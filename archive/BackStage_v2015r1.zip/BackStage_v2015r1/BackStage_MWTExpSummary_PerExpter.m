function MWTSet = MWTExpSummary_PerExpter(MWTSet)
%% README.
% this function provide a summary of experiment done by an experimenter


%% PATHS:
pSaveA = MWTSet.PATHS.pSaveA;


%% SURVEY DATABASE  % [updated 20150512]
pData = MWTSet.PATHS.pData;
Database = Dance_surveydatabase(pData);
MWTSet.Database = Database;

MWTSet = Dance_selectinputMWTfiles(MWTSet,Database,'expter');

%% summarize pMWT
pMWT = MWTSet.MWTInfo.pMWT;
MWTSet.MWTInfo = MWTInfo_reconstruct(pMWT);


%% summary of experiments
T = table;

% list of experiments
ExpName = MWTSet.MWTInfo.ExpName;

ExpName = MWTSet.MWTInfo.ExpName;
T.ExpName = ExpName;
T.ExpDate = expname_parse(ExpName,{'expdate'});
T.Tracker = expname_parse(ExpName,{'tracker'});
T.Expter = expname_parse(ExpName,{'expter'});
T.RunCondition = expname_parse(ExpName,{'runcond'});
Gn = mwtname_getgroupNexpName(MWTSet.MWTInfo.pMWT,{'gname'});
T.GroupName = Gn;

% strain name
a = regexpcellout(T.GroupName,'_','split');
T.Strain = a(:,1);

% group condition
A = {};
for x = 1:numel(Gn)
    a = regexp(Gn{x},'_');
    if isempty(a) ==1
        A{x,1} = {};
    else
        b = Gn{x};
        A{x,1} = b(a+1:end);
    end
end
T.GroupCond = A;


T.MWTName = MWTSet.MWTInfo.MWTfn;
cd(pSaveA); 
writetable(T,'Experiment Summary.txt','Delimiter','\t')


%% Text reports
display 'Unique run conditions:'
RCL = T.RunCondition;
RCU = unique(RCL);
disp(char(RCU))

%% within each run condition what group names:
GN = T.GroupName;
for x = 1:numel(RCU)
    i = ismember(RCL,RCU{x});
    GNL = GN(i);
    display ' ';
    display(sprintf('These groups belongs to RC[%s]: ',RCU{x}));
    a = tabulate(GNL);
    disp(a)
    T = cell2table(a);
    cd(pSaveA);
    writetable(T,[RCU{x},'.txt'],'Delimiter','\t');
% char(unique(T.GroupName))
    
end


%% exp list text files
pSaveA = MWTSet.PATHS.pSaveA;
cd(pSaveA)
a = unique(MWTSet.MWTInfo.ExpName);
[nrows,ncols]= size(a);

filename = 'experiment_list.dat';
fid = fopen(filename, 'w');

for row=1:nrows
    fprintf(fid, '%s\n', a{row,:});
end

fclose(fid);








