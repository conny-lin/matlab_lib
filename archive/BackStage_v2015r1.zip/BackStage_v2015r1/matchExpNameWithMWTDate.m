
function A = matchExpNameWithMWTDate(pData)

%% match experiment date with MWT date
Database = Dance_surveydatabase(pData);

%%
Database.MWTfn{1}