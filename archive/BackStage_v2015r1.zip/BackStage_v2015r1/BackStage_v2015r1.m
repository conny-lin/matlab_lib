% function MWTSet = BackStage_v2015r1
%% INSTRUCTION
% inputs should be paired with a name of the type of input

%% CLEAR MEMORY
clear

%% PROGRAM INFO & GLOBAL VARIABLES
a = regexp(mfilename,'_','split');
ProgramName = a{:,1}; MWTSet.ProgramName = ProgramName;
ProgramVersion = a{:,2}; MWTSet.ProgramVersion = ProgramVersion;
GeneralFunFolderNames = {'.git','Chor','Modules','TextFiles'};
ProgramStatusType = {'Coding','Testing','Publish_InDrive'};
ProgramStatus = ProgramStatusType{1};

%% PATHS: GENERAL FUNCTIONS [updated 20150511]
% get code path
pFun = [fileparts(which(mfilename)),'/',mfilename]; addpath(pFun); 
MWTSet.PATHS.pCode = pFun;
% add matlab public library path
addpathfromtextfile([pFun,'/path_matlabfunction.dat']);
% add common module path
addpathfromtextfile([pFun,'/path_MWTmodules.dat']);


%% PATH: DATA, ANALYSIS OUTPUTS, AND REPORTS
% paths are given in text files under TextFile folder
filepath = [pFun,'/path_datadrive.dat'];
[p,filename] = fileparts(filepath);
a = ls(p);
if isempty(strfind(a,filename)) == 0; 
    pDriveHome = addpathfromtextfile(filepath);
    pData = [pDriveHome,'/MWT/Data']; 
else
    error('path_datadrive.dat file did not contain a valid path');
end
MWTSet.PATHS.pData = pData;

% PATH: CHOR ANALYSIS OUTPUT 
pAnalysis=  [pDriveHome,'/MWT/Analysis'];
if isdir(pAnalysis) == 0;
    warning('missing analysis output folder, creating one')
    mkdir(pAnalysis);
end
MWTSet.PATHS.pAnalysis = pAnalysis;


% PATH: OUTPUT HOME
% generate output paths
filepath = [pFun,'/path_output.dat'];
[p,filename] = fileparts(filepath);
a = ls(p);
if isempty(strfind(a,filename)) == 0; 
    pOutputHome = addpathfromtextfile(filepath);
else
    error('path_output.dat file did not contain a valid path');
end
MWTSet.PATHS.pOutputHome = pOutputHome;

%% SELECT EXTENTION PACKS
% p = [MWTSet.PATHS.pCode];
a = dircontent(MWTSet.PATHS.pCode,[ProgramName,'_*.m']);
b = regexprep(a,['(',ProgramName,'_)|(.m)'],'');
% a(ismember(a,{'.git'})) = [];
AnalysisName = a{chooseoption(b,'Choose extension packs:','index')};
MWTSet.AnalysisCode = AnalysisName;


%% PATHS: CREAT OTHER PATHS
MWTSet.pStore = [pDriveHome,'/MWT_Data_ExpZip'];
MWTSet.pIn = [pDriveHome,'/MWT_Data_Inbox'];
pTemp = [pDriveHome,'/TEMP']; if isdir(pTemp) == 0; mkdir(pTemp); end
MWTSet.pTemp = pTemp;

%% PATHS: CREATE OUTPUT PATHS
% generate time stampe
timestamp = generatetimestamp;
MWTSet.timestamp = timestamp;

% create output name
display ' ';
display 'Enter a name for your output folder';
name = input(': ','s');

% generate output folder
FunName = MWTSet.AnalysisCode;
OutputFolderName = [FunName,' ', timestamp,' ', name];
pSaveA = [pOutputHome,'/',OutputFolderName];
MWTSet.PATHS.pSaveA = pSaveA;
if isdir(pSaveA) == 0; mkdir(pSaveA); end
MWTSet.OutputFolderName = OutputFolderName;


%% TESTING: STOP PROGRAM 
varargout{1} = MWTSet;
if strcmp(ProgramStatus,'Testing') == 1
    cd(pSaveA); save('matlab.mat','MWTSet'); 
    disp ' ';
    disp(MWTSet)
    return
end


%% RUN SUB-FUNCTION MODULE
eval(['[MWTSet] = ',MWTSet.AnalysisCode,'(MWTSet);']);


%% make a copy of the analysis code in output folder
source = MWTSet.PATHS.pAnalysisFun;
dest = regexprep(source,fileparts(source),pSaveA);
copyfile(source,dest)


%% CREATE REPORT OF INFO OF THIS ANALYSIS [disabled]
% % REPORT
% % GET pMWT from MWTfG
% MWTfG = MWTSet.MWTfG;
% if isstruct(MWTfG) ==1
%     A = celltakeout(struct2cell(MWTfG),'multirow');
%     pMWT = A(:,2); 
% end
% [p,mwtfn] = cellfun(@fileparts,pMWT,'UniformOutput',0);
% [pExp,gfn] = cellfun(@fileparts,p,'UniformOutput',0);
% groupnames = unique(gfn);
% pExpU = unique(pExp);
% [~,ExpfnU] = cellfun(@fileparts,pExpU,'UniformOutput',0);
% Report = nan(numel(pExpU),numel(groupnames));
% expstr = 'Experiments = ';
% for e = 1:numel(pExpU)
%     [fn,p] = dircontent(pExpU{e});
%     a = regexpcellout(ExpfnU{e},'_','split');
%     a = [a{1,1},'_',a{2,1}];
%     expstr = [expstr,a,', ']; 
%     for g = 1:numel(groupnames)
%         i = ismember(fn,groupnames{g});
%         if sum(i) == 0;
%             n = 0;
%         else
%             p1 = p{i};
%             fn1 = dircontent(p1);
%             n = numel(fn1);
%         end
%         Report(e,g) = n;
%     end
% end
% expstr = [expstr(1:end-2),'; '];
% 
% % sample size string
% names = fieldnames(MWTSet.MWTfG);
% a = structfun(@size,MWTSet.MWTfG,'UniformOutput',0);
% s = [];
% str = '';
% for x = 1:numel(names)
% 
%     str = [str,names{x},' N=',num2str(a.(names{x})(1,1)),'; '];
% end
% Nstr = str;
% 
% % by experiment number
% str = '';
% for g = 1:numel(groupnames)
%     str = [str,groupnames{g},'='];
%     a = Report(:,g);
%     
%     for x = 1:numel(a)
%         str = [str,num2str(a(x,1)),','];
%     end
%     str = [str(1:end-1),'; '];
% end
% expNstr = str(1:end-2);
% 
% % compose
% expreport = [Nstr,' ',expstr,expNstr];
% 
% MWTSet.expreport = expreport;
% [~,fn] = fileparts(MWTSet.pSaveA);
% display([fn,' (', char(MWTSet.StatsOption),') ',MWTSet.expreport]);
% 
% cd(MWTSet.pSaveA); save('matlab.mat','MWTSet');
% 
% 
% 
% 
% display 'Analysis completed';


%% VARARGOUT
varargout{1} = MWTSet;


%% DISPLAY END AND SAVE
cd(MWTSet.PATHS.pSaveA);
save('matlab.mat','MWTSet');

display '  ** Dance: The End **'
display ' ';
return



































