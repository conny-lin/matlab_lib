function MWTSet = BackStage_matchAwithD(MWTSet)

%% conslidate analysis output folders
pAnalysis = MWTSet.PATHS.pAnalysis;
pData = MWTSet.PATHS.pData;

%% get database files
[~,~,~,pE] = dircontent(pData);
[~,~,~,pG] = cellfun(@dircontent,pE,'UniformOutput',0);
pG = celltakeout(pG);
[f,p] = cellfun(@dircontent,pG,'UniformOutput',0);
p = regexprep(celltakeout(p,'multirow'),'(.zip)','');
f = regexprep(celltakeout(f,'multirow'),'(.zip)','');
str = '\<(\d{8})[_](\d{6})\>';
i = regexpcellout(f,str);
MnDatabase = f(i);
pMDataBase = p(i);


%% get analysis files
[~,~,~,pE] = dircontent(pAnalysis);
[~,~,~,pG] = cellfun(@dircontent,pE,'UniformOutput',0);
pG = celltakeout(pG,'multirow');
[f,p] = cellfun(@dircontent,pG,'UniformOutput',0);
p = regexprep(celltakeout(p,'multirow'),'(.zip)','');
f = regexprep(celltakeout(f,'multirow'),'(.zip)','');
str = '\<(\d{8})[_](\d{6})\>';
i = regexpcellout(f,str);
fMA = f(i);
pMA = p(i);


%% replace analysis file with data base file to see if there are the same
pMAmatch = regexprep(pMA,pAnalysis,pData);
i = ismember(pMDataBase,pMAmatch);
sum(i)
numel(pMDataBase)

%%
pMnotInA = pMDataBase(~i);
unique(mwtpath_parse(pMnotInA,{'expname'}))




return


%% get exp folders
[~,~,En,pE] = dircontent(pAnalysis);

%% look to see any MWT names under exp folder
f = En;
str = '\<(\d{8})[_](\d{6})\>';
i = regexpcellout(f,str);
if sum(i) > 0
    disp('problem: MWT plates as exp folder:');
    disp(char(regexprep(pG(i),pAnalysis,'')));
    return
end


%% check folders under exp folders
[~,~,Gn,pG] = cellfun(@dircontent,pE,'UniformOutput',0);
i = cellfun(@isempty,pG);
if sum(i) > 1
    display 'the following exp folders do not contain group folders';
    p = regexprep(pE(i),pAnalysis,'');
    disp(p)
    error('correct before proceeding');
end
pG = celltakeout(pG);
Gn = celltakeout(Gn);

f = Gn;
str = '\<(\d{8})[_](\d{6})\>';
i = regexpcellout(f,str);
if sum(i) > 0
    disp('problem: MWT plates as group folder:');
    disp(char(regexprep(pG(i),pAnalysis,'')));
    error('correct before proceeding');
    return
end

%% ignore matlab folders
n1 = numel(pG);
str = '(MatlabAnalysis)|(Matlab)';
i = regexpcellout(Gn,str);
pG = pG(~i);
n2 = n1-numel(pG);
disp(sprintf('%d/%d folders are matlab analysis folders',n2,n1));


%% check folder under group folders
[fn,pf,Mn,pM] = cellfun(@dircontent,pG,'UniformOutput',0);


%% check if folder under group folder empty
i = cellfun(@isempty,pM);
if sum(i) > 0
    display(sprintf('%d/%d group folders are empty',sum(i),numel(pG)));
    display('remove those folders');
    pM = pM(~i);

end
pM = celltakeout(pM);
[~,Mn] = cellfun(@fileparts,pM,'UniformOutput',0);

%% validate MWT name
f = Mn;
str = '\<(\d{8})[_](\d{6})'; % ignore notes after MWT name
i = ~regexpcellout(f,str);
if sum(i) > 0
    disp('problem: not MWT folder name:');
    disp(char(regexprep(pM(i),pAnalysis,'')));
    error('correct before proceeding');
    return
end


%% see duplications
duplicatenameok = {'20110827_105902'};
a = tabulate(Mn);
i = cell2mat(a(:,2)) > 1;
b = a(i,1);
b(ismember(b,duplicatenameok)) = [];
if sum(i) > 0
    display 'duplicated MWT files found';
    disp(char(b));
    display(sprintf('%d duplicated MWT files found',numel(b)));
    
   names = {'fixed manually';'merge like database';'copy like database';'return'};
   option = chooseoption(names,'Select option:');
   
   % search each duplications
    for x = 1:numel(b)
        MnT = b{x};
        display(sprintf('processing [%s]',MnT));
        i = ismember(Mn,b{x});
        pP = pM(i);
        i = ismember(MnDatabase,b{x});
        pD = pMDataBase(i);
        if isempty(pD) == 1; 
            display 'MWT file not found in database';
        end
        
        switch option
           case 'fixed manually'
           case 'return'
               return
 
           case 'merge like database'
                display ' ';
                display('duplicate folders');
                disp(char(regexprep(pP,pAnalysis,'')));
                display('in database this files belongs to:');
                disp(char(regexprep(pD,pData,'')));
               p = fileparts(char(pD));
               pC = regexprep(p,pData,pAnalysis);
               pPP = cellfun(@fileparts,pP,'UniformOutput',0);
               i = ~ismember(pPP,pC);
               notgoodpath = pP(i);
               goodpath = pP(~i);
               op2 = chooseoption({'yes';'return'},'merge these files');
               switch op2
                   case 'yes'
                       [~,pF] = cellfun(@dircontent,notgoodpath,'UniformOutput',0);
                       pF = celltakeout(pF);
                       pDS = regexprep(pF,notgoodpath,goodpath);
                       cellfun(@movefile,pF,pDS);
                       
                       display 'delete duplicated file folder';
                       cellfun(@rmdir,notgoodpath);
                       
                   case 'return'
                       return
               end
               
               
               
           case 'copy like database'

               if isempty(pD) == 0
                   p = fileparts(char(pD));
                   pC = regexprep(p,pData,pAnalysis);
                   pPP = cellfun(@fileparts,pP,'UniformOutput',0);
                   i = ~ismember(pPP,pC);
                   notgoodpath = pP(i);
                   if sum(~i) == 1
                       goodpath = pP(~i);
                   else
                       goodpath = pC;
                      if isdir(goodpath) == 0
                          error('test')
                          mkdir(goodpath);
                      end
                   end

                   if size(pC,1) == 1 && isempty(notgoodpath) == 0
                      [~,pF] = cellfun(@dircontent,notgoodpath,'UniformOutput',0);
                      pF(cellfun(@isempty,pF)) = []; 

                      if isempty(pF) == 0
                            pF = celltakeout(pF);

                            pDS = regexprep(pF,notgoodpath,goodpath);
                            % check if designation has the same files
                            [~,pDexist] = dircontent(char(goodpath));
                            if isempty(pDexist) == 0
                                i = ismember(pDS,pDexist);
                                pDS(i) = [];
                                pF(i) = [];
                            end

                            if isempty(pDS) == 0
                                display ' ';
                                display('duplicate folders');
                                disp(char(regexprep(pP,pAnalysis,'')));
                                display('in database this files belongs to:');
                                disp(char(regexprep(pD,pData,'')));
                                display(sprintf('copying %d files',size(pDS,1)));
                                cellfun(@copyfile,pF,pDS);
                            end
                      else
                      end


                   end
               end

       end
    end
end




























