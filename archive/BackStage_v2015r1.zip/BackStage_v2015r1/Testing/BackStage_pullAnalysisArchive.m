function BackStage_pullAnalysisArchive(pOldA,pNewA)

% pOldA = '/Volumes/ParahippocampalGyrus/MWT/Data Archive/MWT_Data_Analysis_20150412';
addpath('/Users/connylin/Dropbox/MATLAB/Programs_RankinLab/Library/MWT Common Modules');
addpath('/Users/connylin/Dropbox/MATLAB/Function_Library_Public');
% pNewA = '/Volumes/ParahippocampalGyrus/MWT/Analysis';


%% get MWT folders

[~,~,~,pExpfD] = dircontent(pOldA); 
[~,~,fn,p] = cellfun(@dircontent,pExpfD,'UniformOutput',0);
fn = celltakeout(fn,'multirow');
p = celltakeout(p,'multirow');
i = ~ismember(fn,{'MatlabAnalysis';'Matlab'});
Gfn = fn(i);
pGf = p(i);
[~,pMWT,~,~] = cellfun(@dircontent,pGf,'UniformOutput',0);
pMWT = celltakeout(pMWT,'multirow');
[~,fn] = cellfun(@fileparts,pMWT,'UniformOutput',0);
pMWT(~regexpcellout(fn,'\<(\d{8})[_](\d{6})\>')) = [];
pOldMWT = pMWT;
fnOldMWT = mwtpath_parse(pMWT,{'MWTname'});

%% look for duplication in old
A = pOldMWT;
a = tabulate(A);
a(cell2mat(a(:,2)) <=1,:) = [];
if isempty(a) == 0; error('duplicates in analysis archive'); end

%% get new folders
[~,~,~,pExpfD] = dircontent(pNewA); 
[~,~,fn,p] = cellfun(@dircontent,pExpfD,'UniformOutput',0);
fn = celltakeout(fn,'multirow');
p = celltakeout(p,'multirow');
i = ~ismember(fn,{'MatlabAnalysis';'Matlab'});
Gfn = fn(i);
pGf = p(i);
[~,pMWT,~,~] = cellfun(@dircontent,pGf,'UniformOutput',0);
pMWT = celltakeout(pMWT,'multirow');
[~,fn] = cellfun(@fileparts,pMWT,'UniformOutput',0);
pMWT(~regexpcellout(fn,'\<(\d{8})[_](\d{6})\>')) = [];
pNewMWT = pMWT;
fnNewMWT = mwtpath_parse(pMWT,{'MWTname'});

%% look for duplication in new
A = pNewMWT;
a = tabulate(A);
a(cell2mat(a(:,2)) <=1,:) = [];
if isempty(a) == 0; error('duplicates in analysis new'); end



%% copy matched files without the same files
A = fnOldMWT;
B = fnNewMWT;
[C,ia,ib] = intersect(A,B);
D = cell(size(C,1),3);
D(:,1) = C;
D(:,2) = pOldMWT(ia);
D(:,3) = pNewMWT(ib);

%%
for x = 1:size(D,1)
p = D{x,2};
[f1,p1] = dircontent(p);

i = regexpcellout(f1,'(.blob)|(.summary)|(.png)|(.blobs)');
if numel(i) == numel(f1);
   p1(i) = []; 
   f1(i) = [];
end
% copy
cd(p);
[f2,p2] = dircontent(D{x,3});
i = ~ismember(f1,f2);
p1 = p1(i);
if isempty(p1) == 0
    [~,ff] = fileparts(D{x,3});
    fprintf('copying: %s\n',ff);
cellfun(@copyfile,p1,cellfunexpr(p1,D{x,3}));
end
end













