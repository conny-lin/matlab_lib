function MWTSet = matchExpNameWithMWTDate(MWTSet)

%% get paths from MWTSet

pData = MWTSet.PATHS.pData;
pAnalysis = MWTSet.PATHS.pAnalysis;
pStore = MWTSet.PATHS.pStore;

%% match experiment date with MWT date
Database = Dance_surveydatabase(pData);


%% check names
Expfn = Database.ExpfnD;
checkMWTexpnameStd(Expfn,'stop');


%% get date of MWTf
pMWT = Database.pMWTf;
MWTfn = mwtname_getgroupNexpName(pMWT,{'MWTname'});
MWTdate = mwtname_getdate(pMWT,'numeric');

%% get date of exp folder 
Expfn = mwtname_getgroupNexpName(pMWT,{'expname'});
expdate = expname_getdate(Expfn,'numeric');

%% find dates not matching
a = MWTdate - expdate;
i = find(a ~= 0);
pE = mwtname_getgroupNexpName(pMWT,{'pE'});
Expfn_bad = Expfn(i);
pE_bad = pE(i);
expdate_bad = expdate(i);


%% look into each exp to find lowest MWT date
pE_bad_unique = unique(pE_bad);
pEU = unique(pE_bad);
expdate_bad_unique = expname_getdate(pEU,'numeric');

nameMatch = cell(size(pEU));
array = nan(size(expdate_bad_unique));
dateMatch = [expdate_bad_unique,array,array];

for x = 1:numel(pEU)
    p = pEU{x};
    [~,expname] = fileparts(p);
    nameMatch{x,2} = expname;
    nameMatch{x,1} = p;
    
    [~,pG] = dircontent(p);
    MWTdate_min = [];
    MWTdate_max = [];
    for g = 1:numel(pG)
        pGT = pG{g};
        [~,pMWT] = dircontent(pGT);
        % get lowest date
        MWTdate = mwtname_getdate(pMWT,'numeric');
        MWTdate_min(g,1) = min(MWTdate);
        MWTdate_max(g,1) = max(MWTdate);
    end
    MWTdate_min = min(MWTdate_min);
    MWTdate_max = max(MWTdate_max);
    dateMatch(x,2) = MWTdate_min;
    dateMatch(x,3) = MWTdate_max;
end

%% if lowest date the same as exp date, remove
i = (dateMatch(:,2)-dateMatch(:,1)) == 0;
pEU(i) = [];
dateMatch(i,:) = [];
nameMatch(i,:) = [];


%% get exp name suffix
pE = pEU;
% expname_parse(pE)
[expname_suffix] = expname_parse(pEU,{'nameafterdate'});
newexpdate = cellstr(num2str(dateMatch(:,2)));

%% report
[expname] = expname_parse(pEU,{'expname'});
display ('the following exp mismatch with MWT date');
disp(expname)

%% recommend new names
nameMatch(:,3) = cellfun(@strcat,newexpdate,expname_suffix,'UniformOutput',0);
newname = nameMatch(:,3);
display('recommended name change:')
disp(newname)


%% for each experiments
% get database path
pDH = unique(cellfun(@fileparts,pEU,'UniformOutput',0));
if numel(pDH) > 1
    error('more than one database path')
end


ChangeAction = nan(size(pEU));

display ' ';
for e = 1:numel(pEU)
    % see disparity of mwt dates
    datediff = dateMatch(e,3) - dateMatch(e,2);
    % get names
    expname_old = expname{e};
    newnameT = newname{e};
    pEDO = pEU{e};
    display(sprintf('bad expname: %s',expname_old));
    % vaidate paths
    pEDN = regexprep(pEDO,expname_old,newnameT);
    if isdir(pEDN) ==1
        option = 'stop to see what to do';
        error('already has %s in raw data database',newnameT)  
    end

    pEAO = regexprep(pEDO,pDH,pAnalysis);
    if isdir(pEAO) == 0
        disp 'does not have analysis folder'
        disp 'create one';
        mkdir(pEAO);
        option = 'normal';
    end
    
    pEAN = regexprep(pEAO,expname_old,newnameT);
    if isdir(pEAN) == 1
        option = 'combine new and old analysis database';
        error('already has %s in analysis database',newnameT) 
    end
    
    
%     display ' ';
    display(sprintf('dates of MWT within this exp are [%d] day(s) apart',...
        datediff));
    if datediff == 1 || datediff == 0
%         disp(expname_old)
%         display ' ';
%         display('recommended action: change to new name');
%         disp(newnameT);
%         ChangeAction(e)  = chooseoption({'yes';'no'},'Change?','index');
        ChangeAction(e) = 1;
    elseif datediff >1 || datediff <0
%         disp(expname_old)
%         display ' ';
%         display('recommended action: examine exp manually');
%         disp(newnameT);
%         ChangeAction(e)  = chooseoption({'yes';'no'},'Change?','index');
        ChangeAction(e) = 2;
    end

end

%% automatic change
str = 'automatically change these';
disp(str);
i = ChangeAction == 1;
pEUAction = pEU(i);
newnameAction = nameMatch(i,3);
disp(newnameAction);

%% process action - manually change
str = 'manually change these';
disp(str)
disp(expname(ChangeAction == 2))


%% CODE STOP
return


%% for automatic change

[expname] = expname_parse(pEUAction,{'expname'});

for e = 1%:numel(pEUAction)
    % get names
    expname_old = expname{e};
    newnameT = newname{e};
    
    pEDO = pEUAction{e};
    display(sprintf('change [%s] to [%s]',expname_old,newnameT));
    
    % vaidate paths
    pEDN = regexprep(pEDO,expname_old,newnameT);
    if isdir(pEDN) ==1
        option = 'stop to see what to do';
        error('already has %s in raw data database',newnameT) 
    else
        % move analysis folder
        source = pEAO;
        dest = pEAN;
        movefile(source,dest,'f')
    end

   
    pEAO = regexprep(pEDO,pDH,pAnalysis);
    if isdir(pEAO) == 0
        disp 'does not have analysis folder'
        disp 'create one';
        mkdir(pEAO);
        option = 'normal';
        
        % write old exp name in analysis exp folder
        filename = [expname_old,'.oldname.dat'];
        cd(pEAO{x});
        dlmwrite(filename,M);
    end
    pEAN = regexprep(pEAO,expname_old,newnameT);
    if isdir(pEAN) == 1
        option = 'combine new and old analysis database';
        error('already has %s in analysis database',newnameT) ;
    else
        % move analysis folder
        source = pEAO;
        dest = pEAN;
        movefile(source,dest,'f')
    end
    

    
end









return

%% if all MWT are in the same date, the exp name should be changed
display 'dates of MWT within this exp are all the same date:'
isamedate = datediff == 0;
pEUT = pEU(isamedate);
expnameOld = expname(isamedate);
disp(expnameOld);
display('recommended new name:');
newnameT = newname(isamedate);
disp(newnameT);

%% autochange (disabled)
pDH = unique(cellfun(@fileparts,pEU,'UniformOutput',0));
if numel(pDH) > 1
    error('more than one database path')
end
pNewNameT = regexprep(pEUT,expnameOld,newnameT);
pOldNameA = regexprep(pEUT,pDH,pAnalysis);
pNewNameA = regexprep(pEUT,pDH,pAnalysis);

%% check if new name already exist
[~,pexpnameDatabase] = dircontent(pData);
i = ismember(pNewNameT,pexpnameDatabase);
sum(i) == 0

%% record old name in analysis folder
M = str2num(generatetimestamp);

for x = 1%:numel(pOldNameA)
    filename = [expnameOld{x},'.oldname.dat'];
    cd(pOldNameA{x});
    dlmwrite(filename,M)
end

% find analysis folder


%% if the MWt dates are only on date difference, change to earliest exp date
ionedatediff = datediff == 1;

%% if dates are more than one day diff, probably multiple exp in one
imultidates = datediff > 1;




%% match analysis vs data folder name
% record former exp name





