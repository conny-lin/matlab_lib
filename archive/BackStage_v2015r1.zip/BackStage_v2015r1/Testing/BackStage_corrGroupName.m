% function BackStage_corrGroupName  correct specified group name in
% database
pH = '/Volumes/ParahippocampalGyrus/';
pA = [pH,'MWT/Analysis'];
pD = [pH,'MWT/Data'];
gnWrong = 'MT11480';
gnCorr = 'MT14480';


%% find group name
p = pD;
[~,~,~,pE] = dircontent(p); 
[~,~,fn,p] = cellfun(@dircontent,pE,'UniformOutput',0);
fn = celltakeout(fn,'multirow');
p = celltakeout(p,'multirow');
i = ~ismember(fn,{'MatlabAnalysis';'Matlab'});
Gfn = fn(i);
pGf = p(i);
i = ismember(Gfn,gnWrong);
pGf{i}

% [~,pMWT,~,~] = cellfun(@dircontent,pGf,'UniformOutput',0);
% pMWT = celltakeout(pMWT,'multirow');
% [~,fn] = cellfun(@fileparts,pMWT,'UniformOutput',0);
% pMWT(~regexpcellout(fn,'\<(\d{8})[_](\d{6})\>')) = [];
% pOldMWT = pMWT;
% fnOldMWT = mwtpath_parse(pMWT,{'MWTname'});
