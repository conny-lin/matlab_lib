function MWTSet = BackStage_mwtfiles_replicate(MWTSet)
%% MWTSet = mwtfiles_replicate(MWTSet)



%%
% nIn = 1;
% if nargin > nIn
%     INPUT = varargin;
% end
%% list of experiment previously validated:
% expOK = {'20110827B_CL_2s30x10s598s_pilot';'20110827C_SS_600s0x0s0s_coiling'};
expOK = {};
%% check for replicated MWT files
pData = MWTSet.PATHS.pData;
pAnalysis = MWTSet.PATHS.pAnalysis;
pStore = MWTSet.PATHS.pStore;

%% look for rep files
% survey database
Database = Dance_surveydatabase(pData);

MWTfn = Database.MWTfn;
a = tabulate(MWTfn);
i = cell2mat(a(:,2)) > 1;

a = a(i,1:2);
MWTfn_rep = a(:,1);
MWTSet.DuplicateMWTfileSummary = a;


%%
i = ismember(MWTfn,MWTfn_rep);
pMWT_rep = Database.pMWTf(i);
MWTSet.pMWTduplicate = a;



%%
expname = mwtname_getgroupNexpName(pMWT_rep,{'expname'});
i = ismember(expname,expOK);
pMWT_rep(i) = [];
expname(i) = [];


% display bad exp names
disp('following exp contains duplicated MWT files');
disp(unique(expname))


%% look at each plate
mwtnameList = mwtname_getgroupNexpName(pMWT_rep,{'MWTname'});
xStart = 1;
for x = xStart:numel(pMWT_rep)
    mwtname = mwtname_getgroupNexpName(pMWT_rep(x),{'MWTname'});
    i = ismember(mwtnameList,mwtname);
%     mwtnameList(i)
    a = pMWT_rep(i);
    a = regexprep(a,pData,'');
    a = regexprep(a,mwtname,'');
    disp(sprintf('[%s]',char(mwtname)))
    disp('duplicates are in paths below:')
    disp(char(a))
    i = input('enter [1] when ready for next plate: ');
    if i ~=1
        xStart = x;
        return
    end
end


return




%%



p = mwtname_getgroupNexpName(pMWT_rep,{'pE'});
pp = unique(p);
n = 1;
%% look at first exp


pEQ = pp{n};

[gname,pG] = dircontent(pEQ);
[mwtname, pMWTQ] = cellfun(@dircontent,pG,'UniformOutput',0);
pMWTQ = celltakeout(pMWTQ);
mwtname = celltakeout(mwtname);
mwtname = regexprep(mwtname,'(.zip)','');


[~,EQname] = fileparts(pEQ);
p = Database.pMWTf(ismember(Database.MWTfn,mwtname));
display(sprintf('MWT files in exp [%s]',EQname));
% duplicated mwt
mname = unique(mwtname_getgroupNexpName(p,{'MWTname'}));
disp(mname)

display 'are also found in:';
expname = unique(mwtname_getgroupNexpName(p,{'expname'}));
expname(ismember(expname,EQname)) = [];
disp(expname);


return
%%
nMWT = 1;
m = unique(mwtname_getgroupNexpName(pMWTQ,{'MWTname'}));
tabulate(m)


















