%% INFORMATION:
% date: 201604051120
% objectives:
% - see if can compare between assays. all from 1-200s, except for 60mins
% experiment needs to start at 1800s (30mins post exposure)

%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% SETTINGS
timeStartSet = 0;
timeEndSet = 200;
timeInterval = 10;

%% load database
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
load(pDB);
MWTDB = MWTDB.text;

%% Igor exp standard 
explist = {
    '20130308C_BM_100s30x10s10s_10sISI_tolerance2'
    '20130315C_BM_100s30x10s10s_10sISI_tolerancefood'};
rclist = {
    '300s30x10s0s'
    '0s2x0s1320s'
    '300s0x0s0s'
    '3600s0x0s0s'
    '600s0x0s0s'
    '900s0x0s0s'};
% query
i = (ismember(MWTDB.rc, rclist) | ismember(MWTDB.expname, explist)) & ...
    ~ismember(MWTDB.expter,'SS') ...
    & ~ismember(MWTDB.groupname, {'N2_Test','N2_400mM_NoFood','N2_NoFood'});
MWTDB(~i,:) = [];

% change to group name alternate for igor
MWTDB = rxname_add2MWTDB(MWTDB);

%% additional query
% keep only N2
MWTDB(~ismember(MWTDB.strain, 'N2'),:) = [];
% rx dose = 0
MWTDB(~(MWTDB.dose_rx==0 |isnan(MWTDB.dose_rx)) ,:) = [];
% test dose = 0 or none
MWTDB(MWTDB.dose_test~=0,:) = [];



%% GET DATA
% chor
[L,pMWTps,pMWTfailed] = chormaster5('DrunkPostureOnly',MWTDB.mwtpath);
% recreate MWTDB
MWTDB = parseMWTinfo(pMWTps);
MWTDB = rxname_add2MWTDB(MWTDB);
% import
[Data,~,Legend2] = import_drunkposture2_dat(pMWTps,'array');
if numel(pMWTps) ~=numel(Data); error('import number incorrect'); end
Data = array2table(cell2mat(Data),'VariableNames',Legend2);

% change 60mins time t=0 as 30mins into exposure
mwtid60min = MWTDB.mwtid(ismember(MWTDB.rc,'3600s0x0s0s'));
i = ismember(Data.mwtid,mwtid60min);
Data.time(i) = Data.time(i) - (30*60);

%  remove data outside of assay time
Data(Data.time < timeStartSet | Data.time > timeEndSet,:) = [];
% delete data with no good numbers
Data(Data.goodnumber==0,:) = [];

% transform time to assay time
ta = timeStartSet:timeInterval:timeEndSet;
Data.time = transform_time2assaytime(Data.time,timeAssay);

%% analyze by age test x rc
msrlist = {'speed','curve'};
storeprefix = 'Data_rc_age';
agetestu = unique(MWTDB.age_test);
groupname = 'rc';
gnu = unique(MWTDB.(groupname));
[~,j] = ismember(Data.mwtid,MWTDB.mwtid);
age = MWTDB.age_test(j);
gname = MWTDB.(groupname)(j);
S = struct;
for ai = 1:numel(agetestu)
    aget = agetestu(ai);
    D1 = Data(age==aget,msrlist);
    t = Data.time(age==aget);
    g = gname(age==aget);
    fn = sprintf('%s%d',storeprefix,aget);
    % calculate speed and curve
    display 'calculate per plate stats, this will take a while';
    S(ai).age = aget;
    S(ai).data = cal_meanPerTime(D1,t,g,'groupname',groupname);
    display '-done';    
end

%% export data
for si = 1:numel(S)
    for msri = 1:numel(msrlist)
        msr = msrlist{msri};
        D = S(si).data.(msr);
        time = cellfun(@num2str,num2cell(D.time),'UniformOutput',0);
        colname = strjoinrows([cellfunexpr(time,'t') time],'');
        gnu = unique(D.(groupname));
        A = nan(numel(gnu)*2,numel(colname));
        r1 = 1;
        T = table;
        T.(groupname) = repmat(gnu,2,1);
        stats = {'mean','se'};
        for stati = 1:numel(stats)
            r2 = r1+numel(gnu)-1;
            A(r1:r2,:) = D.(stats{stati})';
            r1 = r2+1;
        end
        T = [T array2table(A,'VariableNames',colname)];
        cd(pSave);
        savename = sprintf('%s_age%d.csv',msr,S(si).age);
        writetable(T,savename);
    end
end
return












%% run Dance
% pMWT = MWTDB.mwtpath;
% MWTSet = Dance_DrunkMoves(pMWT,'pSave',pSave);
% 
% %% get SE
% msrlist = fieldnames(MWTSet.Data_GroupByPlate);
% for msri = 1:numel(msrlist)
%     msr = msrlist{msri};
%     T = MWTSet.Data_GroupByPlate.(msr);
%     T.groupname = MWTSet.Info.VarIndex.groupname(T.groupname);
%     
%     gnu = unique(T.groupname);
%     tn = unique(T.timeind);
%     t = nan(numel(gnu),numel(tn));
%     for gi = 1:numel(gnu)
%         i = ismember(T.groupname,gnu(gi));
%         t(gi,:) = T.SE(i)';
%     end
%     t = array2table(t);
%     T1 = table;
%     T1.groupname = gnu;
%     T1 = [T1 t];
%     cd(pSave);
%     writetable(T1,sprintf('%s/Dance_DrunkMoves/Data Curve/%s SE.csv',pSave,msr));
% end
% 
% %% run stats on 35min mark, speed and curve
% pSaveA = sprintf('%s/Stats',pSave);
% if isdir(pSaveA) == 0; mkdir(pSaveA); end
% gnind = MWTSet.Info.VarIndex.groupname;
% strainind = MWTSet.Info.VarIndex.strain;
% msrlist = {'speed','curve'};
% timeT = 35;
% for msri = 1:numel(msrlist)
%     msr = msrlist{msri};
%     D = MWTSet.Data_Plate.(msr);
%     D(D.timeind~=timeT,:) = [];
%     gn = gnind(D.groupname);
%     strain = strainind(D.strain);
%     % age
%     a = regexpcellout(gn,'\d{1,}(?=d)','match');
%     a(cellfun(@isempty,a)) = {'4'};
%     age = a;
%     % dose
%     a = regexpcellout(gn,'\d{1,}(?=mM)','match');
%     a(cellfun(@isempty,a)) = {'0'};
%     dose = a;
%     %% anovav
%     Y = D.mean;
%     G = [{strain} {age} {dose}];
%     anovan_std(Y,G,{'strain','age','dose'},pSaveA,msr)
%     return
%     
% end
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
























