%% get Pregger graphs to see if speed var imporves after removing outlier

%% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;

%% var
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp';
programName = 'Dance_Glee_Preggers';

analysisNLimit = 0;
exp_exclusion = {};
mwtname_exclude = {};

%% get plate validation file and add more 
pf = sprintf('%s/mwt_summary included issues.csv',pSaveHome);
T = readtable(pf);
% exclude plates with no issues
T(cellfun(@isempty,T.issues),:) = [];

% issues excluding
issues_exclude = {'plate*wet'
'worm*clump'
'worm*curve_not_2SD_flatter_than_0mM_group'
'worm*look_drunk_but_is_0mM_group'
'worm*not_look_drunk_but_is_400mM_group'
'worm*too_many_small_worms'};

% % view unique issues
% issues = T.issues;
% issuesu = unique(issues);
% a = regexpcellout(issuesu,' ','split');
% a = reshape(a,numel(a),1);
% a(cellfun(@isempty,a)) = [];
% a = unique(a);
% get plate name with excluding issues
a = issues_exclude;
b = T.issues;
c = regexpcellout(b,' ','split');
c(cellfun(@isempty,c)) = {''};
val = false(size(b));
for x = 1:numel(a)
   str = regexprep(a{x},'*','[*]');
   for y = 1:size(c,2)
       i = ismember(c(:,y),a{x});
       if sum(i) > 0
        val(i) = true;
       end
   end
end

unique(b(val));
plate_issue_exclude = T.mwtname(val);
mwtname_exclude = [mwtname_exclude; plate_issue_exclude];


%% load MWTset to find which mwtname has revDur threhold higher than 4 after the 5th tap
% define thresholds
ythreshold = 4; % define y threshold
tthreshold = 5; % define time threshold as all time points
msr = 'RevDur';
% load
str = sprintf('%s/Dance_Glee_Preggers 201512121701/Dance_Glee_Preggers.mat',pSaveHome);
load(str);
a = MWTSet.Data.trv.(msr).mean;
% find plates over threshold
m = MWTSet.Data.trv.(msr).mwtname(any(a(tthreshold+1:end,:) > ythreshold));
mwtname_over = m;
mwtname_exclude = [mwtname_exclude; m'];



%% look if plates removed from speed has existing issues
mwtT = mwtname_over;
pf = sprintf('%s/mwt_summary included issues.csv',pSaveHome);
T = readtable(pf);
a = T.issues(ismember(T.mwtname,mwtT));
fprintf('\nmwt with outlier speed existing issues:\n')
disp([mwtT' a])


%% pull images of problem
% define variables
mwtname_bad = mwtname_over; % get bad mwt plate name
suffix = 'duration over 4';
pSave = pSaveHome;
% get images
pImage = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp/plate image';
[f,p] = dircontent(pImage);
mwtname_image = regexpcellout(f,'\d{8}_\d{6}(?=[.]png)','match');
i = ismember(mwtname_image,mwtname_bad);
imageTarget = p(i);
imageTargetFileName = f(i);
pSaveA = sprintf('%s//plate image %s',pSave,suffix);
if isdir(pSaveA) == 0; mkdir(pSaveA); end
for x = 1:numel(imageTarget)
    ps = imageTarget{x};
    pd = [pSaveA,'/',imageTargetFileName{x}];
    copyfile(ps,pd);
end



%% load MWTset to find which mwtname has threhold lower than 0.6
% define thresholds
ythreshold = 0.6; % define y threshold
tthreshold = Inf; % define time threshold as all time points
msr = 'RevSpeed';
% load
str = sprintf('%s/Dance_Glee_Preggers 201512121701/Dance_Glee_Preggers.mat',pSaveHome);
load(str);
a = MWTSet.Data.trv.(msr).mean;
% find plates over threshold
m = MWTSet.Data.trv.(msr).mwtname(any(a > ythreshold));
mwtname_exclude = [mwtname_exclude; m'];

    

%% get name and path of excluded
mwtname_exclude = unique(mwtname_exclude);
pf = sprintf('%s/mwt_summary included issues.csv',pSaveHome);
T = readtable(pf);
i  = ismember(T.mwtname,mwtname_exclude);
mwtpath_exclude = T.mwtpath(i);
mwtpath_include = T.mwtpath(~i);
mwtname_exclude = T.mwtname(i);
mwtname_include = T.mwtname(~i);



%% run Preggers for excluded files
pMWT = mwtpath_exclude;
outputsuffix = 'Excluded RevDur';
% run
pSave = pSaveHome;
if isdir(pSave) == 0; mkdir(pSave); end
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Dance_Glee');
MWTSet = Dance_Glee_Preggers(pMWT,'pSave',pSave,'outputsuffix',outputsuffix,'saveimport',0);

% run Preggers for included files
pMWT = mwtpath_include;
outputsuffix = 'Include RevDur';
% run
pSave = pSaveHome;
if isdir(pSave) == 0; mkdir(pSave); end
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Dance_Glee');
MWTSet = Dance_Glee_Preggers(pMWT,'pSave',pSave,'outputsuffix',outputsuffix,'saveimport',0);



