%% OBJECTIVE:
% - create statistics in Dance_DrunkMoves_RapidTolerance that can do percent
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
% pSave = setup_std(mfilename('fullpath'),'RL');
prgpath = mfilename('fullpath');
wrkgrpname = 'RL';
pSave = prgpath;
if isdir(pSave) == 0; mkdir(pSave); end
pDepository = '/Users/connylin/Dropbox/Code/Matlab/Working Depository';

% ADD FUNCTION PATH
switch wrkgrpname
    case 'RL'
        pFun = {'/Users/connylin/Dropbox/Code/Matlab/Library';
                '/Users/connylin/Dropbox/Code/Matlab/Library RL/Modules';
                '/Users/connylin/Dropbox/Code/Matlab/Library RL/Dance'};
end
addpath_allsubfolders(pFun);

% deposit current code
[~,fname] = fileparts(prgpath);
tstamp = generatetimestamp;
name = sprintf('%s/%s%sa_%s.m',pDepository,wrkgrpname,tstamp,fname);
copyfile([mfilename('fullpath'),'.m'],name);

% copy current code
copyfile(prgpath, [pSave,'/',fname,'_a',tstamp,'.m']);

return
%% LOAD MWT DATABASE
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
load(pDB);
MWTDB = MWTDB.text;

%% SEARCH
i = ismember(MWTDB.groupname,{'DA609_E3d24h0mM_R1h_T4d0mM'});
e = unique(MWTDB.expname(i));
MWTDB(~ismember(MWTDB.expname,e),:) = [];
pMWT = MWTDB.mwtpath;
fprintf('# of MWT: %d\n',numel(pMWT))
fprintf('\nexperiments:\n');
disp(char(unique(MWTDB.expname)))
fprintf('\ngroups:\n');
disp(char(unique(MWTDB.groupname)))



%% run dance
MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSave);



return



















