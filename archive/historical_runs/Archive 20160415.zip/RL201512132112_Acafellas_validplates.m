%% run Dance_Glee_Acafellas
programName = 'Dance_Glee_Acafellas';
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/2-Valid Exp';
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Dance_Glee');

%% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;

%% get pMWT
str = sprintf('%s/mwt_summary valid.csv',pSaveHome);
T = readtable(str);
pMWT = T.mwtpath;

%% run dance
pSave = pSaveHome;
MWTSet = Dance_Glee_Acafellas(pMWT,'analysisNLimit',30,'pSave',pSave);



return




