%% OBJECTIVE:
% - create a list of experiments relevant for rapid tolerance chapter
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load database
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
load(pDB);
MWTDB = MWTDB.text;

%% target list
explist = {
    '20130308C_BM_100s30x10s10s_10sISI_tolerance2'
    '20130315C_BM_100s30x10s10s_10sISI_tolerancefood'};
rclist = {
    '300s30x10s0s'
    '0s2x0s1320s'
    '300s0x0s0s'
    '3600s0x0s0s'
    '600s0x0s0s'
    '900s0x0s0s'};

%% query
i = (ismember(MWTDB.rc, rclist) | ismember(MWTDB.expname, explist)) & ...
    ~ismember(MWTDB.expter,'SS') ...
    & ~ismember(MWTDB.groupname, {'N2_Test','N2_400mM_NoFood','N2_NoFood'});
MWTDB(~i,:) = [];

%% summary
expu = unique(MWTDB.expname);
T = table;
for ei = 1:numel(expu)
    Db = MWTDB(ismember(MWTDB.expname,expu(ei)),:);
    a = tabulate(Db.groupname);
    n = size(a,1);
    b = repmat(expu(ei),n,1);
    t = table;
    t.expname = b;
    t.groupname = a(:,1);
    t.plateN = cell2mat(a(:,2));
    T = [T;t];
    
end


%% parse rx
fG = T.groupname;
T.strain = regexpcellout(fG,'\<[A-Z]{1,}\d{1,}','match');
a = regexpcellout(fG,'_','split');
T.rx = regexpcellout(fG,'(?<=\<[A-Z]{1,}\d{1,}_)\w{1,}','match');
T.rx(cellfun(@isempty,T.rx)) = {'NA'};
a = regexpcellout(T.expname,'_','split');
T.rc = a(:,3);
%% save standard exp file
cd(pSave);
writetable(T,'expsum.csv');


%% change to group name alternate
cd(fileparts(pSave));
rxname = readtable('rxname_alternate.csv');
for ri =1:size(rxname,1)
    i= ismember(MWTDB.rx,rxname.rx(ri));
    MWTDB.rx(i) = rxname.rx_alternate(ri);
   
end
% create new names
A = [MWTDB.strain MWTDB.rx];
MWTDB.groupname = strjoinrows(A,'_');

%% parse 
% NM1630_E3d12h400mM_R12h_T4d400mM
T = table;
T.groupname = MWTDB.groupname;
T.strain = MWTDB.strain;
T.rx = MWTDB.rx;

%% test conditions
rx = MWTDB.rx;
a = regexp(rx,'_','split');
[r,c] = cellfun(@size,a);
a = celltakeout(a);
% get last condition
b = cell(size(a,1),1);
for x = 1:size(a,1)
   b(x) = a(x,c(x)) ;
end
T.age_test = cellfun(@str2num,regexpcellout(b,'\d(?=(d))','match'));
T.dose_test = cellfun(@str2num,regexpcellout(b,'\d{1,}(?=(mM))','match'));

%% recovery condition
T.rec_hr = nan(size(T,1),1);
a = regexpcellout(rx,'(?<=([_]R))\d{1,}(?=d)','match');
a(cellfun(@isempty,a)) = {'NaN'};
a = cellfun(@str2num,a);
T.rec_hr(~isnan(a)) = a(~isnan(a)).*24;
a = regexpcellout(rx,'(?<=([_]R))\d{1,}(?=h)','match');
a(cellfun(@isempty,a)) = {'NaN'};
a = cellfun(@str2num,a);
T.rec_hr(~isnan(a)) = a(~isnan(a));
a = regexpcellout(rx,'[_]Rvaries');
T.rec_hr(a==1) = Inf;

%%

cd(pSave);
writetable(T,'rx_condition.csv')

return
%% treatment condition
%% delete recovery
a = regexp(rx,'_','split');
[r,c] = cellfun(@size,a);
a = celltakeout(a);

% a = regexpcellout(rx,'(?<=([_]R))\d{1,}(?=d)','match');

%%

MWTDB.expname(~cellfun(@isempty,a(:,5)))
%%















































