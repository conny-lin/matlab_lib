%% OBJECTIVE:
% - create statistics in Dance_DrunkMoves_RapidTolerance that can do percent
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);


strain = 'N2';
gname = sprintf('%s_E3d24h0mM_R1h_T4d0mM',strain);
%%
excludeMWT = {
    '20151220_181004'
    '20151228_163932'
    '20151228_174020'
    '20151228_165130'
    '20151228_175126'
    '20151228_171133'
    '20151228_180338'
    '20151228_172444'
    '20151228_162414'
    '20151228_165841'
    '20151228_173127'};


%% load database
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
load(pDB);
MWTDB = MWTDB.text;
e = unique(MWTDB.expname(ismember(MWTDB.groupname,gname)));
MWTDB(~ismember(MWTDB.expname,e),:) = [];
MWTDB(~ismember(MWTDB.strain,'N2'),:) = [];
MWTDB(ismember(MWTDB.groupname,{'N2_Test','N2_E3d24h0mM_R1h_T4d400mM','N2_E3d24h200mM_R1h_T4d400mM'}),:) = [];


pMWT = MWTDB.mwtpath;
fprintf('# of MWT: %d\n',numel(pMWT))
fprintf('\nexperiments:\n');
disp(char(unique(MWTDB.expname)))
fprintf('\ngroups:\n');
disp(char(unique(MWTDB.groupname)))


%% run dance
MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSave);





return



















