%% OBJECTIVE:
% - create a list of experiments relevant for rapid tolerance chapter
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load database
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
load(pDB);
MWTDB = MWTDB.text;

%% target list
explist = {
    '20130308C_BM_100s30x10s10s_10sISI_tolerance2'
    '20130315C_BM_100s30x10s10s_10sISI_tolerancefood'};
rclist = {
    '300s30x10s0s'
    '0s2x0s1320s'
    '300s0x0s0s'
    '3600s0x0s0s'
    '600s0x0s0s'
    '900s0x0s0s'};

%%
i = (ismember(MWTDB.rc, rclist) | ismember(MWTDB.expname, explist)) & ...
    ~ismember(MWTDB.expter,'SS') ...
    & ~ismember(MWTDB.groupname, {'N2_Test','N2_400mM_NoFood','N2_NoFood'});
MWTDB(~i,:) = [];

%%
unique(MWTDB.expter)
gn = unique(MWTDB.groupname);

%%
gn(regexpcellout(gn,'Food'))
return
%%
e = unique(MWTDB.expname(ismember(MWTDB.groupname,gname)));
MWTDB(~ismember(MWTDB.expname,e),:) = [];
MWTDB(~ismember(MWTDB.strain,'N2'),:) = [];
MWTDB(ismember(MWTDB.groupname,{'N2_Test','N2_E3d24h0mM_R1h_T4d400mM','N2_E3d24h200mM_R1h_T4d400mM'}),:) = [];


pMWT = MWTDB.mwtpath;
fprintf('# of MWT: %d\n',numel(pMWT))
fprintf('\nexperiments:\n');
disp(char(unique(MWTDB.expname)))
fprintf('\ngroups:\n');
disp(char(unique(MWTDB.groupname)))

% run dance
MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSave,'timeStartSet',60,'timeEndSet',120);



















%% look at curve and speed data by mwt and exp
close;
D = innerjoin(MWTSet.Info.MWTDB, MWTSet.Data_Plate);
D.speedb = D.speed./D.midline;
msrlist = {'curve','speed','kink','speedb'};

for msri = 1:numel(msrlist)
    msr = msrlist{msri};
    fig1 = clusterDotsErrorbar(D.(msr),D.groupname_short,...
        'visible','off','yname',msr,'xname','group','errorbartype','se',...
        'markersize',5,'fontsize',14)
    savefigtiffOnly(sprintf('%s',msr),pSave)
end

%% save 
cd(pSave);
writetable(D,'rawdata.csv');



%% create scatter plot for curve/speed

color = [0.8 0.8 0.8; 1 0 0; ...
    [0 0.447058826684952 0.74117648601532];...
    [0.494117647409439 0.184313729405403 0.556862771511078]];
gnames = unique(D.groupname_short);
close;
for gi = 1:numel(gnames)
    gn = gnames{gi};
    i = ismember(D.groupname_short, gn);
    x = D.speed(i);
    y = D.curve(i);
    c = color(gi,:);
    scatter(x,y,'MarkerFaceColor',c,'MarkerEdgeColor',c);
    hold on;
end

xlabel('speed');
ylabel('curve');

legend(gnames,'EdgeColor',[1 1 1])
savefigtiffOnly('scatter',pSave)

%% scatter speedb
color = [0.8 0.8 0.8; 1 0 0; ...
    [0 0.447058826684952 0.74117648601532];...
    [0.494117647409439 0.184313729405403 0.556862771511078]];
gnames = unique(D.groupname_short);
close;
for gi = 1:numel(gnames)
    gn = gnames{gi};
    i = ismember(D.groupname_short, gn);
    x = D.speedb(i);
    y = D.curve(i);
    c = color(gi,:);
    scatter(x,y,'MarkerFaceColor',c,'MarkerEdgeColor',c);
    hold on;
end

xlabel('speed');
ylabel('curve');

legend(gnames,'EdgeColor',[1 1 1])
savefigtiffOnly('scatter speedb',pSave)


%%  scatter plot for curve/speed - low N
nseq = [0 10:5:20];
for ni = 1:numel(nseq)
n = nseq(ni);
savename = sprintf('scatter_N>%d',n)
ival = D.goodnumber >n;

color = [0.8 0.8 0.8; 1 0 0; ...
    [0 0.447058826684952 0.74117648601532];...
    [0.494117647409439 0.184313729405403 0.556862771511078]];
gnames = unique(D.groupname_short);
close;
for gi = 1:numel(gnames)
    gn = gnames{gi};
    i = ismember(D.groupname_short, gn);
    x = D.speed(i & ival);
    y = D.curve(i & ival);
    c = color(gi,:);
    scatter(x,y,'MarkerFaceColor',c,'MarkerEdgeColor',c);
    hold on;
end

xlabel('speed');
ylabel('curve');
xlim([0 0.35])
ylim([0 45]);
legend(gnames,'EdgeColor',[1 1 1])
savefigtiffOnly(savename,pSave)
end

%%














