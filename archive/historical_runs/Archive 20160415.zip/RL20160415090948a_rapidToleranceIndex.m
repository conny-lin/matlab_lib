%% OBJECTIVE:
% - create statistics in Dance_DrunkMoves_RapidTolerance that can do percent
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',false);

%% load data
pData = '/Users/connylin/Dropbox/RL/Publication/PhD Dissertation/Chapters/5-Igor/3-Results/4-Rapid Tolerance/2-Strains/DA609/Dance_RapidTolerance';
cd(pData); load('Dance_RapidTolerance.mat');

return
%% strain list 
[~,~,strains,pst] = dircontent(fileparts(mfilename('fullpath')));
i = ismember(strains,'N2');
strains(i) = [];
pst(i) = [];

%% SEARCH
for si = 1:numel(strains)
    gname = sprintf('%s_E3d24h0mM_R1h_T4d0mM',strains{si});
    % LOAD MWT DATABASE
    pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
    load(pDB);
    MWTDB = MWTDB.text;
    e = unique(MWTDB.expname(ismember(MWTDB.groupname,gname)));
    MWTDB(~ismember(MWTDB.expname,e),:) = [];
    pMWT = MWTDB.mwtpath;
    fprintf('# of MWT: %d\n',numel(pMWT))
    fprintf('\nexperiments:\n');
    disp(char(unique(MWTDB.expname)))
    fprintf('\ngroups:\n');
    disp(char(unique(MWTDB.groupname)))
    % run dance
    MWTSet = Dance_RapidTolerance(pMWT,'pSave',pst{si});
    
    %%
    
    
    return
end





return



















