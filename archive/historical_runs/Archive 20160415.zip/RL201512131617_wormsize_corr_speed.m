%% see if worm area correlates with reversal speed

%% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;

%% var
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp';

%% calculate worm area for each plate
str = sprintf('%s/Dance_DrunkMoves/Dance_DrunkMoves.mat',pSaveHome);
load(str)
T = table;
% get only first time data
D = MWTSet.Data_Plate.area;
D(D.timeind == 2,:) = [];
% calculate worm area
T.mwtname = MWTSet.Info.VarIndex.mwtname(D.mwtname);
T.area = D.mean;
% calculate worm speed
D = MWTSet.Data_Plate.speed;
D(D.timeind == 2,:) = [];
T.speed = D.mean;

clear D;

%% get reversal speed
str = sprintf('%s/Dance_Glee_Preggers 201512121701/Dance_Glee_Preggers.mat',pSaveHome);
load(str)
T1 = table;
T1.mwtname = MWTSet.Data.trv.RevSpeed.mwtname';
d = MWTSet.Data.trv.RevSpeed.mean;
T1.RevSpeed = nanmean(d)';
d = MWTSet.Data.trv.RevFreq.mean;
T1.RevFreq = nanmean(d)';
d = MWTSet.Data.trv.RevDur.mean;
T1.RevDur = nanmean(d)';
%% join table
T2= innerjoin(T,T1);

%% scatter graphs
pSave = [pSaveHome,'/Speed Area corr'];
if isdir(pSave) == 0; mkdir(pSave); end
a = T2.Properties.VariableNames;
a(ismember(a,{'mwtname','area'})) = [];
ymsru = a;

for ymsri = 1:numel(ymsru)
    ymsr = ymsru{ymsri};
    
    X = T2.area;
    Y = T2.(ymsr);
    figure1 = figure;
    axes1 = axes('Parent',figure1);
    hold(axes1,'all');
    scatter(X,Y,'MarkerFaceColor',[0 0 0],'MarkerEdgeColor',[0 0 0]);
    xlabel('Area');
    ylabel(ymsr);
    titlename = sprintf('%s vs area',ymsr);
    savefigeps(titlename,pSave);
end




%% correlate stats
pSave = [pSaveHome,'/Speed Area corr'];
if isdir(pSave) == 0; mkdir(pSave); end
fid = fopen([pSave,'/pearson correlation.txt'],'w');
for ymsri = 1:numel(ymsru)
    ymsr = ymsru{ymsri};
    X = T2.area;
    Y = T2.(ymsr);
    [r,p] = corr(X,Y);
    df = numel(X) - 2;
    str = print_pvalue(p);
    fprintf(fid,'%s vs area: r(%d) = %.3f, %s\n',ymsr,df,r,str);
end
fclose(fid);











































