%% get Pregger graphs to see if speed var imporves after removing outlier

%% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;

%% var
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp';
programName = 'Dance_Glee_Preggers';

analysisNLimit = 0;
exp_exclusion = {};

%% load MWTset to find which mwtname has threhold lower than 0.6
% define thresholds
ythreshold = 0.6; % define y threshold
tthreshold = Inf; % define time threshold as all time points
msr = 'RevSpeed';
% load
str = sprintf('%s/Dance_Glee_Preggers Include/Dance_Glee_Preggers.mat',pSaveHome);
load(str);
a = MWTSet.Data.trv.(msr).mean;
% find plates over threshold
mwtname_exclude_threshold = MWTSet.Data.trv.(msr).mwtname(any(a > 0.6));

%% pull images of not drunk worms
% define variables
mwtname_bad = mwtname_exclude_threshold; % get bad mwt plate name
suffix = 'speed over point 6';
pSave = pSaveHome;
% get images
pImage = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp/plate image';
[f,p] = dircontent(pImage);
mwtname_image = regexpcellout(f,'\d{8}_\d{6}(?=[.]png)','match');
i = ismember(mwtname_image,mwtname_bad);
imageTarget = p(i);
imageTargetFileName = f(i);
pSaveA = sprintf('%s//plate image %s',pSave,suffix);
if isdir(pSaveA) == 0; mkdir(pSaveA); end
for x = 1:numel(imageTarget)
    ps = imageTarget{x};
    pd = [pSaveA,'/',imageTargetFileName{x}];
    copyfile(ps,pd);
end



%% get plate validation file and add more 
pf = sprintf('%s/mwt_summary included issues.csv',pSaveHome);
T = readtable(pf);
% exclude plates with no issues
T(cellfun(@isempty,T.issues),:) = [];

% issues excluding
issues_exclude = {'plate*wet'
'worm*clump'
'worm*curve_not_2SD_flatter_than_0mM_group'
'worm*look_drunk_but_is_0mM_group'
'worm*not_look_drunk_but_is_400mM_group'
'worm*too_many_small_worms'};

% % view unique issues
% issues = T.issues;
% issuesu = unique(issues);
% a = regexpcellout(issuesu,' ','split');
% a = reshape(a,numel(a),1);
% a(cellfun(@isempty,a)) = [];
% a = unique(a);
% get plate name with excluding issues
a = issues_exclude;
b = T.issues;
c = regexpcellout(b,' ','split');
c(cellfun(@isempty,c)) = {''};
val = false(size(b));
for x = 1:numel(a)
   str = regexprep(a{x},'*','[*]');
   for y = 1:size(c,2)
       i = ismember(c(:,y),a{x});
       if sum(i) > 0
        val(i) = true;
       end
   end
end

unique(b(val))
plate_issue_exclude = T.mwtname(val);

%% look if plates removed from speed has existing issues
pf = sprintf('%s/mwt_summary included issues.csv',pSaveHome);
T = readtable(pf);
a = T.issues(ismember(T.mwtname,mwtname_exclude_threshold));
fprintf('\nmwt with outlier speed existing issues:\n')
disp([mwtname_exclude_threshold' a])
    

%% get name and path of excluded
mwtname_exclude = [plate_issue_exclude;mwtname_exclude_threshold'];
i  = ismember(T.mwtname,mwtname_exclude);
mwtpath_exclude = T.mwtpath(i);
mwtpath_include = T.mwtpath(~i);
mwtname_exclude = T.mwtname(i);
mwtname_include = T.mwtname(~i);



%% run Preggers for excluded files
pMWT = mwtpath_exclude;
outputsuffix = 'Excluded';
% run
pSave = pSaveHome;
if isdir(pSave) == 0; mkdir(pSave); end
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Dance_Glee');
MWTSet = Dance_Glee_Preggers(pMWT,'pSave',pSave,'outputsuffix',outputsuffix,'saveimport',0);

% run Preggers for included files
pMWT = mwtpath_include;
outputsuffix = 'Include';
% run
pSave = pSaveHome;
if isdir(pSave) == 0; mkdir(pSave); end
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Dance_Glee');
MWTSet = Dance_Glee_Preggers(pMWT,'pSave',pSave,'outputsuffix',outputsuffix,'saveimport',0);



