%% see if worm area correlates with reversal speed

%% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;

%% var
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp';

%% calculate worm area for each plate
str = sprintf('%s/Dance_DrunkMoves/Dance_DrunkMoves.mat',pSaveHome);
load(str)
T = table;
% get only first time data
D = MWTSet.Data_Plate.area;
D(D.timeind == 2,:) = [];
% calculate worm area
T.mwtname = MWTSet.Info.VarIndex.mwtname(D.mwtname);
T.area = D.mean;
clear D;

%% get reversal speed
str = sprintf('%s/Dance_Glee_Preggers 201512121701/Dance_Glee_Preggers.mat',pSaveHome);
load(str)
d = MWTSet.Data.trv.RevSpeed.mean;
mwtname = MWTSet.Data.trv.RevSpeed.mwtname';
% get worm size per plate
[i,j] = ismember(mwtname,T.mwtname);
a = T.area(j(i));
d(:,~i) = [];
mwtname(~i) = [];
pMWT = MWTSet.Data.trv.RevSpeed.pMWT(i)';
%% repmat
b = repmat(a',size(d,1),1);
y = d./b;

%% errobar organize by group
pSave = [pSaveHome,'/Speed Area corr'];
if isdir(pSave) == 0; mkdir(pSave); end

A = parseMWTinfo(pMWT);
% calculate group mean
gnu = unique(A.groupname);
Y = nan(size(y,1),numel(gnu));
E = nan(size(y,1),numel(gnu));
Y1 = Y;
E1 = E;
for gi = 1:numel(gnu)
    gn = gnu{gi};
    i = ismember(A.groupname,gn);
    c = y(:,i)';
    m = nanmean(c);
    s = nanstd(c)./sqrt(sum(i)-1);
    Y(:,gi) = m;
    E(:,gi) = s;  
    u = d(:,i)';
    m = nanmean(u);
    s = nanstd(u)./sqrt(sum(i)-1);   
    Y1(:,gi) = m;
    E1(:,gi) = s;  
end

errorbar(Y,E)
savefigeps('RevSpeed calibrate to worm size',pSave);
errorbar(Y1,E1)
savefigeps('RevSpeed original',pSave);


%% errorbar SD
pSave = [pSaveHome,'/Speed Area corr'];
if isdir(pSave) == 0; mkdir(pSave); end

A = parseMWTinfo(pMWT);
% calculate group mean
gnu = unique(A.groupname);
Y = nan(size(y,1),numel(gnu));
E = nan(size(y,1),numel(gnu));
Y1 = Y;
E1 = E;
for gi = 1:numel(gnu)
    gn = gnu{gi};
    i = ismember(A.groupname,gn);
    c = y(:,i)';
    m = nanmean(c);
    s = nanstd(c);
    Y(:,gi) = m;
    E(:,gi) = s;  
    u = d(:,i)';
    m = nanmean(u);
    s = nanstd(u);   
    Y1(:,gi) = m;
    E1(:,gi) = s;  
end

errorbar(Y,E)
savefigeps('RevSpeed SD calibrate to worm size',pSave);
errorbar(Y1,E1)
savefigeps('RevSpeed SD original',pSave);



%% join table
T2= innerjoin(T,T1);



%% scatter graphs
pSave = [pSaveHome,'/Speed Area corr'];
if isdir(pSave) == 0; mkdir(pSave); end
a = T2.Properties.VariableNames;
a(ismember(a,{'mwtname','area'})) = [];
ymsru = a;

for ymsri = 1:numel(ymsru)
    ymsr = ymsru{ymsri};
    
    X = T2.area;
    Y = T2.(ymsr);
    figure1 = figure;
    axes1 = axes('Parent',figure1);
    hold(axes1,'all');
    scatter(X,Y,'MarkerFaceColor',[0 0 0],'MarkerEdgeColor',[0 0 0]);
    xlabel('Area');
    ylabel(ymsr);
    titlename = sprintf('%s vs area',ymsr);
    savefigeps(titlename,pSave);
end




%% correlate stats
pSave = [pSaveHome,'/Speed Area corr'];
if isdir(pSave) == 0; mkdir(pSave); end
fid = fopen([pSave,'/pearson correlation.txt'],'w');
for ymsri = 1:numel(ymsru)
    ymsr = ymsru{ymsri};
    X = T2.area;
    Y = T2.(ymsr);
    [r,p] = corr(X,Y);
    df = numel(X) - 2;
    str = print_pvalue(p);
    fprintf(fid,'%s vs area: r(%d) = %.3f, %s\n',ymsr,df,r,str);
end
fclose(fid);











































