%% run Dance_Glee_VitaminD on dose study
programName = 'Dance_Glee_VitaminD';
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI Dose Effect';

%% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;

%% get pMWT from a mwt summary file
% str = sprintf('%s/mwt_summary valid.csv',pSaveHome);
% T = readtable(str);
% pMWT = T.mwtpath;


%% get pMWT from querying database
pMWTDB = '/Users/connylin/Dropbox/RL/MWTDB';
load(sprintf('%s/MWTDB.mat',pMWTDB));
DB = MWTDB.text;
pMWT = DB.mwtpath(ismember(DB.expname,...
                        unique(DB.expname(ismember(DB.rc,'100s30x10s10s')...
                                & ismember(DB.groupname,{'N2_100mM','N2_500mM'})))));


%% run dance
pSave = pSaveHome;
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Dance_Glee');
MWTSet = Dance_Glee_VitaminD(pMWT,'analysisNLimit',20,'pSave',pSave,'saveimport',1,'GroupVar',{'groupname'});



return




