function [pSave] = setup_std(prgpath,wrkgrpname)



%% PATHS
pSave = prgpath;
if isdir(pSave) == 0; mkdir(pSave); end
% pSave = '/Users/connylin/Dropbox/rl/Publication/PhD Dissertation/Chapters/5-Rapid tolerance/Data/Rapid Tolerance/20160326';
pDepository = '/Users/connylin/Dropbox/Code/Matlab/Working Depository';

%% ADD FUNCTION PATH
switch wrkgrpname
    case 'RL'
        pFun = {'/Users/connylin/Dropbox/Code/Matlab/Library';
                '/Users/connylin/Dropbox/Code/Matlab/Library RL/Modules';
                '/Users/connylin/Dropbox/Code/Matlab/Library RL/Dance'};
end
addpath_allsubfolders(pFun);

% deposit current code
[~,fname] = fileparts(prgpath);
tstamp = generatetimestamp;
name = sprintf('%s/%s%sa_%s.m',pDepository,wrkgrpname,tstamp,fname);
copyfile([mfilename('fullpath'),'.m'],name);

% copy current code
copyfile(prgpath, [pSave,'/',fname,'_a',tstamp,'.m']);


