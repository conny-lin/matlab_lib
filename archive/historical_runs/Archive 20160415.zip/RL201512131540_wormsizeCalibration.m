%% run Dance_Glee_Acafellas

%% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;

% pHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/Recovery/Groups';
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp';
AfolderName = 'Dance_DrunkMoves';
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Dance_Glee');
analysisNLimit = 30;

%% get pMWT
str = sprintf('%s/%s/Dance_DrunkMoves.mat',pSaveHome,AfolderName);
load(str)

D = MWTSet.Data_Plate.area;
% get only first time data
D(D.timeind == 2,:) = [];

%% find threshold from visually inspected plate (not using this)
% % this plate visually is a good plate
% goodplate = '20120213_184953';
% goodplateind = find(strcmp(MWTSet.Info.VarIndex.mwtname, goodplate));
% % get good plate mean and SD
% i = D.mwtname == goodplateind;
% m = D.mean(i);
% s = D.SD(i);
% threshold_upper = m+(2*s);
% threshold_lower = m-(2*s);

%% find plates below and over threshold
% calculate 2SD for each plates
m = D.mean;
s = D.SD;
m1 = m+(s.*2);
m2 = m-(s.*2);
% calculate 2SD for all plates
m = mean(D.mean);
s = std(D.mean);
threshold_upper = m+(s.*2);
threshold_lower = m-(s.*2);
% find worms upper bound is still smaller than threshold lower
toosmall = D.mwtname(m1 < threshold_lower);
fprintf('too small: %d\n',numel(toosmall));
mwtname_toosmall = MWTSet.Info.VarIndex.mwtname(toosmall);
% find worms lower bound area bigger than upper threshold
toobig = D.mwtname(m2 > threshold_upper);
fprintf('too big: %d\n',numel(toobig));
mwtname_toobig = MWTSet.Info.VarIndex.mwtname(toobig);

%% pull plate images (too big)
% define variables
mwtname_bad = mwtname_toobig; % get bad mwt plate name
suffix = 'worm area 2SD above mean';
pSave = pSaveHome;
% get images
pImage = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp/plate image';
[f,p] = dircontent(pImage);
mwtname_image = regexpcellout(f,'\d{8}_\d{6}(?=[.]png)','match');
i = ismember(mwtname_image,mwtname_bad);
imageTarget = p(i);
imageTargetFileName = f(i);
pSaveA = sprintf('%s//plate image %s',pSave,suffix);
if isdir(pSaveA) == 0; mkdir(pSaveA); end
for x = 1:numel(imageTarget)
    ps = imageTarget{x};
    pd = [pSaveA,'/',imageTargetFileName{x}];
    copyfile(ps,pd);
end

% visual inspection note - plates seem to be closer to the camera


%% pull plate images (too small)
% define variables
mwtname_bad = mwtname_toosmall; % get bad mwt plate name
suffix = 'worm area 2SD below mean';
pSave = pSaveHome;
% get images
pImage = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp/plate image';
[f,p] = dircontent(pImage);
mwtname_image = regexpcellout(f,'\d{8}_\d{6}(?=[.]png)','match');
i = ismember(mwtname_image,mwtname_bad);
imageTarget = p(i);
imageTargetFileName = f(i);
pSaveA = sprintf('%s//plate image %s',pSave,suffix);
if isdir(pSaveA) == 0; mkdir(pSaveA); end
for x = 1:numel(imageTarget)
    ps = imageTarget{x};
    pd = [pSaveA,'/',imageTargetFileName{x}];
    copyfile(ps,pd);
end

% visual inspection note - all plates except for 20150410_164405 plate
% contained too many small worms in relation to adult worms. consider
% removeal



%% check if small worms are alrady excluded
mwtnameT = mwtname_toosmall(~ismember(mwtname_toosmall,'20150410_164405'));
str = sprintf('%s/Dance_Glee_Acafellas/mwt_summary included.csv',pSaveHome);
T = readtable(str);
i = ismember(mwtnameT,T.mwtname);
sum(i)
numel(i)













































