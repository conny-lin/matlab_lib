%% OBJECTIVE:
% - create statistics in Dance_DrunkMoves_RapidTolerance that can do percent
%% INITIALIZING
clc; clear; close all;
%% PATHS
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
pSave = mfilename('fullpath'); if isdir(pSave) == 0; mkdir(pSave); end
% pSave = '/Users/connylin/Dropbox/rl/Publication/PhD Dissertation/Chapters/5-Rapid tolerance/Data/Rapid Tolerance/20160326';
pDepository = '/Users/connylin/Dropbox/Code/Matlab/Working Depository';
%% ADD FUNCTION PATH
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pFun = {'/Users/connylin/Dropbox/Code/Matlab/Library';
        '/Users/connylin/Dropbox/Code/Matlab/Library RL/Modules';
        '/Users/connylin/Dropbox/Code/Matlab/Library RL/Dance'};
addpath_allsubfolders(pFun);
% deposit current code
name = sprintf('%s/RL%sa_%s.m',pDepository,generatetimestamp,mfilename);
copyfile([mfilename('fullpath'),'.m'],name);
% copy current code
copyfile([mfilename('fullpath'),'.m'],[pSave,'/',mfilename,'_a',generatetimestamp,'.m']);
% clear memory
clear pFun name
%% LOAD MWT DATABASE
load(pDB);
MWTDB = MWTDB.text;

%% SEARCH
i = ismember(MWTDB.groupname,{'RB1025_E3d24h0mM_R1h_T4d0mM'});
e = unique(MWTDB.expname(i));
MWTDB(~ismember(MWTDB.expname,e),:) = [];
pMWT = MWTDB.mwtpath;
fprintf('# of MWT: %d\n',numel(pMWT))
fprintf('\nexperiments:\n');
disp(char(unique(MWTDB.expname)))
fprintf('\ngroups:\n');
disp(char(unique(MWTDB.groupname)))



%% run dance
MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSave);



return



















