%% run Dance_Glee_Acafellas

%% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;

programName = 'Dance_Glee_Acafellas';
% pHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/Recovery/Groups';
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp';

addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Dance_Glee');
analysisNLimit = 30;

%% get pMWT
str = sprintf('%s/Dance_Glee_Preggers Include RevDur/mwt_summary included.csv',pSaveHome);
T = readtable(str);
pMWT = T.mwtpath;

%% run dance
pSave = pSaveHome;
MWTSet = Dance_Glee_Acafellas(pMWT,'analysisNLimit',analysisNLimit,'pSave',pSave);



return




