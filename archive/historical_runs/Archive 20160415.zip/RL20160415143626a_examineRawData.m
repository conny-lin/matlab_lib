%% OBJECTIVE:
% - create statistics in Dance_DrunkMoves_RapidTolerance that can do percent
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% get rapid tolerance data
cd([fileparts(pSave),'/Dance-RapidTolerance']);
load('Dance_RapidTolerance')

















