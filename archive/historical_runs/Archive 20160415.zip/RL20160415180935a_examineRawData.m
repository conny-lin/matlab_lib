%% OBJECTIVE:
% - create statistics in Dance_DrunkMoves_RapidTolerance that can do percent
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% get rapid tolerance data
cd([fileparts(pSave),'/Dance_RapidTolerance']);
load('Dance_RapidTolerance')

%% run individual worm chor
strainName = 'DA609';
gname = sprintf('%s_E3d24h0mM_R1h_T4d0mM',strainName);
% LOAD MWT DATABASE
load('/Volumes/COBOLT/MWT/MWTDB.mat');
MWTDB = MWTDB.text;
e = unique(MWTDB.expname(ismember(MWTDB.groupname,gname)));
MWTDB(~ismember(MWTDB.expname,e),:) = [];
pMWT = MWTDB.mwtpath;
fprintf('# of MWT: %d\n',numel(pMWT))
fprintf('\nexperiments:\n');
disp(char(unique(MWTDB.expname)))
fprintf('\ngroups:\n');
disp(char(unique(MWTDB.groupname)));

%% get paths
[PathData,pMWTp] = getpath2chorfile(pMWT,'Gangnam.mat');
MWTDB = parseMWTinfo(pMWTp); % update MWTDB
pMWT = MWTDB.mwtpath;
% parse rapid tolerance name
MWTDB = parseToleranceName(MWTDB);


%% speed distribution
load legend_gangnam;
msr = 'speed';
msrind = find(ismember(legend_gangnam,msr));

%% load data
dfac = 0.0005;
timestepx = (0:dfac:1.5)';
A = nan(numel(timestepx),numel(PathData));
for mwti = 1:numel(PathData)
    pf = PathData{mwti};
    D = load(pf);
    Data = cell2mat(D.Data);
    d = Data(:,msrind);
    
    d(isnan(d)) = [];
    d1 = round(d./dfac).*dfac;
    a = tabulate(d1);
    i = a(:,1)>max(timestepx);
    n = sum(i);
    if n>0
       timestepx = [timestepx;a(i,1)];
       A = [A;nan(n,numel(PathData))];
    end
    [i,j] = ismember(timestepx,a(:,1));
    A(i,mwti) = a(j(i),3);
end
clear D;

%% by group summarize
grp = MWTDB.groupname_short;
gnu = unique(grp);
gnu = [gnu(regexpcellout(gnu,'N2'));gnu(~regexpcellout(gnu,'N2'))];
Mean = nan(numel(timestepx),numel(gnu));
SE = Mean;
N = Mean;

for gi = 1:numel(gnu)
    i = ismember(MWTDB.groupname_short,gnu(gi));
    A1 = A(:,i);
    Mean(:,gi) = nanmean(A1,2);
    n = sum(~isnan(A1),2);
    sd = nanstd(A1')';
    ns = sqrt(n-1);
    ns(n==0)=0;
    SE(:,gi) = sd./ns;    
end

T = table;
T.(msr) = timestepx;
T = [T array2table(Mean) array2table(SE)];
writetable(T,sprintf('%s/%s prob density.csv',pSave,msr));


%% plot
display 'plotting';
close;
color  = repmat({'k','r',[0.5 0.5 0.5],'m'},1,2);

X = repmat(T.(msr),1,size(Mean,2));
figure1 = figure('Visible','on');
hold on;
plot1 = plot(X,Mean,'LineStyle','none','MarkerSize',4);

for x = 1:size(Mean,2)
    if regexp(gnu{x},'N2'); marker = 'o'; else marker = 'x'; end
    set(plot1(x),'DisplayName',gnu{x},'Color',color{x},'Marker',marker) 
end
xlim([0 0.4])
legend('show');
ylabel('prob density')
xlabel(msr)
savefigtiffOnly(sprintf('%s prob density',msr),pSave)



%% save each group separately
mwtname = strjoinrows([cellfunexpr(MWTDB.mwtname,'m') regexprep(MWTDB.mwtname,'_','')],'');
for gi = 1:numel(gnu)
   i = ismember(MWTDB.groupname_short,gnu(gi));
   B = table;
   B.(msr) = timestep
   d = A(:,i);
   name = mwtname(i);
   T = array2table(d,'VariableNames',name);
   T = [B T];
   writetable(T,sprintf('%s/%s %s.csv',pSave,msr,gnu{gi}));
   
   % plot
   
   
   return
   
end











































