%% OBJECTIVE:
% - create a list of experiments relevant for rapid tolerance chapter
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load database
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
load(pDB);
MWTDB = MWTDB.text;

%% target list
explist = {
    '20130308C_BM_100s30x10s10s_10sISI_tolerance2'
    '20130315C_BM_100s30x10s10s_10sISI_tolerancefood'};
rclist = {
    '300s30x10s0s'
    '0s2x0s1320s'
    '300s0x0s0s'
    '3600s0x0s0s'
    '600s0x0s0s'
    '900s0x0s0s'};

%% query
i = (ismember(MWTDB.rc, rclist) | ismember(MWTDB.expname, explist)) & ...
    ~ismember(MWTDB.expter,'SS') ...
    & ~ismember(MWTDB.groupname, {'N2_Test','N2_400mM_NoFood','N2_NoFood'});
MWTDB(~i,:) = [];

%% summary
expu = unique(MWTDB.expname);
T = table;
for ei = 1:numel(expu)
    Db = MWTDB(ismember(MWTDB.expname,expu(ei)),:);
    a = tabulate(Db.groupname);
    n = size(a,1);
    b = repmat(expu(ei),n,1);
    t = table;
    t.expname = b;
    t.groupname = a(:,1);
    t.plateN = cell2mat(a(:,2));
    T = [T;t];
    
end


%% parse rx
fG = T.groupname;
T.strain = regexpcellout(fG,'\<[A-Z]{1,}\d{1,}','match');
a = regexpcellout(fG,'_','split');
T.rx = regexpcellout(fG,'(?<=\<[A-Z]{1,}\d{1,}_)\w{1,}','match');
T.rx(cellfun(@isempty,T.rx)) = {'NA'};
a = regexpcellout(T.expname,'_','split');
T.rc = a(:,3);

%% change to group name alternate
cd(fileparts(pSave));
rxname = readtable('rxname_alternate.csv');
rxname.rx_alternate
%%
for ri =1:size(rxname,1)
    i= ismember(MWTDB.rx,rxname.rx(ri));
    MWTDB.rx(i) = rxname.rx_alternate(ri);
   
end
% create new names
A = [MWTDB.strain MWTDB.rx];
MWTDB.groupname = strjoinrows(A,'_');

unique(MWTDB.groupname)


%% 


return
%%
cd(pSave);
writetable(T,'expsum.csv');
return














