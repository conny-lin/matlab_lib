%% OBJECTIVE:
% - create a list of experiments relevant for rapid tolerance chapter
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load database
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
load(pDB);
MWTDB = MWTDB.text;

%% target list
explist = {
    '20130308C_BM_100s30x10s10s_10sISI_tolerance2'
    '20130315C_BM_100s30x10s10s_10sISI_tolerancefood'};
rclist = {'300s30x10s0s'};

%% query
i = (ismember(MWTDB.rc, rclist) | ismember(MWTDB.expname, explist)) & ...
    ~ismember(MWTDB.expter,'SS') ...
    & ~ismember(MWTDB.groupname, {'N2_Test','N2_400mM_NoFood','N2_NoFood'});
MWTDB(~i,:) = [];
unique(MWTDB.groupname)















































