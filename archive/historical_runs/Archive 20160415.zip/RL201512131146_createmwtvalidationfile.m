%% run Dance_Glee_Preggers
% add fun path
addpath('/Users/connylin/Dropbox/RL/Code/Modules/Dance/Modules');
PATH = DanceM_funpath;


%% variables definition
pSaveHome = '/Users/connylin/Dropbox/RL/PhD/Chapters/2-STH N2/Data/10sISI/1-All Exp';
programName = 'Dance_Glee_Preggers';
analysisNLimit = 0;
exp_exclusion = {};


%% get plate validation file and add more 
cd(pSaveHome)
[~, ~, A] = xlsread(sprintf('%s/mwt_summary included.xlsx',pSaveHome),...
    'mwt_summary included.csv');
A = A(2:end,:);
A(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),A)) = {''};
% convert to table
A = cell2table(A,'VariableNames',{'mwtpath','expname','groupname','mwtname','issues','drunk_status','decision','curve_status','note'});
%% consolidate issues
issues = A.issues;

% corrections
issues = regexprep(issues,'wet plate','plate*wet');
issues = regexprep(issues,'e coli uneven color|e coli color uneven','ecoli*color_uneven');
issues(ismember(issues,'small dot contamination')) = {'contamination*small_dot'};
issues(ismember(issues,'contamination')) = {'contamination*'};
issues(ismember(issues,'contamination ecoli*color_uneven')) = {'contamination* ecoli*color_uneven'};
issues = regexprep(issues,'large black dot','contamination*large_black_dot');

issues = regexprep(issues,'glitched frame','image*glitch');
issues = regexprep(issues,'fuzzy','image*focus_fuzzy');
issues = regexprep(issues,'too bright','image*light_too_bright');
issues = regexprep(issues,'background light uneven|uneven light','image*light_uneven');

issues = regexprep(issues,'large crystals','agar*crystals_large');
issues(ismember(issues,'crystals')) = {'agar*crystals'};
issues = regexprep(issues,'too small|mostly small worms','worm*too_many_small_worms');
issues = regexprep(issues,'worms clumping|worms clump|some clumping','worm*clump');
issues = regexprep(issues,'looks like 400mM worms|looks like drunk worm|suspect to be 400mM','worm*look_drunk_but_is_0mM_group');
issues = regexprep(issues,' and ',' ');
issues = regexprep(issues,' is npr1 exp','');
issues = regexprep(issues,' maybe is npr-1 check','');
issues = regexprep(issues,'only about 10 worms','worm*lowN');

%% consolidate drunk_status
drunk = A.drunk_status;
drunk = regexprep(drunk,'not very drunk','worm*not_look_drunk_but_is_400mM_group');
unique(drunk)

%% consolidate curve
cur = A.curve_status;
cur = regexprep(cur,'same as N2','worm*curve_not_2SD_flatter_than_0mM_group');
unique(cur)

%% consolidate note (nothing)
n = A.note;
% cur = regexprep(cur,'same as N2','worm*curve_not_2SD_flatter_than_0mM_group');
unique(n)

%% consolidate issues with drunk_status and curve
b = cell(size(A,1),1);
for x = 1:size(A,1)
    a = [issues(x) drunk(x) cur(x)];
    a(cellfun(@isempty,a)) = [];
    b{x} = strjoin(a,' ');
end

%% make new table
T = table;
fn = {'mwtpath' 'expname' 'groupname' 'mwtname' 'issues'};
for x = 1:numel(fn)
    T.(fn{x}) = A.(fn{x});
end
T.issues = b;

str = sprintf('%s/mwt_summary included issues.csv',pSaveHome);
writetable(T,str)



%% create list
f = unique(issues);
a = regexpcellout(f,' ','split');
a = reshape(a,numel(a),1);
a(cellfun(@isempty,a))  = [];
issue_list = unique(a);

a = issue_list;
a = regexpcellout(a,'*','split');
a = unique(a(:,1));
issue_category = a;

%% save this in MWTDB
p = PATH.pMWTDB;
fname = sprintf('%s/MWTDB_issue.mat',p);
save(fname,'issue_list','issue_category');








