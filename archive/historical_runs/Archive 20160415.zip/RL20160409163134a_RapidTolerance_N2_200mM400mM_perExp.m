%% OBJECTIVE:
% - create a list of experiments relevant for rapid tolerance chapter
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load database
pDB = '/Volumes/COBOLT/MWT/MWTDB.mat';
load(pDB);
MWTDB = MWTDB.text;


%% Igor exp standard 
explist = {
    '20130308C_BM_100s30x10s10s_10sISI_tolerance2'
    '20130315C_BM_100s30x10s10s_10sISI_tolerancefood'};
rclist = {'300s30x10s0s' '0s2x0s1320s' '300s0x0s0s' '3600s0x0s0s',...
    '600s0x0s0s' '900s0x0s0s'};
% query
i = (ismember(MWTDB.rc, rclist) | ismember(MWTDB.expname, explist)) & ...
    ~ismember(MWTDB.expter,'SS') ...
    & ~ismember(MWTDB.groupname, {'N2_Test','N2_400mM_NoFood','N2_NoFood'});
MWTDB(~i,:) = [];
% change to group name alternate for igor
MWTDB = rxname_add2MWTDB(MWTDB);

%% additional query
MWTDB(~ismember(MWTDB.strain, 'N2'),:) = []; % strain
MWTDB(~ismember(MWTDB.rc,{'300s30x10s0s'}),:) = []; % rc
% MWTDB(~(MWTDB.dose_rx==0 |isnan(MWTDB.dose_rx)) ,:) = []; % rx dose = 0
% MWTDB(MWTDB.dose_test==400,:) = []; % test dose = 0 or none
MWTDB(~ismember(MWTDB.rec_hr,1),:) = [];

% report
tabulate(MWTDB.groupname)
char(unique(MWTDB.expname))

%% repeat by exp
enu = unique(MWTDB.expname);
for ei = 1:numel(enu)
    i = ismember(MWTDB.expname,exnu(ei));
    

    %% run Dance
    pMWT = MWTDB.mwtpath(i);
    pSaveA = sprintf('%s/%s',enu{ei}); if isdir(pSaveA)==0; mkdir(pSaveA); end
    MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSaveA);


    %% save exp sum
    saveGroupExpPlateN(MWTDB,pSaveA)

end
return










