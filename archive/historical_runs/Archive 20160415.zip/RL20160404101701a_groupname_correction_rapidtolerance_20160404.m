%% INFORMATION:
% start time stamp: 201604040851
% objecitve:
%     - correct group name after evaluating rapid tolerance exp list
%     - make sure MWTDB updates are archived

%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% groupname change
% load alternate names
cd(fileparts(pSave))
T = readtable('groupname_alternate.csv');
gntarget = {'T4dxh0mM_T5d0mM' 'T4dxh400mM_T5d0mM' '400mM_400mM'};
T(~ismember(T.groupname,gntarget),:) = [];


%% find paths to files for name change
pData = '/Volumes/COBOLT/MWT';
% load database
load('/Volumes/COBOLT/MWT/MWTDB.mat');
MWTDB = MWTDB.text;
i = ismember(MWTDB.rx,T.groupname);
MWTDB(~i,:) = [];
pMWT = MWTDB.mwtpath;

%% make sure same names are found in zip archive
pZipArchive = '/Volumes/IRONMAN/RL_MWT_Data_Zip';
a = regexprep(pMWT,pData,pZipArchive);
for mwti = 1:numel(pMWT)
    p = a{mwti};
    [pf,fn] = fileparts(p);
    f = dircontent(pf,[fn,'.zip']);
    if isempty(f)
        disp(p)
        error('no zip file')
    end
end

%% combine strain name with new rx name
[i,j] = ismember(MWTDB.rx,T.groupname);
newrx = T.groupname_alternate(j(i));
A = [MWTDB.strain newrx];
groupname_new = strjoinrows(A,'_');

%% make new paths
pMWTnew = cell(size(pMWT));
for mwti = 1:numel(pMWT)
   pmwt = pMWT{mwti};
   pMWTnew{mwti} = regexprep(pmwt,MWTDB.groupname{mwti},groupname_new{mwti});
end
a = parseMWTinfo(pMWTnew);

%% get new group folder name
pGold = cellfun(@fileparts,pMWT,'UniformOutput',0);
pGnew = cellfun(@fileparts,pMWTnew,'UniformOutput',0);



%% change group folder name
for gi = 1:numel(pGold)
    ps = pGold{gi};
    pd = pGnew{gi};
    if isdir(ps)==1
        movefile(ps,pd,'f')
    end

end


return


























