%% INFORMATION:
% start time stamp: 201604040851
% objecitve:
%     - correct group name after evaluating rapid tolerance exp list
%     - make sure MWTDB updates are archived

%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% groupname change
% load alternate names
cd(fileparts(pSave))
T = readtable('groupname_alternate.csv');
gntarget = {'T4dxh0mM_T5d0mM' 'T4dxh400mM_T5d0mM' '400mM_400mM'};
T(~ismember(T.groupname,gntarget),:) = [];


%% find paths to files for name change
pData = '/Volumes/COBOLT/MWT';
% load database
load('/Volumes/COBOLT/MWT/MWTDB.mat');
MWTDB = MWTDB.text;
i = ismember(MWTDB.rx,T.groupname);
MWTDB(~i,:) = [];
pMWT = MWTDB.mwtpath;



%% combine strain name with new rx name
[i,j] = ismember(MWTDB.rx,T.groupname);
newrx = T.groupname_alternate(j(i));
A = [MWTDB.strain newrx];
groupname_new = strjoinrows(A,'_');

%% make new paths
pMWTnew = cell(size(pMWT));
for mwti = 1:numel(pMWT)
   pmwt = pMWT{mwti};
   pMWTnew{mwti} = regexprep(pmwt,MWTDB.groupname{mwti},groupname_new{mwti});
end
a = parseMWTinfo(pMWTnew);

%% get new group folder name
pGnew = cellfun(@fileparts,pMWTnew,'UniformOutput',0);
pGold = cellfun(@fileparts,pMWT,'UniformOutput',0);
[unique(pGold) unique(pGnew)]

%% make sure same names are found in zip archive
pZipArchive = '/Volumes/IRONMAN/RL_MWT_Data_Zip';
a = regexprep(pMWT,pData,pZipArchive);
for mwti = 1:numel(pMWT)
    p = a{mwti};
    [pf,fn] = fileparts(p);
    f = dircontent(pf,[fn,'.zip']);
    if isempty(f)
        disp(p)
        error('no zip file')
    end
end


%%

% movefile(ps,pd,'f')


return


%% change name in MWT database
pData = '/Volumes/COBOLT/MWT';

%% 
% archive MWTDB
% run new MWTDB
%% change group name in MWTDB
% change group name folder in ironman



%% target list (rapid tolerance)
explist = {
    '20130308C_BM_100s30x10s10s_10sISI_tolerance2'
    '20130315C_BM_100s30x10s10s_10sISI_tolerancefood'};
rclist = {
    '300s30x10s0s'
    '0s2x0s1320s'
    '300s0x0s0s'
    '3600s0x0s0s'
    '600s0x0s0s'
    '900s0x0s0s'};



%% query
i = (ismember(MWTDB.rc, rclist) | ismember(MWTDB.expname, explist)) & ...
    ~ismember(MWTDB.expter,'SS') ...
    & ~ismember(MWTDB.groupname, {'N2_Test','N2_400mM_NoFood','N2_NoFood'});
MWTDB(~i,:) = [];

%% summary
expu = unique(MWTDB.expname);
T = table;
for ei = 1:numel(expu)
    Db = MWTDB(ismember(MWTDB.expname,expu(ei)),:);
    a = tabulate(Db.groupname);
    n = size(a,1);
    b = repmat(expu(ei),n,1);
    t = table;
    t.expname = b;
    t.groupname = a(:,1);
    t.plateN = cell2mat(a(:,2));
    T = [T;t];
    
end

%% parse rx
fG = T.groupname;
T.strain = regexpcellout(fG,'\<[A-Z]{1,}\d{1,}','match');
a = regexpcellout(fG,'_','split');
T.rx = regexpcellout(fG,'(?<=\<[A-Z]{1,}\d{1,}_)\w{1,}','match');
T.rx(cellfun(@isempty,T.rx)) = {'NA'};
a = regexpcellout(T.expname,'_','split');
T.rc = a(:,3)


%%
cd(pSave);
writetable(T,'expsum.csv');
return














