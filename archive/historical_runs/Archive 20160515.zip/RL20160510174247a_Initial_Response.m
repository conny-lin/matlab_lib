%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% SETTING
msrlist = {'RevFreq','RevDur','RevSpeed'};

%% get strain names
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
a = dircontent(pDataHome);
a(ismember(a,'0-Code')) = [];
strainlist  = a;
strainlist(~ismember(strainlist,{'BZ142'})) = [];


%% MWTDB - get all paths
MWTDBM = load('/Volumes/COBOLT/MWT/MWTDB.mat'); MWTDBM = MWTDBM.MWTDB.text; 
% restrict master database
MWTDBM(~ismember(MWTDBM.rc, '100s30x10s10s'),:) = [];

%% create output table 
% create col name
a = {'N2','N2_400mM','Mut','Mut_400mM'}';
colNames = [a', strjoinrows([a, cellfunexpr(a,'_SE')],'')', ...
    strjoinrows([a, cellfunexpr(a,'_N')],'')'];
a = nan(numel(strainlist),numel(colNames));
% T = array2table(a,'VariableNames',colNames);
% T.strain = cell(numel(strainlist),1);

R = struct;
for msri=1:numel(msrlist)
   R.(msrlist{msri}) = a; 
end



%% get intial response table
for si = 1:numel(strainlist)
    %% get strain info
    strain = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strain);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);
    
    %% load Dance data
    p  = sprintf('%s/Dance_Glee/Dance_ShaneSpark3.mat',pSave);
    if ~exist(p,'file'); error('no file exist'); end
    load(p);
    
    %% validate data the same as current MWTDB
    MWTDB = parseMWTinfo(MWTSet.Data.Import.mwtpath); % rebuilt database
    [i,j] = ismember(MWTDB.mwtname, MWTDBM.mwtname);
    if sum(~i) > 0; error('some missing files'); end
    gnM = MWTDBM.groupname(j(i));
    gnD = MWTDB.groupname;
    if ~isequal(gnM,gnD); error('some group names do not match'); end
    
    %% see if more data available in MWTDBM
    rgroup = {strain,[strain,'_400mM']};
    cgroup = {'N2','N2_400mM'};
    DbT = MWTDBquery_grpInSameExp(MWTDBM,rgroup,cgroup);
    a = size(DbT,1); b = size(MWTDB,1);
    if a > b
        error('more data in database'); 
    elseif a == b
        display('same data size as in database');
    elseif a < b
        error('more data in data than database');
    end
    
    %% get group name
    groupName = output_sortN2first(unique(DbT.groupname));
    if numel(groupName)~=4 || ~isequal(groupName, [cgroup rgroup]')
        error('wrong group name');
    end
    
    %% get intial data
    for msri = 1:numel(msrlist)
        msr = msrlist{msri};
        gn = MWTSet.Graph.Initial.(msr).GroupName;
        y = MWTSet.Graph.Initial.(msr).Y;
        n = MWTSet.Graph.Initial.(msr).N;
        e = MWTSet.Graph.Initial.(msr).E;
        [~,ind] = output_sortN2first(gn);
        if ~issorted(ind)
            a = [y,e,n];
            a = a(ind,:);
            a = reshape(a,1,numel(a));
        else
            a = [y',e',n'];
        end
        R.(msr).strain = strain;
        for x = 2:numel(colNames)
            R.(msr)(si,x) = a(x-1);
        end
        
        
    end
    
   
    
end















































