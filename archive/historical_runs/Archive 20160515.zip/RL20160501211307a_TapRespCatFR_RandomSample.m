%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);
pData = fileparts(pSave);
          
            
%% load data
cd(pData); load('data','Data2','MWTDB');

%% get group
[i,j] = ismember(Data2.mwtid,MWTDB.mwtid);
Data2.dose = MWTDB.dose_test(j(i));
Data2.timer = floor(Data2.time);

%% get data for each time
t = Data2.timer;
t1 = (t- (floor(t./10).*10));
D = Data2(t1<=1,:);
% adjust time
for t1 = [100 110 120]
    D.timer(ismember(D.timer,t1+1)) = t1;
end
for t1 = [240 370]
    D.timer(ismember(D.timer,[t1+1:10:(t1+1)+20 t1+10 t1+20])) = t1;
end

clear Data2

%% get N
a = tabulate(D.dose);
T = table;
T.dose = a(:,1);
T.N = a(:,2);
cd(pSave); writetable(T,'N.csv');
N = T.N;

%% get index to dose
doseu = unique(D.dose)';
doseind = cell(size(doseu));
n = 1;
for dose = doseu
    doseind{n} = find(D.dose==dose);
    n=n+1; 
end

%% get pauses % comparison
rown = 1; repeatN = 30; sampleN = 100;
for dose = doseu
    ind = doseind{rown};
    D1 = D(ind,:);
    for ri = 1:repeatN
        k = randi(n,100,1);
        d = D1.velocityc(k);
        dose
        n1 = sum(d==0)
        n1./sampleN
        
        return
        [tb,ch,p,lb] = crosstab(D1.dose,D1.timer);

        N = sum(tb,2);
        pct = tb./repmat(N,1,size(tb,2));

        t = pct;
        t = array2table(t);
        T1 = table;
        T1.dose = lb(:,1);
        T1 = [T1 t];
    end
    return
    %%
    plot(pct')



    %%
    rm = fitrm(D,'t10-t30~strain');
    ranovatbl = ranova(rm);
    anovatxt = anovan_textresult(ranovatbl,0);

end




































