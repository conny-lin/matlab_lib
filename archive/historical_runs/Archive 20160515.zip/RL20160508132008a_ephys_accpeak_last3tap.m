%% Questions to answer
% 1-sample size (how many worms, valid worms)
% 2-did accpeak occur in alcohol condition? in 0mM condition?
% 3-if accpeak exist, whats the 
%     peak time
%     peak height
%     peak width
% 4 - statistics
%     is the peak 


%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);


%% SETTING
pSF = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Results/Data/10sISI/by strains/';

strainlist = dircontent(pSF);
strainlist(ismember(strainlist,'0-Code')) = [];

%% load data
for si =1:numel(strainlist)
    strain = strainlist(si);
    pData = sprintf('%s/%s',pSF,strain);
    load([pData,'/data_ephys_t28_30.mat']);
    pSave = sprintf('%s/ephys graph',pData); if ~isdir(pSave); mkdir(pSave); end


    [Stats, DataG] = ephys_stats(DataG,pSave);
    ephys_randomSample(DataG,pSave)
end




























    
    
    
    
    
    
    
    
    
    
    
    