%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);


%% SETTING
pSF = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Results/Data/10sISI/by strains/';

strainlist = dircontent(pSF);
strainlist(ismember(strainlist,'0-Code')) = [];

%%

for si =1:numel(strainlist)
    
    strain = strainlist{si};
    fprintf('%d/%d: %s\n',si, numel(strainlist), strain);
    pG = sprintf('%s/%s/ephys graph/ephys t28-30.pdf',pSF,strain);
    pd = sprintf('%s/%s ephys t28-30.pdf',pM,strain);
    copyfile(pG,pd);
    
    pF = sprintf('%s/%s/ephys graph/ephys t28_30 MANOVA.txt',pSF,strain);
    pd = sprintf('%s/%s ephys t28_30 MANOVA.txt',pM,strain);
    copyfile(pF,pd);
    
    pF = sprintf('%s/%s/ephys graph/ephys t28_30.csv',pSF,strain);
    pd = sprintf('%s/%s ephys t28_30.csv',pM,strain);
    copyfile(pF,pd);
end
