%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);

%% combine data
cd(pSave); load data


%% standardize time
Time1 = Time(:,1:end-1);
Timerd = round(Time1.*10)./10;
% adjust all to start with same number
adjm = nan(size(Timerd,1),1);
t1 = Timerd(:,1);
adjm(t1<=99) = 98;
adjm(t1<=239 & t1> 99) = 238;
adjm(t1<=369 & t1 >239) = 368;
adjm1 = t1-adjm;
a = repmat(adjm1,1,size(Time1,2));
TimeStd= Timerd - a;

%%
doseu = unique(MWTDB.dose_test);
timeu = unique(TimeStd(:,1));
for dosei = 1:numel(doseu)
for timei = 1:numel(timeu)
    i = TimeStd(:,1)==timeu(timei) & MWTDB.dose_test == doseu(dosei);
    D = Data(i,:);
    
    return
    
    return
    
    
    
    
    
end
end



return



































