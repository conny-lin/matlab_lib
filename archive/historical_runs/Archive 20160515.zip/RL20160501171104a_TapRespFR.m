%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);

%% load data
cd(pSave); load data


%% standardize time
Time1 = Time(:,1:end-1);
Timerd = round(Time1.*10)./10;
% adjust all to start with same number
adjm = nan(size(Timerd,1),1);
t1 = Timerd(:,1);
adjm(t1<=99) = 98;
adjm(t1<=239 & t1> 99) = 238;
adjm(t1<=369 & t1 >239) = 368;
adjm1 = t1-adjm;
a = repmat(adjm1,1,size(Time1,2));
TimeStd= Timerd - a;

%%
colorset = [[0.0784313753247261 0.168627455830574 0.549019634723663];
    [0.635294139385223 0.0784313753247261 0.184313729405403]];

doseu = unique(MWTDB.dose_test);
timeu = unique(TimeStd(:,1));
for dosei = 1:numel(doseu)
for timei = 1:numel(timeu)
    t = timeu(timei);
    i = TimeStd(:,1)==t & MWTDB.dose_test == doseu(dosei);
    % get forward
    F = Data(i,:);
    F(F<=0.014) = nan; 
    mF = nanmean(F);
    time = TimeStd(i,:);
    xF = time(1,:);
    sdF = nanstd(F);
    nF = sum(~isnan(F));
    seF = sdF./sqrt(nF-1);
    % reverse
    R = Data(i,:);
    R(R>=-0.014) = nan; 
    mR = nanmean(R);
    time = TimeStd(i,:);
    xR = time(1,:);
    sdR = nanstd(R);
    nR = sum(~isnan(R));
    seR = sdR./sqrt(nR-1);
    
    % make errorbar
    figure('Visible','off');
    e1 = errorbar([xF;xR]',[mF;mR]',[seF;seR]','MarkerSize',2,...
        'Marker','o','LineStyle','-');
    for xi = 1:2
        c = colorset(xi,:);
        set(e1(xi), 'DisplayName','F',...
        'MarkerFaceColor',c,...
        'MarkerEdgeColor',c,...
        'Color',c);
    end
    
    name = sprintf('%dmM t%d',doseu(dosei),timeu(timei));
    title(name)
    savefigtiffOnly(name,pSave)
    
    

    
    
    
end
end








































