%% save MWTinfo in data folder using ephys record

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
% pSave = fileparts(pM);


%% get strain names
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
a = dircontent(pDataHome);
a(ismember(a,'0-Code')) = [];
strainlist  = a;
strainlist(~ismember(strainlist,{'VG202'})) = [];



%% MWTDB - get all paths
% MWTDB = load('/Volumes/COBOLT/MWT/MWTDB.mat');
% MWTDBMaster = MWTDB.MWTDB.text; clear MWTDB;
    
%% run data for all strains


for si = 1:numel(strainlist)
    %% create save folder
    strain = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strain);
    cd(pSave); load('data_ephys_t28_30.mat','MWTDB');
    
    cd(pSave); save('MWTDB.mat','MWTDB');
    
end
%     
%     fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);
%     
%     i = MWTDBMaster.ISI == 10 ...
%         & MWTDBMaster.preplate == preplate ...
%         & MWTDBMaster.tapN == 30 ...
%         & ismember(MWTDBMaster.groupname,sprintf('%s_400mM',strain));
%     exp = unique(MWTDBMaster.expname(i));
% 
%     MWTDB = MWTDBMaster(ismember(MWTDBMaster.expname,exp),:);
%     MWTDB(~ismember(MWTDB.groupname,{'N2','N2_400mM',strain,[strain,'_400mM']}),:) = [];
%     pMWT = MWTDB.mwtpath;
%     
%     
%     %% patch for VG202 withtout N2
%     if strcmp(strain,'VG202')
%         i = ismember(MWTDBMaster.expter,'DH') ...
%             & ismember(MWTDBMaster.groupname,{'N2','N2_400mM'});
%         pMWTpatch = MWTDBMaster.mwtpath(i);
%         pMWT = [pMWT;pMWTpatch];
%         MWTDB = parseMWTinfo(pMWT);
%     end
%     
%     gu = unique(MWTDB.groupname);
%     
%     %% INITIAL RESPONSE
%     DataTrv = import_trv_table(pMWT);
% end
% 
% %%
% cd(pSave); save('DataTrv.mat','DataTrv','MWTDB');
% 
% return










