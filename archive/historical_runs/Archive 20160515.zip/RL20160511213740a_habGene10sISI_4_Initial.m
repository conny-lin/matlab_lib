%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM =fileparts(pM);
%% SETTING
msrlist = {'RevFreq','RevDur','RevSpeed'};


%% load data
DM = load([pSaveM,'/habGene10sISI_2_habValue/All.mat'],'DataMaster');
DM = DM.DataMaster;
strainlist = unique(DM.strain);



%% create output table 
% create col name
a = {'N2','N2_400mM','Mut','Mut_400mM'}';
colNames = [a', strjoinrows([a, cellfunexpr(a,'_SE')],'')', ...
    strjoinrows([a, cellfunexpr(a,'_N')],'')'];
nCol = numel(colNames);
a = nan(numel(strainlist),numel(colNames));
R = struct;



% get intial response table
habmlist = unique(DM.habm);
msrilist = unique(DM.msr);

for si = 1:numel(strainlist)    
    % get strain info
    strain = strainlist{si};
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);

    for msri = 1:numel(msrilist)
        for habmi = 1:numel(habmlist)
            msr = msrlist{msri};
            habm = habmlist{habmi};
            i = ismember(DM.msr,msr) & ismember(DM.habm,habm) ...
                & ismember(DM.strain,strain)...
                & ismember(DM.habm,habm);
            D = DM(i,:);
            y = D.mean;
            n = D.n; 
            e = D.se;

            gn = D.groupname;
            groupName = output_sortN2first(gn);
            

            [i,j] = ismember(groupName,gn);
            ind = j(i);
            i = [ind; ind+numel(groupName); ind+(numel(groupName)*2)];

            a = nan(1,nCol);
            b = [y,e,n];
            a(i) = b;
            R.(msr).(habm)(si,:) = a;
        end
    end

end



%% export
for msri = 1:numel(msrlist)
    for habmi = 1:numel(habmlist)
       msr = msrlist{msri};
       habm = habmlist{habmi};
       a = R.(msr).(habm);
       a = array2table(a,'VariableNames',colNames);
       T = table;
       T.strain = strainlist;
       T = [T a];
       cd(pSaveM);
       writetable(T,sprintf('%s %s.csv',msr,habm));
    end
   
end















































