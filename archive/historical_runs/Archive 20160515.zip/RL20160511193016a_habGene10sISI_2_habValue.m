%  habituation curve 10sISI of valid experiments

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM = fileparts(pM);

%% Settings
plateN = 9;
samplingN = 100;
sampleRepeatN = 3;
msrlist = {'RevFreq','RevSpeed','RevDur'};

%% get strain names
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
a = dircontent(pDataHome);
% a(ismember(a,'0-Code')) = [];
strainlist  = a;
% strainlist(~ismember(strainlist,{'BZ142'})) = [];

%% run data for all strains
StrainMaster = cell(numel(strainlist),2);
for si = 1:numel(strainlist)
    %% load data
    strainame = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strainame);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strainame);
    clear MWTDB; load([pSave,'/DataTrv.mat']);
    
    % varify group name
    [i,j] = ismember(DataTrv.mwtid,MWTDB.mwtid);
    DataTrv.groupname = MWTDB.groupname(j(i));
    DataTrv.strain = MWTDB.strain(j(i));
    groupNames = output_sortN2first(unique(DataTrv.groupname));
    gnExpected = {'N2','N2_400mM',strainame,[strainame,'_400mM']}';
    if ~isequal(groupNames,gnExpected)
        tabulate(DataTrv.groupname)
        error('group name not expected');
    end
    

    
    %% get initial
    Initial = DataTrv(DataTrv.tap ==1,:);

    %% get habituation level
    DataInput = DataTrv(DataTrv.tap >=28,:);
    Data = table;
    Data.mwtid = unique(DataInput.mwtid);
    for msri = 1:numel(msrlist)
        d = DataInput.(msrlist{msri});
        T = grpstatsTable(d, DataInput.mwtid);
        Data.(msrlist{msri}) = T.mean;
    end
    HabLevel = Data;

    %% calculate percent hab
    Data = table;
    Data.mwtid = unique(DataInput.mwtid);
    for msri = 1:numel(msrlist)
       h = HabLevel.(msrlist{msri});
       [i,j] = ismember(HabLevel.mwtid, Initial.mwtid);
       ini = Initial.(msrlist{msri})(j(i));
       hpct = 1-(h./ini);
       Data.(msrlist{msri}) = hpct;
    end
    HabPct = Data;
    
    


    %%
    HabData = {Initial,HabLevel,HabPct};
    
    HabDataName = {'Initial','HabLevel','HabPct'};
    Header = cell(numel(HabDataName)*numel(msrlist)*4,4);
    Sum = nan(size(Header,1),4);
    rowN = 1;
    for hbi = 1:numel(HabData)
        Data = HabData{hbi};
        for msri = 1:numel(msrlist)
            y = Data.(msrlist{msri});
            strain = MWTDB.strain(Data.mwtid);
            gn = MWTDB.groupname(Data.mwtid);
            dose = num2cellstr(parseGname_TestmM(gn));
            T = grpstatsTable(y,gn);
            
            rowN2 = rowN+size(T,1)-1;
            
            h = [HabDataName(hbi) msrlist(msri) strainame];
            header = repmat(h,size(T,1),1);
            gnameu = T.gnameu;
            T(:,1) = [];
            Header(rowN:rowN2,:) = [header gnameu];
            Sum(rowN:rowN2,:) = table2array(T);
            rowN = rowN2+1;
        end
    end
    
    %% collect result
    T1 = array2table(Sum,'VariableNames',T.Properties.VariableNames);
    T2 = cell2table(Header,'VariableNames',{'habm','msr','strain','groupname'});
    Result = [T2 T1];
    
    cd(pM); save(sprintf('%s.mat',strainame),'Result');
    %% put in strain master
    StrainMaster{si,1} = Header;
    StrainMaster{si,2} = Sum;
    
end
cd(pM); save('All.mat','StrainMaster');


























