%% patching VC223 run mistakes (included N2_test group)

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);


%% SETTING
ISI = 10; preplate = 100;
% assaytimePretap = 1;
% assaytimePosttap = 8;
% assayTapNumber = 28:30;
% assaytimes = [(assayTapNumber-1)*ISI+preplate-assaytimePretap;(assayTapNumber-1)*ISI+preplate+assaytimePosttap];
assaytimes = [90;95];

%% GET INFO
    legend_gangnam = load('/Users/connylin/Dropbox/Code/Matlab/Library RL/Modules/Chor_output_handling/legend_gangnam.mat');
    legend_gangnam = legend_gangnam.legend_gangnam;
    msrInterest = {'time','id','bias','speed','tap','midline'};

%% get strain names
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
a = dircontent(pDataHome);
a(ismember(a,'0-Code')) = [];
strainlist  = a;
strainlist(~ismember(strainlist,{'BZ142'})) = [];

%% MWTDB - get all paths
MWTDB = load('/Volumes/COBOLT/MWT/MWTDB.mat');
MWTDBMaster = MWTDB.MWTDB.text; clear MWTDB;


    
%% run data for all strains
for si = 1:numel(strainlist)
    strainame = strainlist{si};

    %% get data paths
    pS = sprintf('%s/%s',pDataHome,strainame);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strainame);
    
    i = MWTDBMaster.ISI == 10 ...
        & MWTDBMaster.preplate == preplate ...
        & MWTDBMaster.tapN == 30 ...
        & ismember(MWTDBMaster.groupname,sprintf('%s_400mM',strainame));
    exp = unique(MWTDBMaster.expname(i));

    MWTDB = MWTDBMaster(ismember(MWTDBMaster.expname,exp),:);
    MWTDB(~ismember(MWTDB.groupname,{'N2','N2_400mM',strainame,[strainame,'_400mM']}),:) = [];
    pMWT = MWTDB.mwtpath;
    
    
    %% patch for VG202 withtout N2
    if strcmp(strainame,'VG202')
        i = ismember(MWTDBMaster.expter,'DH') ...
            & ismember(MWTDBMaster.groupname,{'N2','N2_400mM'});
        pMWTpatch = MWTDBMaster.mwtpath(i);
        pMWT = [pMWT;pMWTpatch];
        MWTDB = parseMWTinfo(pMWT);
    end
    gu = unique(MWTDB.groupname);
    

    %% run data   
    pSave = sprintf('%s/ephys graph',pS); if ~isdir(pS); mkdir(pS); end
%     [Data,MWTDB] = ephys_extractData(pMWT,assaytimes,ISI,preplate,assayTapNumber);
    
    

    %% check pMWT files
    [~,pMWT_success,~] = getpath2chorfile(pMWT,'Gangnam.mat','reporting',0);
    MWTDB = parseMWTinfo(pMWT_success);
    pMWT = pMWT_success;
    gu = unique(MWTDB.groupname);

    %% LOAD AND PROCESS FILES
    DataVal = cell(size(pMWT));
    % produce habituated response summary per plate
    for mwti = 1:numel(pMWT)
        processIntervalReporter(numel(pMWT),1,'MWT',mwti); % reporting
        pmwt = pMWT{mwti}; % get basic info
        % get file path
        pf = char(getpath2chorfile(pMWT(mwti),'Gangnam.mat','reporting',0));
        if exist(pf,'file')~=2; display(pMWT(mwti)); error('no file exist'); end
        % load individual worm data
        Import = load(pf);
        % extract data from relevant times
        DataHab = cell(size(assaytimes,2),1);
        for ti = 1:size(assaytimes,2) % for each tap time
            Data1 = Import.Data(extract_valid_wormtime(Import.time,assaytimes(:,ti)));
            for wrmi = 1:numel(Data1)
                clear D;
                D = convert_import2table(Data1{wrmi},legend_gangnam,'msr',msrInterest);
                D = extract_data_timeofinterest(D.time,D,assaytimes(:,ti));
                % exclude data if all nan
                if sum(isnan(D.bias))==size(D,1); Data1{wrmi} = {}; continue; end; 

                % synchronize to tap
                [t,tapN] = syncdata2tap(D.time,D.tap,0);
                if tapN==0
                    Data1{wrmi} = {};
                else
                    D.time = t;
                    Data1{wrmi}  = transform_roundSpeedbytime2(D,'overwriteTime',0);
                    if isempty(D)==1; error('flag'); end
                end
            end
            Data1(cellfun(@isempty,Data1)) = []; % clear invalid data
            Data1 = cellfun(@table2array,Data1,'UniformOutput',0); % convert to array
            [r,~] = cellfun(@size,Data1); % find size
            DataHab{ti} = [repmat(ti,sum(r),1) cell2mat(Data1)]; % add time id
        end

        %% check consistency of data
        [r,c] = cellfun(@size,DataHab);
        % remove data with no data
        if any(r==0) 
            DataHab(r==0) = [];
        end
        [~,gid] = ismember(MWTDB.groupname(mwti),gu);
        DataVal{mwti} = [repmat(mwti,sum(r),1) repmat(gid,sum(r),1) cell2mat(DataHab)];
    end

    %% make sure all pMWT contains data
    i = cellfun(@isempty,DataVal);
    if sum(i) > 0
       warning('the following do not contain data:');
       disp(char(pMWT(i)));
       DataVal(i) = [];
    end
    DataVal = cell2mat(DataVal);
    clear Import DataHab Data Db D;

    % convert 2 table
    Data = array2table(DataVal,'VariableNames',[{'mwtid','groupid' 'timeid'} msrInterest {'timeround'}]);
    clear DataVal D;
    
    return
    
    %% organize data
    DataG = ephys_tranformData2struct(Data,gu);
    % save
    savename = sprintf('%s/data_ephys_%d_%ds.mat',pSave,assaytimes(1),assaytimes(2));
    save(savename,'Data','gu','MWTDB','DataG');
    % load data
    [Stats, DataG] = ephys_stats(DataG,pSave);
%     StatT = ephys_randomSample(DataG,pSave);
    % graph
    ephys_graphline(DataG,pS,assayTapNumber(1),assayTapNumber(end),strainame)
    
end




fprintf('DONE\n');

beep
beep
beep

    
    
    
    
    
    
    
    
    
    
    
    