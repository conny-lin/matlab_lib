%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);
% pData = fileparts(pSave);

            
%% load data
load('/Volumes/COBOLT/MWT/MWTDB.mat','MWTDB');
MWTDB = MWTDB.text;

% get strains
MWTDB(MWTDB.ISI ~= 10 & MWTDB.preplate ~=100,:) = [];
MWTDB(~ismember(MWTDB.rx,'400mM'),:) = [];
MWTDB.genotype(cellfun(@isempty,MWTDB.genotype)) = {''};
MWTDB(ismember(MWTDB.strain,'N2'),:) =[];
exp = unique(MWTDB.expname);


%% get exp
load('/Volumes/COBOLT/MWT/MWTDB.mat','MWTDB');
MWTDB = MWTDB.text;
MWTDB(~ismember(MWTDB.expname,exp),:) = [];
cd(pSave);
writetable(MWTDB,'explist.csv')
