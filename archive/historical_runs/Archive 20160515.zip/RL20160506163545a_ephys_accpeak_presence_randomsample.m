%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);
% pData = fileparts(pSave);

%% SETTING
%% LOAD DATA
pData = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/3-STH N2/3-Results/ePhys/Habituated Response/RL201603061657_habResp_8s_rerun/data.mat';
load(pData,'DataG');

%% ANALYSIS
Stats = struct;

%% find n(rows) and time (columns)
samplesize = nan(size(DataG,2),1);
timepts = samplesize;
for gi =1:size(DataG,2)
    [samplesize(gi),timepts(gi)] = size(DataG(gi).speedbm);
end

%% find baseline
for gi = 1:size(DataG,2)
    % generate baseline
    i = (1:find(DataG(gi).time(1,:)==0)-1);
    d = DataG(gi).speedbm(:,i);
    DataG(1).bs_data = d;
    [m,m_up,m_low,sd,se] = ephys_findbaseline(d);
    DataG(gi).bs_mean = m;
    DataG(gi).bs_sd = sd;
    DataG(gi).bs_se = se;
    DataG(gi).bs_upper = m_up;
    DataG(gi).bs_lower = m_low;
    fprintf('- baseline speed (%s): [%.3f]-[%.3f]\n',char(DataG(gi).name),DataG(gi).bs_lower,DataG(gi).bs_upper);
end

% anova for baseline differences
a = nanmean(DataG(1).bs_data')';
b = nanmean(DataG(2).bs_data')';
x = [a;b];
group = [repmat({DataG(1).name},numel(a),1); repmat({DataG(2).name},numel(b),1)];
i = isnan(x);
x(i) = []; group(i) = [];
[text,T] = anova1_autoresults(x,group);
% store in stats
Stats(end+1).name = 'baseline';
Stats(end).anova = text;
Stats(end).descriptive = T;

%% find rise peaks not on tap time(existance, value, time)
statsname = 'risepeak';
for gi = 1:size(DataG,2)
    i = (find(DataG(gi).time(1,:)==0)+1):timepts(gi);
    d = nanmean(DataG(gi).speedbm(:,i));
    t = DataG(gi).time(1,i);
    bs = DataG(gi).bs_upper;
    [ymax,ymaxtime] = ephys_findrisepeak(d,t,bs);
    DataG(gi).(statsname) = ymax;
    DataG(gi).([statsname,'_time']) = ymaxtime;
end

return
%% random sample to see if 2nd rise is significant
close all;
rep2N = 3;
repN = 3;
samplingN = 100;
figure;
color= {'k','r'};
strep = 100;
ppercent = nan(rep2N,1);
RepMean = nan(rep2N,size(DataG,2)*2);
for rep2 = 1:rep2N
    filename = sprintf('%s/peak2stats_%dx%dx%d rep%d',pSave,strep,repN,samplingN,rep2);
    fid = fopen([filename,'ANOVA.txt'],'w');
    fprintf(fid,sprintf('peak2stats %d samples x %d wormsgroup\n',repN,samplingN));
    pvalue_time = nan(strep,1);
    pvalue_peak = pvalue_time;
    repmean_ymax = nan(strep,size(DataG,2));
    repmean_ytime = nan(strep,size(DataG,2));
    for rep1 = 1:strep
        ymax = nan(repN,size(DataG,2));
        ymaxtime = ymax;
        gn = cell(size(ymax));
        for rep = 1:repN
            subplot(repN,1,rep); hold on;
            for gi = 1:size(DataG,2)
                % random select
                k = randi(samplesize(gi),samplingN,1);
                % plot
                plot(nanmean(DataG(gi).time(k,:)),nanmean(DataG(gi).speedbm(k,:)),'Color',color{gi});
                % find baseline
                bsd = DataG(gi).speedbm(:,(1:find(DataG(gi).time(1,:)==0)-1));
                [m,m_upper,m_low,sd,se] = ephys_findbaseline(bsd);
                bs = m+(sd*3); % set baseline as 3 standard deviation
                % calculate peak
                i = (find(DataG(gi).time(1,:)==0)+1):timepts(gi);
                t = DataG(gi).time(1,i);
                d = nanmean(DataG(gi).speedbm(k,i));
                [ymax(rep,gi),ymaxtime(rep,gi)] = ephys_findrisepeak(d,t,bs);
                gn(rep,gi) = {DataG(gi).name};
            end
        end
        % anova -ytime
        x = reshape(ymaxtime,numel(ymaxtime),1);
        group = reshape(gn,numel(gn),1);
        i = isnan(x);
        x(i) = [];
        group(i) = [];
        if numel(unique(group))~=size(DataG,2);
            error('stop')
            pvalue_time(rep1) = Inf;
        else
            [text,T,p] = anova1_autoresults(x,group);
            repmean_ymax(rep1,:) = T.mean';
            if isnan(p); error('stop'); end
            fprintf(fid,'%s\n',text);
            pvalue_time(rep1) = p;
        end
        % anova - ymax
        x = reshape(ymax,numel(ymax),1);
        group = reshape(gn,numel(gn),1);
        i = isnan(x);
        x(i) = [];
        group(i) = [];
        if numel(unique(group))~=size(DataG,2);
            error('stop')
            pvalue_peak(rep1) = Inf;
        else
            [text,T,p] = anova1_autoresults(x,group);
            repmean_ytime(rep1,:) = T.mean';
            if isnan(p); error('stop'); end
            fprintf(fid,'%s\n',text);
            pvalue_peak(rep1) = p;
        end
    end
    
    savefigpdf(filename,pSave);
    fclose(fid);
    % write pvalue table
    T= table;
    T.pvalue_maxtime = pvalue_time;
    T.pvalue_ypeak = pvalue_peak;
    writetable(T,[filename,' pvalue.csv']);
    % write mean table
    T= table;
    T.N2 = repmean_ymax(:,1);
    T.N2_400mM = repmean_ymax(:,2);
    writetable(T,[filename,' peak value.csv']);
    % write mean table
    T= table;
    T.N2 = repmean_ytime(:,1);
    T.N2_400mM = repmean_ytime(:,2);
    writetable(T,[filename,' peak time.csv']);
    % write rep mean
    RepMean(rep2,:) = [mean(repmean_ytime) mean(repmean_ymax)];
    % examine pvalue > 0.001
    ppercent(rep2,1) = sum(pvalue_time<0.05);
    ppercent(rep2,2) = sum(pvalue_peak<0.05);

end
cd(pSave);
filename = sprintf('%s/peak2stats_%dx%dx%d',pSave,strep,repN,samplingN);
dlmwrite([filename,' p pass alpha5.csv'],ppercent)
dlmwrite([filename,' mean values.csv'],RepMean)


return

%% find fall peaks not on tap time(existance, value, time)
statsname = 'fallpeak';
for gi = 1:size(DataG,2)
    i = (find(DataG(gi).time(1,:)==0)+1):timepts(gi);
    d = nanmean(DataG(gi).speedbm(:,i));
    ymax = min(d);
    if ymax>=DataG(gi).bs_lower
        ymax = NaN; 
    end
    if ~isnan(ymax)
        t = DataG(gi).time(1,i);
        ymaxtime = t(d==ymax);
    else
        ymaxtime=NaN;
    end
    DataG(gi).(statsname) = ymax;
    DataG(gi).([statsname,'_time']) = ymaxtime;
end



%%
return
y_max1 = max(y);
if y_max1<=bs_upper
    y_max1 = NaN; 
    y_max2 = NaN;
else
    y_max2 = max(y(y~=y_max1));
    % if second peak is within baseline or next to first peak, ignore
    if y_max2<=bs_upper || abs(diff([find(y==y_max1) find(y==y_max2)]))==1
        y_max2 = NaN; 
    end
end
y_min1 = min(y);
if y_min1>=bs_lower
    y_min1 = NaN; 
    y_min2 = NaN;
else
   y_min2 = min(y(y~=y_min1));
    if y_min2>=bs_lower || abs(diff([find(y==y_min1) find(y==y_min2)]))==1
        y_min2 = NaN; 
    end
end

fprintf('- found %d forward peak\n',sum(~isnan([y_max1 y_max2])));
fprintf('- found %d reverse peak\n',sum(~isnan([y_min1 y_min2])));

%% get mean response
        Y = DataG(gi).speedbm;
    X = DataG(gi).time;
    time= DataG(gi).time(1,:);
    y = nanmean(DataG(gi).speedbm);

%% find max peaks
y_max1 = max(y);
if y_max1<=bs_upper
    y_max1 = NaN; 
    y_max2 = NaN;
else
    y_max2 = max(y(y~=y_max1));
    % if second peak is within baseline or next to first peak, ignore
    if y_max2<=bs_upper || abs(diff([find(y==y_max1) find(y==y_max2)]))==1
        y_max2 = NaN; 
    end
end
y_min1 = min(y);
if y_min1>=bs_lower
    y_min1 = NaN; 
    y_min2 = NaN;
else
   y_min2 = min(y(y~=y_min1));
    if y_min2>=bs_lower || abs(diff([find(y==y_min1) find(y==y_min2)]))==1
        y_min2 = NaN; 
    end
end

fprintf('- found %d forward peak\n',sum(~isnan([y_max1 y_max2])));
fprintf('- found %d reverse peak\n',sum(~isnan([y_min1 y_min2])));

%% find threshold (the first point before rise/fall)
% find significant changes between time series
h_slope = nan(numel(time)-1,1);
p_slope = h_slope;
stats_slope = cell(size(p_slope));
for t = 1:numel(time)-1
    [h_slope(t),p_slope(t),~,stats_slope{t}] = ttest(Y(:,t),Y(:,t+1)); 
end
fprintf('- %d time pts sig diff(p<0.05)\n',sum(h_slope))
a = find(p_slope<0.0001)+1;
fprintf('- %d time pts sig diff(p<0.0001)\n',numel(a))

% find response threshold
threshold_response = a(1)-1;
if threshold_response+1 ~= find(time==0)
   fprintf('- response threshold %d ~= the pt before tap time\n',threhold_time) 
else
   fprintf('- response threshold = the pt before tap time\n')  
end

% calculate significant difference from threshold
h_bs = nan(numel(time),1);
p_bs = h_bs;
stats_bs = cell(size(h_bs));
for t = 1:numel(time)
    [h_bs(t),p_bs(t),~,stats_bs{t}] = ttest(Y(:,t),nanmean(bs_data,2),'Alpha',0.0001); 
end
% plot
close;
plot(time,y,'kx'); hold on;
% plot(x,y,'Color','k','Marker','none');
% xlim([min(x) max(x)]);
% ylim([min(y)*.9 max(y)*1.1]);
th = find(h_bs==1);
yy = y(th);
xx = time(th);
plot(xx,yy,'bo');
title('points sig diff from baseline','FontSize',20);
fprintf('press enter to continue: ');
pause;
close;
fprintf('\n');
% process
a = find(h_bs);
threshold_return = a(end)+1;
if threshold_return > numel(y)
   fprintf('- speed did not return to baseline\n');
end

%% duration of response
dur_fullrecovery = (threshold_return - threshold_response)*(time(2)-time(1));
fprintf('- duration to full recovery: %.1fs\n',dur_fullrecovery);


%% find 20%/80% rise and fall from threshold/baseline
if ~isnan(y_max1)
    rise80 = (y_max1-bs_mean)*.8+bs_mean;
    rise20 = (y_max1-bs_mean)*.2+bs_mean;
    fprintf('- 20/80%% rise: %.3f, %.3f\n',rise20,rise80)
end
if ~isnan(y_min1)
    fall80 = bs_mean-(bs_mean-y_min1)*.8;
    fall20 = bs_mean-(bs_mean-y_min1)*.2;
    fprintf('- 20/80%% fall: %.3f, %.3f\n',fall20,fall80)
end

%% 20% recovery from reversal
find(y==y_min1)












%% peak width (to code later)
% peaks_name = {'max1','max2','min1','min2'};
% peaks = [y_max1 y_max2 y_min1 y_min2];
% [i,j] = ismember(peaks,y);
% peaks_time = j(i);
% [k,m] = sort(peaks_time);
% peaks_btw_time = diff(k);
% peaks_name(m)




%%
th = find(p_slope<0.02)+1;
yss = y(th);
xss = x(th);
plot(xss,yss,'ro','MarkerSize',10);

% plot lines
yy = [min(y)*.9 max(y)*1.1];
for i = 1:numel(th);
   line([x(th(i)) x(th(i))],yy,'Color',[.5 .5 .5])
end
% generate baseline
bsi = (1:find(time==0)-1);
bs_data = Y(:,bsi);
% bs_data = reshape(bs_data,numel(bs_data),1);
bs_mean = nanmean(nanmean(bs_data));
bs_sd = nanstd(nanmean(bs_data));
bs_se = nanstd(nanmean(bs_data))./sqrt(numel(nanmean(bs_data))-1);
bs_upper = bs_mean+(bs_sd*2);
bs_lower = bs_mean-(bs_sd*2);
% plot baseline
line([min(x) max(x)], [bs_mean bs_mean],'Color','k');
line([min(x) max(x)], [bs_upper bs_upper],'Color',[.5 .5 .5]);
line([min(x) max(x)], [bs_lower bs_lower],'Color',[.5 .5 .5]);



%%
fprintf('DONE\n');


    
    
    
    
    
    
    
    
    
    
    
    