%  habituation curve 10sISI of valid experiments

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSave = fileparts(pM);

%% Settings
plateN = 9;
samplingN = 100;
sampleRepeatN = 3;
msrlist = {'RevFreq','RevSpeed','RevDur'};

%% get strain names
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
a = dircontent(pDataHome);
% a(ismember(a,'0-Code')) = [];
strainlist  = a;
strainlist(~ismember(strainlist,{'BZ142'})) = [];

%% run data for all strains
for si = 1:numel(strainlist)
    %% load data
    strainame = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strainame);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strainame);
    clear MWTDB; load([pSave,'/DataTrv.mat']);
    
    % varify group name
    [i,j] = ismember(DataTrv.mwtid,MWTDB.mwtid);
    DataTrv.groupname = MWTDB.groupname(j(i));
    groupNames = output_sortN2first(unique(DataTrv.groupname));
    gnExpected = {'N2','N2_400mM',strainame,[strainame,'_400mM']}';
    if ~isequal(groupNames,gnExpected)
        tabulate(DataTrv.groupname)
        error('group name not expected');
    end
    

    
    %% get initial
    Initial = DataTrv(DataTrv.tap ==1,:);

    %% get habituation level
    DataInput = DataTrv(DataTrv.tap >=28,:);
    Data = table;
    Data.mwtid = unique(DataInput.mwtid);
    for msri = 1:numel(msrlist)
        d = DataInput.(msrlist{msri});
        T = grpstatsTable(d, DataInput.mwtid);
        Data.(msrlist{msri}) = T.mean;
    end
    HabLevel = Data;

    %% calculate percent hab
    Data = table;
    Data.mwtid = unique(DataInput.mwtid);
    for msri = 1:numel(msrlist)
       h = HabLevel.(msrlist{msri});
       [i,j] = ismember(HabLevel.mwtid, Initial.mwtid);
       ini = Initial.(msrlist{msri})(j(i));
       hpct = 1-(h./ini);
       Data.(msrlist{msri}) = hpct;
    end
    HabPct = Data;
    
    
    return
    %% put in groups
    Data = cell(size(groupNames));
    for gi = 1:numel(groupNames)
        Data{gi} = DataTrv(ismember(DataTrv.groupname,groupNames(gi)),:);     
    end

    %%
%     for msri = 1:numel(msrlist)
%     Mean = nan(samplingN,numel(groupNames));
%     pValue = nan(samplingN,1);
%     N = nan(size(Mean));
%     for samplei =  1:samplingN
%         Y = nan(plateN,numel(groupNames));
%         G = reshape(repmat(groupNames',plateN,1),numel(Y),1);
% 
%         for gi = 1:numel(groupNames)
%             gn = groupNames{gi};
%             msr = msrlist{msri};
%             data = Data{gi}.(msr);
%             Y(:,gi) = datasample(data,plateN);
%         end
% 
%         Y = reshape(Y, numel(Y),1);
%         % get rid of nan
%         i = isnan(Y) | isinf(Y);
%         if sum(i) > 0
%            Y(i) = [];
%            G(i) = [];
%         end
% 
% 
%         [~,T,p] = anova1_autoresults(Y,G);
%         pValue(samplei) = p;
% 
%         [i,j] = ismember(groupNames,T.gnames);
% 
%         Mean(samplei,:) = T.mean(j(i));
%         N(samplei,:) = T.N(j(i));
% 
%     end
% 
% end

end

























