%% Questions to answer
% 1-sample size (how many worms, valid worms)
% 2-did accpeak occur in alcohol condition? in 0mM condition?
% 3-if accpeak exist, whats the 
%     peak time
%     peak height
%     peak width
% 4 - statistics
%     is the peak 


%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);


%% SETTING
pSF = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Results/Data/10sISI/by strains/';

%% load data
strain = 'DA609';
pData = sprintf('%s/%s',pSF,strain);
load([pData,'/data_ephys_t28_30.mat']);
pSave = sprintf('%s/ephys graph',pData); if ~isdir(pSave); mkdir(pSave); end


%% ANALYSIS
Stats = struct;

%% find n(rows) and time (columns)
samplesize = nan(size(DataG,2),1);
timepts = samplesize;
for gi =1:size(DataG,2)
    [DataG(gi).N, DataG(gi).timepts] = size(DataG(gi).speedbm);
end


%% decide group sequence
gu = cell(size(DataG,2),1);
for gi =1:size(DataG,2)
    gu{gi} = DataG(gi).name;
end
guseq = [find(regexpcellout(gu,'N2'));find(~regexpcellout(gu,'N2'))]';


%% graph mean curve 
color = [0 0 0; 1 0 0; .5 .5 .5; [0.851 0.325 0.098]]; 
color = color(guseq,:);
close
figure1 = figure('Visible','off'); hold on;
for gi = guseq
    gn = regexprep(DataG(gi).name,'_',' ');
    d = DataG(gi).speedbm;
    y = nanmean(d);
    sd = nanstd(d);
    n = sum(~isnan(d));
    se = sd./sqrt(n-1);
    se2 = se.*2;
    x = DataG(gi).time(1,:);
    c = color(gi,:);
    e1 = plot(x,y,'Color',c,'Marker','none','DisplayName',gn,...
        'Linewidth',3);
end
xlim([min(x) max(x)])
legend1 = legend('show');
set(legend1,'Location','northeast','EdgeColor',[1 1 1]);
savename = sprintf('ephys t28-30');
printfig(savename,pSave,'w',4,'h',4,'closefig',1);


%% find baseline
for gi = 1:size(DataG,2)
    % generate baseline
    i = (1:find(DataG(gi).time(1,:)==0)-1);
    d = DataG(gi).speedbm(:,i);
    DataG(gi).bs_data = d;
    [m,m_up,m_low,sd,se] = ephys_findbaseline(d);
    DataG(gi).bs_mean = m;
    DataG(gi).bs_sd = sd;
    DataG(gi).bs_se = se;
    DataG(gi).bs_upper = m_up;
    DataG(gi).bs_lower = m_low;
    fprintf('- baseline speed (%s): [%.3f]-[%.3f]\n',...
        char(DataG(gi).name),DataG(gi).bs_lower,DataG(gi).bs_upper);
end
% anova for baseline differences
a = nanmean(DataG(1).bs_data')';
b = nanmean(DataG(2).bs_data')';
x = [a;b];
group = [repmat({DataG(1).name},numel(a),1); repmat({DataG(2).name},numel(b),1)];
i = isnan(x);
x(i) = []; group(i) = [];
[text,T] = anova1_autoresults(x,group);
% store in stats
Stats(end+1).name = 'baseline';
Stats(end).anova = text;
Stats(end).descriptive = T;



%% find mean rise peaks not on tap time(existance, value, time)
statsname = 'risepeak';
for gi = 1:size(DataG,2)
    % define range of time after tap
    bs = DataG(gi).bs_upper;
    time = DataG(gi).time(1,:);
    i = (find(time==0)+1):DataG(gi).timepts;
    d = nanmean(DataG(gi).speedbm(:,i)); % find mean
    t = time(:,i);
    [ymax,ymaxtime] = ephys_findrisepeak(d,t,bs);
    DataG(gi).(statsname) = ymax;
    DataG(gi).([statsname,'_time']) = ymaxtime;
end


%% random sampling
wormN = 100;
plateN = 4*3;

n = plateN*size(DataG,2);
peakValue = nan(n,1);
groupname = cell(n,1);
peakTime = nan(n,1);


rowN =1;
for gi = guseq
    % get data
    D = DataG(gi).speedbm;
    time = DataG(gi).time(1,:);
    sampleN = size(D,1);
    gn = {DataG(gi).name};
    
for ei = 1:plateN    
    % baseline time
    tbs = (1:find(time==0)-1);
    tpeak = (find(time(1,:)==0)+1):numel(time);
    % get random number
    DS = D(randi(sampleN,wormN,1),:);
    
    % find baseline (2SD above mean baseline)
    bsd = DS(:,tbs);
    [m,bs,~,sd,~] = ephys_findbaseline(bsd);
    
    % calculate peak
    t = time(tpeak);
    d = nanmean(DS(:,tpeak));
    [peakValue(rowN), peakTime(rowN)] = ephys_findrisepeak(d,t,bs);
    
    % record group name
    groupname(rowN) = gn;
    
    rowN = rowN+1;
end
end

%% summarize
T = table;
T.groupname = groupname;
T.peakValue = peakValue;
T.peakTime = peakTime;


return
%% random sample to see if 2nd rise is significant
close all;
rep2N = 3;
repNlist = [3 5];
samplingN = 100;
figure;
color= {'k','r'};
strep = 100;
ppercent = nan(rep2N,1);
RepMean = nan(rep2N,size(DataG,2)*2);
for repNi = 1:numel(repNlist)
    repN = repNlist(repNi);
for rep2 = 1:rep2N
    filename = sprintf('%s/peak2stats_%dx%dx%d rep%d',pSave,strep,repN,samplingN,rep2);
    fid = fopen([filename,'ANOVA.txt'],'w');
    fprintf(fid,sprintf('peak2stats %d samples x %d wormsgroup\n',repN,samplingN));
    pvalue_time = nan(strep,1);
    pvalue_peak = pvalue_time;
    repmean_ymax = nan(strep,size(DataG,2));
    repmean_ytime = nan(strep,size(DataG,2));
    for rep1 = 1:strep
        ymax = nan(repN,size(DataG,2));
        ymaxtime = ymax;
        gn = cell(size(ymax));
        for rep = 1:repN
            subplot(repN,1,rep); hold on;
            
            for gi = 1:size(DataG,2)
                % random select
                k = randi(samplesize(gi),samplingN,1);
                % plot
                plot(nanmean(DataG(gi).time(k,:)),nanmean(DataG(gi).speedbm(k,:)),'Color',color{gi});
                
                % find baseline
                bsd = DataG(gi).speedbm(:,(1:find(DataG(gi).time(1,:)==0)-1));
                [m,m_upper,m_low,sd,se] = ephys_findbaseline(bsd);
                bs = m+(sd*3); % set baseline as 3 standard deviation
                
                % calculate peak
                i = (find(DataG(gi).time(1,:)==0)+1):timepts(gi);
                t = DataG(gi).time(1,i);
                d = nanmean(DataG(gi).speedbm(k,i));
                [ymax(rep,gi),ymaxtime(rep,gi)] = ephys_findrisepeak(d,t,bs);
                gn(rep,gi) = {DataG(gi).name};
                
            end
            
        end
        % anova -ytime
        x = reshape(ymaxtime,numel(ymaxtime),1);
        group = reshape(gn,numel(gn),1);
        i = isnan(x);
        x(i) = [];
        group(i) = [];
        if numel(unique(group))~=size(DataG,2);
%             error('stop')
            pvalue_time(rep1) = Inf;
        else
            [text,T,p] = anova1_autoresults(x,group);
            repmean_ymax(rep1,:) = T.mean';
            if isnan(p); error('stop'); end
            fprintf(fid,'%s\n',text);
            pvalue_time(rep1) = p;
        end
        % anova - ymax
        x = reshape(ymax,numel(ymax),1);
        group = reshape(gn,numel(gn),1);
        i = isnan(x);
        x(i) = [];
        group(i) = [];
        if numel(unique(group))~=size(DataG,2);
%             error('stop')
            pvalue_peak(rep1) = Inf;
        else
            [text,T,p] = anova1_autoresults(x,group);
            repmean_ytime(rep1,:) = T.mean';
            if isnan(p); error('stop'); end
            fprintf(fid,'%s\n',text);
            pvalue_peak(rep1) = p;
        end
    end
    
    savefigpdf(filename,pSave);
    fclose(fid);
    % write pvalue table
    T= table;
    T.pvalue_maxtime = pvalue_time;
    T.pvalue_ypeak = pvalue_peak;
    writetable(T,[filename,' pvalue.csv']);
    % write mean table
    T= table;
    T.N2 = repmean_ymax(:,1);
    T.N2_400mM = repmean_ymax(:,2);
    writetable(T,[filename,' peak value.csv']);
    % write mean table
    T= table;
    T.N2 = repmean_ytime(:,1);
    T.N2_400mM = repmean_ytime(:,2);
    writetable(T,[filename,' peak time.csv']);
    % write rep mean
    RepMean(rep2,:) = [mean(repmean_ytime) mean(repmean_ymax)];
    % examine pvalue > 0.001
    ppercent(rep2,1) = sum(pvalue_time<0.05);
    ppercent(rep2,2) = sum(pvalue_peak<0.05);

end
cd(pSave);
filename = sprintf('%s/peak2stats_%dx%dx%d',pSave,strep,repN,samplingN);
dlmwrite([filename,' p pass alpha5.csv'],ppercent)
dlmwrite([filename,' mean values.csv'],RepMean)

end
return







%% find fall peaks not on tap time(existance, value, time)
statsname = 'fallpeak';
for gi = 1:size(DataG,2)
    i = (find(DataG(gi).time(1,:)==0)+1):timepts(gi);
    d = nanmean(DataG(gi).speedbm(:,i));
    ymax = min(d);
    if ymax>=DataG(gi).bs_lower
        ymax = NaN; 
    end
    if ~isnan(ymax)
        t = DataG(gi).time(1,i);
        ymaxtime = t(d==ymax);
    else
        ymaxtime=NaN;
    end
    DataG(gi).(statsname) = ymax;
    DataG(gi).([statsname,'_time']) = ymaxtime;
end





    
    
    
    
    
    
    
    
    
    
    
    