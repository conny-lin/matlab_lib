%  habituation curve 10sISI of valid experiments

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM = fileparts(pM);

%% Settings
plateN = 9;
samplingN = 100;
sampleRepeatN = 3;
msrlist = {'RevFreq','RevSpeed','RevDur'};
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';


%% get strain names
strainlist = dircontent(pDataHome);
strainlist(~ismember(strainlist,{'CX3490'})) = [];

%% run data for all strains
for si = 1:numel(strainlist)
    % load data
    strain = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strain);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);
    clear MWTDB; load([pSave,'/DataTrv.mat'],'MWTDB');
    
    % shane spark
    pMWT = MWTDB.mwtpath;
    MWTSet = Dance_ShaneSpark4(pMWT,'pSave',pSave);
    
    % collect graph
    for msri = 1:numel(msrlist)
        ps = sprintf('%s/Dance_ShaneSpark4/HabCurve %s.pdf',pSave,msrlist{msri});
        [~,fn] = fileparts(ps);
        pd = sprintf('%s/%s %s.pdf',pM,strain,fn);
        copyfile(ps,pd);
    end
    
    % collect RMANOVA
    ps = sprintf('%s/Dance_ShaneSpark4/RMANOVA.txt',pSave);
    [pf,fn] = fileparts(ps);
    pd = sprintf('%s/%s %s.txt',pM,strain,fn);
    copyfile(ps,pd);
    
end

















