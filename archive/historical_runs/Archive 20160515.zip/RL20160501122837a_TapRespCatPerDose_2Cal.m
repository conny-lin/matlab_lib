%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);

%% combine data
cd(pSave); load data

%% get luckery f1e
pSaveA = [pSave,'/velocity x time']; if ~isdir(pSaveA); mkdir(pSaveA); end
for ri = 1:size(Data,1)
    x = Time(ri,1:end-1)';
    y = Data(ri,:)';
    g = MWTDB(ri,:);
    a = sprintf('%s %s %d [%d]',char(g.groupname), char(g.mwtname), floor(min(x)), g.mwtid);
    name = regexprep(a,'_','-');
    figure('Visible','off');
    plot(x,y)
    title(name);
    xlim([floor(min(x)) ceil(max(x))])
    printfig(name,pSaveA,'w',3,'h',2)
    return
end

return



































