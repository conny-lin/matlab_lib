
%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM = fileparts(pM);


%% Settings
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';

%% process into table
pD = ['/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/',...
    '5-initial sensitivity/habGene_initialSensitivity'];
load('/Users/connylin/Dropbox/Code/Matlab/Library RL/Modules/MWTDatabase/strainNames.mat');
% limit strain
strainlimit = {'NM1968'};
% strainlimit = {};

%% get strain names
strainlist = strainNames.strain;
if ~isempty(strainlimit); 
strainlist(~ismember(strainlist,strainlimit)) = []; 
end
if isempty(strainlist); warning('no strain'); end

%% set up output table
msrlist = {'curve','speedbm','speed'};
rowNames = {'df' 'tap' 'strain' 'dose' 'strain*dose',...
    'HRP_WT0x400','HRP_WT0xMut0','HRP_Mut0xMut400','HRP_Mut0xWT400',...
    'HRP_Mut400xWT400','HRP_Mut400xWT0'};
mulnames = {'W_WE','M_ME','W_M','WE_ME','WE_M','W_ME'};
for ri = 1:numel(mulnames)
    a = strjoinrows([repmat(mulnames(ri),30,1) num2cellstr((1:30)')],'')';
    rowNames = [rowNames a];
end

%% run data for all strains
MS = array2table(nan(numel(rowNames),numel(strainlist)),...
    'VariableNames',strainlist,'RowNames',rowNames);

for si = 1:numel(strainlist)
% get strain info
strain = strainlist{si};
fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);

for msri = 1:numel(msrlist)
    %% get msr info
    msr = msrlist{msri}; 
    %% load file
    close all;
    a = fopen(sprintf('%s/%s %s MANOVA.txt',pD,strain,msr),'r');
    dataArray = textscan(a, '%s%[^\n\r]', 'Delimiter', '','ReturnOnError', false);
    fclose(a);
    d = [dataArray{1:end-1}];
    clearvars filename delimiter formatSpec fileID dataArray ans;

    %% get descriptive stats
    i = find(strcmp(d,'*** Descriptive Stats ***'));
    k = find(regexpcellout(d,'*** Multifactorial ANOVA'));
    j = find(regexpcellout(d,'*** Posthoc'));
    eStat = d(i+1:k-1);
    mANOVA = d(k+1:j-1);
    postHoc = d(j+1:end);
    
    %% interprept eStat
    a = regexpcellout(eStat,' = ','split');
    eStat_type = a(:,1);
    b = regexpcellout(a(:,2)',', ','split')';
    c = cell2table(b,'VariableNames',eStat_type);
    for fi = 2:size(c,2)
        c.(eStat_type{fi}) = cellfun(@str2num,table2array(c(:,fi)));
    end
    eStat = c;
    
    %% interpret mANOVA
    a = regexpcellout(mANOVA,'[:] ','split');
    aFactor = a(:,1);
    b = regexpcellout(a(:,2),', p ','split');
    apvalue = nan(size(b,1),1);
    p = b(:,2);
    i = regexpcellout(p,'<');
    apvalue(i) = cellfun(@str2num,regexprep(p(i),'(<)|(=) ',''));
    
    %% interpret posthoc
    
    a = regexpcellout(postHoc,'(, p<)|(, p=)','split');
    p = a(:,2);
    phpvalue = nan(size(a,1),1);
    i = ~regexpcellout(p,'n.s.');
    phpvalue(i) = cellfun(@str2num,p(i));
    b = regexpcellout(a(:,1),' x ','split');
    c = regexpcellout(b(:,1),' ','split');
    phs1 = c(:,1);
    phd1 = c(:,2);
    c = regexpcellout(b(:,2),' ','split');
    phs2 = c(:,1);
    phd2 = c(:,2);
    postHoc = table;
    postHoc.s1 = phs1;
    postHoc.d1 = phd1;
    postHoc.s2 = phs2;
    postHoc.d2 = phd2;
    postHoc.pvalue=  phpvalue
    
    return
    i = find(strcmp(d,'RMANOVA:'));
    k = find(strcmp(d,'Posthoc(Tukey)tap by gname:'));
    j = find(strcmp(d,'Posthoc(Tukey) HabCurve by group:'));
    d1 = d(i+1:j-1);
    d2 = d(j+1:k-1);

    d(1:k) = [];
    a = regexpcellout(d,'(*)|(,)','split');
    tap = cellfun(@str2num,regexprep(a(:,1),'tap',''));
    g1 = a(:,2);
    g2 = a(:,3);
    b = regexprep(a(:,4),' ','');
    pvalue = cellfun(@str2num,regexprep(b,'(p)|(=)|(<)',''));


    T = table;
    T.tap = tap;
    T.g1 = g1;
    T.g1dose = parseGname_TestmM(g1);
    T.g1strain = regexprep(g1,'_400mM','');
    T.g2 = g2;
    T.g2strain = regexprep(g2,'_400mM','');
    T.g2dose = parseGname_TestmM(g2);
    T.pvalue = pvalue;
    
    %% -----------------------------------

    
    % degree of freedom
    s = d1{1};
    i = strfind(s,',');
    df1 = str2double(regexprep(s(1:i(1)),'F(|(,)',''));
    s = s(i(1)+1:i(2)-1);
    df2 = str2double(s(1:strfind(s,')')-1));
    
    % MANOVA table
    a = regexpcellout(d1,', ','split');
    t = regexprep(a(:,1),'(.{1,}(?=[)]))','');
    t = regexprep(t,')','');
    t = regexprep(t,'(?<=[=]).{1,}','');
    t = regexprep(t,'[=]|(\s)','');
    pv_anova =regexprep(a(:,2),'(p)|(=)|(<)','');
    afactor = t;
    afactor = regexprep(afactor,'*tap','');
    afactor(strcmp(afactor,'Intercept')) = {'tap'};
    % add manova
    
%     anovap = cellfun(@str2num,pv_anova);
    MS.(strain)('df') = df2;
    for ri = 1:numel(pv_anova)
        a = pv_anova{ri};
        if ~strcmp(a,'n.s.')
            a = str2double(a);
        else
            a = NaN;
        end
        MS.(strain)(afactor{ri}) = a;
    end
    
    %% get g names
    gu = unique(g1);
    strainu = unique(regexprep(gu,'_400mM',''));
    mutant = strainu(~ismember(strainu,'N2'));
    doseu = unique(T.g1dose);

    % convert to genotype
    i = ismember(strainNames(:,2), mutant);
    if sum(i)==1
        genotype = strainNames{i,1};
        muttype = strainNames{i,3};
    else
        genotype = char(mutant);
        muttype = '';
    end

    %% between curves table
    a = regexpcellout(d2,', ','split');
    pairname = a(:,1);
    gn = regexpcellout(a(:,1),'*','split');
    g1 = gn(:,1);
    g2 = gn(:,2);
    pstring_curve = a(:,2);
    pv =regexprep(a(:,2),'(p)|(=)|(<)','');
    
    mutstr = char(mutant);
    b = pv{ismember(pairname,'N2*N2_400mM')};
    if ~strcmp(b,'n.s.'); MS.(strain)('HRP_WT0x400') = str2double(b); end
    b = pv{ismember(pairname,sprintf('N2*%s',mutstr))};
    if ~strcmp(b,'n.s.'); MS.(strain)('HRP_WT0xMut0') = str2double(b); end
    b = pv{ismember(pairname,sprintf('%s*%s_400mM',mutstr,mutstr))};
    if ~strcmp(b,'n.s.'); MS.(strain)('HRP_Mut0xMut400') = str2double(b); end
    b = pv{ismember(pairname,sprintf('%s*N2_400mM',mutstr))};
    if ~strcmp(b,'n.s.'); MS.(strain)('HRP_Mut0xWT400') = str2double(b); end
     b = pv{ismember(pairname,sprintf('%s_400mM*N2_400mM',mutstr))};
    if ~strcmp(b,'n.s.'); MS.(strain)('HRP_Mut400xWT400') = str2double(b); end   
      b = pv{ismember(pairname,sprintf('%s_400mM*N2',mutstr))};
    if ~strcmp(b,'n.s.'); MS.(strain)('HRP_Mut400xWT0') = str2double(b); end   
    
    %% pairwise time
    tapf = (1:30)';
    tapArray = nan(size(tapf));
rn = {'W_WE'};
A = T(ismember(T.g1,'N2') & ismember(T.g2,'N2_400mM'),:);
a = tapArray;
a(A.tap) = A.pvalue;
MS.(strain)(strjoinrows([repmat(rn,30,1) num2cellstr((1:30)')],'')') = a;


rn = {'M_ME'};
A = T(ismember(T.g1,mutstr) & ismember(T.g2,[mutstr,'_400mM']),:);
a = tapArray;
a(A.tap) = A.pvalue;
MS.(strain)(strjoinrows([repmat(rn,30,1) num2cellstr((1:30)')],'')') = a;

rn = {'W_M'};
i = ismember(T.g1,'N2') & ismember(T.g2,mutstr);
a = tapArray;
a(T.tap(i)) = T.pvalue(i);
MS.(strain)(strjoinrows([repmat(rn,30,1) num2cellstr((1:30)')],'')') = a;


rn = {'WE_ME'};
i = ismember(T.g1,'N2_400mM') & ismember(T.g2,[mutstr,'_400mM']);
a = tapArray;
a(T.tap(i)) = T.pvalue(i);
MS.(strain)(strjoinrows([repmat(rn,30,1) num2cellstr((1:30)')],'')') = a;


rn = {'WE_M'};
i = ismember(T.g1,'N2_400mM') & ismember(T.g2,mutstr);
a = tapArray;
a(T.tap(i)) = T.pvalue(i);
MS.(strain)(strjoinrows([repmat(rn,30,1) num2cellstr((1:30)')],'')') = a;


rn = {'W_ME'};
i = ismember(T.g1,'N2') & ismember(T.g2,[mutstr,'_400mM']);
a = tapArray;
a(T.tap(i)) = T.pvalue(i);
MS.(strain)(strjoinrows([repmat(rn,30,1) num2cellstr((1:30)')],'')') = a;


end

end

return

%% save

cd(pM);
writetable(MS,'pvaluesum.csv','WriteRowNames',1);

%% rank

rn = strjoinrows([repmat({'M_ME'},30,1) num2cellstr((1:30)')],'');
a = table2array(MS(rn,:));
a(isnan(a)) = 1;
b = sum(a);
[i,j] = sort(b);
MSS = MS(:,j);

cd(pM);
writetable(MSS,'pvaluesum_sorted.csv','WriteRowNames',1);



%%


% %% sub fun
% function pairwise_withintime(A)
% if isempty(A); fprintf('all taps, p=n.s.')
% else
%     if size(A,1)==30; fprintf('all taps, p<0.05');
%     elseif size(A,1) <= 15
%         k = A.tap; fprintf('taps %s, p<0.05',char(strjoinrows(num2cellstr(k)',', ')))
%     elseif size(A,1) > 15
%         k = A.tap; 
%         tp = (1:30)';
%         j = find(~ismember(tp,k));
%         fprintf('taps %s, p=n.s., other taps, p<0.05',char(strjoinrows(num2cellstr(j)',', ')))
%     end
% end
% end










































