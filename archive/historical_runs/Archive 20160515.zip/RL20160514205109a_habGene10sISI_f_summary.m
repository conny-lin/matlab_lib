
% function [d1,d2,T,T1] = habGene10sISI_f_summary(strain)

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM = fileparts(pM);


%% Settings
msrlist = {'RevFreq','RevSpeed','RevDur'};
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
% Dance = 'Dance_ShaneSpark4_Nlim8';
%% process into table
pD = ['/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/',...
    '4-TWR/Data/habGene10sISI_5_graph'];
cd(pD); load('strainNames.mat');
% limit strain
strainlimit = {'NM1968'};
% strainlimit = {};

%% get strain names
strainlist = dircontent(pDataHome);
if ~isempty(strainlimit); 
    strainlist(~ismember(strainlist,strainlimit)) = []; 
end
if isempty(strainlist); warning('no strain'); end

%% run data for all strains

rowNames = {'df' 'tap' 'strain' 'dose' 'strain*dose','HRP-WT0*400'};

MS = array2table(nan(numel(rowNames),numel(strainlist)),...
    'VariableNames',strainlist,'RowNames',rowNames);


for si = 1:numel(strainlist)
    % load data
    strain = strainlist{si};
    
    %% process

    a = fopen(sprintf('%s/%s RMANOVA.txt',pD,strain),'r');
    delimiter = '';
    formatSpec = '%s%[^\n\r]';
    dataArray = textscan(a, formatSpec, 'Delimiter', delimiter,'ReturnOnError', false);
    fclose(a);
    d = [dataArray{1:end-1}];
    clearvars filename delimiter formatSpec fileID dataArray ans;

    % interpret anova
    i = find(strcmp(d,'----- RevSpeed -----'));
    d(i(1):end) = [];
    i = find(strcmp(d,'RMANOVA:'));
    k = find(strcmp(d,'Posthoc(Tukey)tap by gname:'));
    j = find(strcmp(d,'Posthoc(Tukey) HabCurve by group:'));
    d1 = d(i+1:j-1);
    d2 = d(j+1:k-1);

    d(1:k) = [];
    a = regexpcellout(d,'(*)|(,)','split');
    tap = cellfun(@str2num,regexprep(a(:,1),'tap',''));
    g1 = a(:,2);
    g2 = a(:,3);
    b = regexprep(a(:,4),' ','');
    pvalue = cellfun(@str2num,regexprep(b,'(p)|(=)|(<)',''));


    T = table;
    T.tap = tap;
    T.g1 = g1;
    T.g1dose = parseGname_TestmM(g1);
    T.g1strain = regexprep(g1,'_400mM','');
    T.g2 = g2;
    T.g2strain = regexprep(g2,'_400mM','');
    T.g2dose = parseGname_TestmM(g2);
    T.pvalue = pvalue;
    
    %% -----------------------------------

    
    % degree of freedom
    s = d1{1};
    i = strfind(s,',');
    df1 = str2double(regexprep(s(1:i(1)),'F(|(,)',''));
    s = s(i(1)+1:i(2)-1);
    df2 = str2double(s(1:strfind(s,')')-1));
    
    % MANOVA table
    a = regexpcellout(d1,', ','split');
    t = regexprep(a(:,1),'(.{1,}(?=[)]))','');
    t = regexprep(t,')','');
    t = regexprep(t,'(?<=[=]).{1,}','');
    t = regexprep(t,'[=]|(\s)','');
    pv_anova =regexprep(a(:,2),'(p)|(=)|(<)','');
    afactor = t;
    afactor = regexprep(afactor,'*tap','');
    afactor(strcmp(afactor,'Intercept')) = {'tap'};
    % add manova
    anovap = cellfun(@str2num,pv_anova);
    MS.(strain)('df') = df2;
    for ri = 1:numel(anovap)
        MS.(strain)(afactor{ri}) = anovap(ri);
    end
    
    %% get g names
    gu = unique(g1);
    strainu = unique(regexprep(gu,'_400mM',''));
    mutant = strainu(~ismember(strainu,'N2'));
    doseu = unique(T.g1dose);

    % convert to genotype
    i = ismember(strainNames(:,2), mutant);
    if sum(i)==1
        genotype = strainNames{i,1};
        muttype = strainNames{i,3};
    else
        genotype = char(mutant);
        muttype = '';
    end

    %% between curves table
    a = regexpcellout(d2,', ','split');
    pairname = a(:,1);
    gn = regexpcellout(a(:,1),'*','split');
    g1 = gn(:,1);
    g2 = gn(:,2);
    pstring_curve = a(:,2);
    pv =regexprep(a(:,2),'(p)|(=)|(<)','');
    
    b = pv(ismember(pairname,'N2*N2_400mM'));
    if ~strcmp(b,'n.s.'); 
        MS.(strain)('HRP-WT0*400') = str2num(b); 
    end
    return

%     
    
    
    %%
    T1 = table;
    T1.g1 = g1;
    T1.g1dose = parseGname_TestmM(g1);
    T1.g1strain = regexprep(g1,'_400mM','');
    T1.g2 = g2;
    T1.g2strain = regexprep(g2,'_400mM','');
    T1.g2dose = parseGname_TestmM(g2);
    T1.pvalue = pv;
    i = regexpcellout(pv,'n.s');
    T1(i,:) = [];
    pstring_curve(i) = [];
    T1.pvalue = cellfun(@str2num,(T1.pvalue));
    
    
  

    
%     regexp(s,'(?<=F[(]).','match')

    

return
    
    
    
    
    
    %% RMANOVA text
    fprintf('\nFor the %s %s allele experiments, HRP was ',genotype,muttype);
    manova_sig=false;
    i = find(~regexpcellout(pv_anova,'n.s.'));
    for x = 1:numel(i)
        if x == 1;
            manova_sig=true;
            fprintf('significantly affected by ');
        end
        k = i(x);
        t1 = afactor(k);
        s1 = d1(k);
        s = char(strjoinrows([t1, s1],', '));
        if x < numel(i); fprintf('%s, ',s);
        elseif x == numel(i); fprintf(' and %s',s);
        else fprintf('%s',s);
        end

    end


    i = find(regexpcellout(pv_anova,'n.s.'));
    for x = 1:numel(i)
        if x ==1
            if manova_sig==true; fprintf(', but not ');
            else fprintf(' not affected ');
            end
        end
        k = i(x);
        t1 = afactor(k);
        s1 = d1(k);
        s = char(t1);
        if x==1 
            if numel(i) == 1; fprintf('by %s',s);
            else fprintf('by %s, ',s);
            end
        else
            if x < numel(i)-1; fprintf('%s, ',s);
            elseif x == numel(i)-1; fprintf('%s ',s); 
            elseif x == numel(i) && numel(i)~=1; fprintf('or %s',s);
            elseif x == numel(i) && numel(i)==1; fprintf('by %s',s);
            end
        end
    end
    fprintf('. ');


    %% N2 ethanol effect
    i = ismember(T1.g1,'N2') & ismember(T1.g2,'N2_400mM');
    if sum(i) > 0
        fprintf('Wildtype showed significant EHRP (%s)',pstring_curve{i});
        effect = true;
    else
        fprintf('Wildtype did not show EHRP');
        effect = false;
    end

    % time pairwise comparison
    i = ismember(T.g1strain,'N2') & ismember(T.g2strain,'N2') & T.g1dose==0 & T.g2dose== 400;
    A = T(i,:);
     % get first/last tap report
    i = A.tap==1;
    k = A.tap==30;
    if sum(i) ==1 
        stri = print_pvalue(A.pvalue(i));
        if sum(k)==1
            strk = print_pvalue(A.pvalue(k));
            fprintf(', for which ethanol significantly affected both initial and habituated responses (tap1, %s, tap30, %s)',stri,strk);
        elseif sum(k) ==0
            fprintf(', initial response was significantly affected, %s, but not habituated response',stri);
        end
    elseif sum(i)==0 
        if sum(k)==0
            fprintf(', but neither initial nor habituated response was affected by ethanol');
        elseif sum(k)==1
            strk = print_pvalue(A.pvalue(k));
            fprintf(', initial response was not significantly affected, but habituated response was, %s',strk);
        end
    end
    fprintf(' '); % sentence linker
    % pairwise within taps
    fprintf('(wildtype 0mM vs. 400mM pairwise, ')
    pairwise_withintime(A)
    fprintf(')');
    if ~effect
       fprintf(' indicating an issue with the experiment');
    end
    fprintf('. ');


    %% mutant 0mM vs. wt 0mM (baseline)
    fprintf('%s 0mM HRP was ',genotype);
    i = ismember(T1.g1,'N2') & ismember(T1.g2,char(mutant));
    if sum(i) ==0
        fprintf('similar to wildtype 0mM HRP');
        effect = false;
    else
        fprintf('different than wildtype 0mM HRP, %s',pstring_curve{i});
        effect = true;
    end  

    fprintf(' ('); % linker
    % time pairwise comparison
    A = T(ismember(T.g1strain,'N2') & ismember(T.g2strain,mutant) & T.g1dose==0 & T.g2dose== 0,:);
    fprintf('wildtype 0mM vs. %s 0mM, ',genotype)
    pairwise_withintime(A)
    fprintf(')'); % linker
    if effect
        fprintf(', suggesting %s mutation affected HRP',genotype);
    end
    fprintf('. ');



    %% mutant ethanol effect
    fprintf('%s HRP was ',genotype);
    i = ismember(T1.g1,char(mutant)) & ismember(T1.g2,[char(mutant),'_400mM']);
    if sum(i) > 0; fprintf('significantly affected by ethanol, %s',pstring_curve{i});
    else fprintf('not affected by ethanol');
    end
    fprintf(' ('); % linker

    % time pairwise comparison
    A = T(ismember(T.g1strain,mutant) & ismember(T.g2strain,mutant) & T.g1dose==0 & T.g2dose== 400,:);
    fprintf('%s 0mM vs. 400mM, ',genotype); 
    pairwise_withintime(A)
    fprintf('). ');

    %% mutant 400mM vs. wt 400mM (alcohol extent)
    fprintf('\n');
    i = ismember(T1.g1,'N2_400mM') & ismember(T1.g2,[char(mutant),'_400mM']);
    fprintf('%s on 400mM had ',genotype);
    if sum(i) ==0
        fprintf('similar HRP as wildtype on 400mM');
    else
        fprintf('significantly different HRP than wildtype on 400mM, %s',pstring_curve{i});
    end
    fprintf(' ('); % linker
    % time pairwise comparison
    A = T(ismember(T.g1strain,'N2') & ismember(T.g2strain,mutant) & T.g1dose==400 & T.g2dose== 400,:);
    % get all reports
    fprintf('wildtype vs. %s 400mM vs.400mM, pairwise, ',genotype)
    pairwise_withintime(A)
    fprintf('). ');



    %% mutant 400mM vs. wt 0mM (ko)
    fprintf('\n');
    i = ismember(T1.g1,'N2') & ismember(T1.g2,[char(mutant),'_400mM']);
    fprintf('%s on 400mM had ',genotype);
    if sum(i) ==0; 
        fprintf('the same HRP as wildtype 0mM, ');
    else
        fprintf('significantly different HRP than wildtype on 0mM, %s',pstring_curve{i});
    end
    fprintf(', ');
    % time pairwise comparison
    A = T(ismember(T.g1strain,'N2') & ismember(T.g2strain,mutant) & T.g1dose==0 & T.g2dose== 400,:);
    % get all reports
    fprintf('wildtype 0mM vs. %s 400mM, pairwise, ',genotype)
    pairwise_withintime(A)
    fprintf('. ');


    %% mutant 0mM vs. wt 400mM (mimick ethanol effect off ethanol)
    fprintf('\n');
    i = ismember(T1.g1,'N2_400mM') & ismember(T1.g2,char(mutant));
    if sum(i) ==0
        fprintf('%s 0mM HRP was similar to wildtype 400mM HRP, ',genotype);
        switch muttype
            case 'lof'
                fprintf('suggesting that ethanol may produce EHRP through ');
                fprintf('supressing this gene');
            case 'gof'
                fprintf('suggesting that ethanol may produce EHRP through ');
                fprintf('activating this gene');
            otherwise
        end

    else
        fprintf('%s 0mM had significantly different HRP than wildtype 400mM, %s',genotype,pstring_curve{i});
    end
    fprintf(' (');
    % time pairwise comparison
    A = T(ismember(T.g1strain,'N2') & ismember(T.g2strain,mutant) & T.g1dose==400 & T.g2dose== 0,:);
    fprintf('wildtype 400mM vs. %s 0mM, ',genotype)
    pairwise_withintime(A)
    fprintf('). ');
    fprintf('\n\n');


end



% %% sub fun
% function pairwise_withintime(A)
% if isempty(A); fprintf('all taps, p=n.s.')
% else
%     if size(A,1)==30; fprintf('all taps, p<0.05');
%     elseif size(A,1) <= 15
%         k = A.tap; fprintf('taps %s, p<0.05',char(strjoinrows(num2cellstr(k)',', ')))
%     elseif size(A,1) > 15
%         k = A.tap; 
%         tp = (1:30)';
%         j = find(~ismember(tp,k));
%         fprintf('taps %s, p=n.s., other taps, p<0.05',char(strjoinrows(num2cellstr(j)',', ')))
%     end
% end
% end










































