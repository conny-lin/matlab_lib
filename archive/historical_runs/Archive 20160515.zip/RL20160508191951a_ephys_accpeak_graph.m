%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);


%% SETTING
pSF = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';

strainlist = dircontent(pSF);
strainlist(ismember(strainlist,'0-Code')) = [];
strainlist(~ismember(strainlist,'DA609')) = [];


%% load data
for si =1:numel(strainlist)
% get strain info
strain = strainlist{si};
fprintf('%d/%d: %s\n',si, numel(strainlist), strain);
% load data for strain
pData = sprintf('%s/%s',pSF,strain);
load([pData,'/data_ephys_t28_30.mat'],'DataG');
pSave = pM;


%% graph space out graphs
% decide group sequence
gu = cell(size(DataG,2),1);
for gi =1:size(DataG,2)
    gu{gi} = DataG(gi).name;
end
guseq = [find(regexpcellout(gu,'N2'));find(~regexpcellout(gu,'N2'))]';

% graph setting
linespec = {':k',':r','-k','-r'};
linespec = linespec(guseq);
% graph mean curve 
close
figure1 = figure('Visible','off'); hold on;
for gi = guseq
    gn = regexprep(DataG(gi).name,'_',' ');
    d = DataG(gi).speedbm;
    x = DataG(gi).time(1,:);
    y = nanmean(d);
    y(x==0) = nan; % make t=0 nan
    
    sd = nanstd(d);
    n = sum(~isnan(d));
    se = sd./sqrt(n-1);
    e1 = plot(x,y,linespec{gi},'DisplayName', gn,'LineWidth',1);
end

xlim([-1 5]);
ylim([-.3 .4]);
ylabel('velocity (body length/s)')
title(strain);
% legend1 = legend('show');
% set(legend1,'Location','southeast','EdgeColor',[1 1 1]);
savename = sprintf('%s ephys t28-30 pubgrade',strain);

printfig(savename,pSave,'w',2,'h',2,'closefig',1);
    
end




























    
    
    
    
    
    
    
    
    
    
    
    