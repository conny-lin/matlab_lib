%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% SETTING

%% get strain names
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
a = dircontent(pDataHome);
a(ismember(a,'0-Code')) = [];
strainlist  = a;
strainlist(~ismember(strainlist,{'BZ142'})) = [];


%% MWTDB - get all paths
MWTDB = load('/Volumes/COBOLT/MWT/MWTDB.mat');
MWTDBMaster = MWTDB.MWTDB.text; clear MWTDB;


%% get intial response table
for si = 1:numel(strainlist)
    %% get strain info
    strain = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strain);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);
    
    %% load Dance data
    p  = sprintf('%s/Dance_Glee/Dance_ShaneSpark3.mat',pSave);
    exist(p)
    
    %% validate data the same as current MWTDB
    
    
    
   
    
end