%  habituation curve 10sISI of valid experiments

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM = fileparts(pM);

%% Settings
plateN = 9;
samplingN = 100;
sampleRepeatN = 3;
msrlist = {'RevFreq','RevSpeed','RevDur'};
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';


%% get strain names
strainlist = dircontent(pDataHome);
strainlist(~ismember(strainlist,{'VG254'})) = [];

%% run data for all strains
for si = 1:numel(strainlist)
    % load data
    strain = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strain);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);
    clear MWTDB; 
    pD = [pSave,'/DataTrv.mat'];
    nodata = false;
    if exist(pD,'file')
        load(pD,'MWTDB');
    else
       % MWTDB - get all paths
        load('/Volumes/COBOLT/MWT/MWTDB.mat','MWTDB');
        MWTDB = MWTDB.text; 

        % create save folder
        i = MWTDB.ISI == 10 & MWTDB.preplate == 100 ...
            & MWTDB.tapN == 30 ...
            & ismember(MWTDB.groupname,sprintf('%s_400mM',strain));
        exp = unique(MWTDB.expname(i));
        MWTDB = MWTDB(ismember(MWTDB.expname,exp),:);
        MWTDB(~ismember(MWTDB.groupname,{'N2','N2_400mM',strain,[strain,'_400mM']}),:) = [];
        pMWT = MWTDB.mwtpath;
        nodata = isempty(pMWT);
    end
    if nodata; break; end
        
    pMWT = MWTDB.mwtpath;
    %% patches:
    % VG254 - had low N2, take from another experimetn ran by the same
    % person
    if strcmp(strain,'VG254')
       MWTDB1 = load('/Users/connylin/Dropbox/Code/Matlab/Library RL/Modules/MWTDatabase/MWTDB.mat');
       MWTDB1 = MWTDB1.MWTDB.text;
  
      i = ismember(MWTDB1.expter,'DH') & ismember(MWTDB1.groupname,{'N2','N2_400mM'}) ...
          & MWTDB1.exp_date == 20140617;
      pMWT1 = MWTDB1.mwtpath;
       pMWT = [pMWT;pMWT1];
    end
    
    
    %%
% shane spark
    MWTSet = Dance_ShaneSpark4(pMWT,'pSave',pSave);
    
    % collect graph
    for msri = 1:numel(msrlist)
        ps = sprintf('%s/Dance_ShaneSpark4/HabCurve %s.pdf',pSave,msrlist{msri});
        [~,fn] = fileparts(ps);
        pd = sprintf('%s/%s %s.pdf',pM,strain,fn);
        copyfile(ps,pd);
    end
    
    % collect RMANOVA
    ps = sprintf('%s/Dance_ShaneSpark4/RMANOVA.txt',pSave);
    [pf,fn] = fileparts(ps);
    pd = sprintf('%s/%s %s.txt',pM,strain,fn);
    copyfile(ps,pd);
    
end

















