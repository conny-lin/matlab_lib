%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);
pData = fileparts(pSave);
          
            
%% load data
cd(pData); load('data','Data2','MWTDB');

return


%%
vheader = array2table(velocitygrid(:,3),'VariableNames',{'velocity'});
DataMaster = struct;
%% gen table

for dosei = 1:numel(doses)
    V = cell((numel(t1s)+2),1);
    TIME = V;
    G = V;
    rowN = 1;

    for t1i = 1:numel(t1s)
        % get variables
        t1 = t1s(t1i);
        dose = doses(dosei);
        % get data
        [fn,p] = dircontent(sprintf('%s/N2_%dmM',pH,dose),'*rasterData.mat');
        pF = p(regexpcellout(fn,sprintf('rasterPlot_%d_',t1)));
        if numel(pF)~=1; error('too many files'); end

        % load file
        Data = load(char(pF));

        % get data
        D = Data.Data;
        Time = Data.rTime;
        if size(D,2) ~= size(Time,2)-1
            error('time not equal');
        end
        Time = Time(:,1:end-1);

        time = Time(1,:);
        time = round(time);
        if t1~=t1s(1) % get data from 5s after tap
            tt = t1+2+5;
            tt = tt:10:tt+10*2;
            i = ismember(time,tt);
            D1 = D(:,i);
            d = reshape(D1,numel(D1),1);
            t = repmat(tt(1),size(d));
            g = repmat(dose,size(d));
            V{rowN} = d;
            G{rowN} = g;
            TIME{rowN} = t;
            rowN = rowN+1;
        else

            tt = t1+2+5;
            tt = tt:10:tt+10*2;
            for tti = 1:numel(tt)
                i = ismember(time,tt(tti));
                D1 = D(:,i);
                d = reshape(D1,numel(D1),1);
                t = repmat(tt(tti),size(d));
                g = repmat(dose,size(d));
                V{rowN} = d;
                G{rowN} = g;
                TIME{rowN} = t;
                rowN = rowN+1;
            end
        
        end
    
    
        %% get tap
        time = Time(1,:);
        time = floor(time);
        if t1~=t1s(1) % get data from 0s after tap
            tt = t1+2;
            tt = tt:10:tt+10*2;
            i = ismember(time,tt);
            D1 = D(:,i);
            d = reshape(D1,numel(D1),1);
            t = repmat(tt(1),size(d));
            g = repmat(dose,size(d));
            V{rowN} = d;
            G{rowN} = g;
            TIME{rowN} = t;
            rowN = rowN+1;
        else

            tt = t1+2;
            tt = tt:10:tt+10*2;
            for tti = 1:numel(tt)
                i = ismember(time,tt(tti));
                D1 = D(:,i);
                d = reshape(D1,numel(D1),1);
                t = repmat(tt(tti),size(d));
                g = repmat(dose,size(d));
                V{rowN} = d;
                G{rowN} = g;
                TIME{rowN} = t;
                rowN = rowN+1;
            end

        end

    end
    
    %% separate velocity to grid
    
    V1 = cell2mat(V);
    V2 = nan(size(V1));
    for grindi = 1:size(velocitygrid,1)
        v1 = velocitygrid(grindi,1);
        v2 = velocitygrid(grindi,2);
        vname = velocitygrid(grindi,3);
        if isinf(v2)
            V2(V1>=v1) = vname;
        elseif isinf(v1)
            V2(V1<v2) = vname;
        else
            V2(V1 >= v1 & V1 < v2) = vname;
        end
    end
    

    %% summarize
    T = table;
    T.dose = cell2mat(G);
    T.time = cell2mat(TIME);
    T.velocity = V2;
    
    return

    %% report by time
    tu = unique(T.time);
    vu = velocitygrid(:,3);
    doseu = unique(T.dose);
    if numel(doseu) > 1; error('too many doses'); end
%     B = []; P1 = [];
    N = zeros(numel(vu),numel(tu));
    for ti = 1:numel(tu)
        P = N;
        t = tu(ti);
%         for di = 1:numel(doseu)
%             dose = doseu(di);
        i = T.time==t;
        a = tabulate(T.velocity(i));
        [i,j] = ismember(vu,a(:,1));
        N(i,ti) = a(j(i),2);
        P(i,ti) = a(j(i),3);
        
%         end
%         header = [repmat(t,size(A,1),1) vu ];
%         P = [header P];
%         A = [header A];
%         if ti==1
%            B = [[NaN NaN doseu'];A];
%            P1 = [[NaN NaN doseu'];P];
%         else
%            B = [B;A];
%            P1 =[P1;P];
%         end
    end
    %%
    vn = strjoinrows([repmat({'t'},numel(tu),1) num2cellstr(tu)],'');
    N = [vheader array2table(N,'VariableNames',vn)];
    P = [vheader array2table(P,'VariableNames',vn)];
    DataMaster(dosei).dose = doses(dosei);
    DataMaster(dosei).N = N;

    %% save
    cd(pSave);
    writetable(N,sprintf('velocity cat %dmM.csv',doses(dosei)))
    writetable(P,sprintf('velocity cat pct %dmM.csv',doses(dosei)))
end

cd(pSave);
save('data.mat','DataMaster');

%%














































