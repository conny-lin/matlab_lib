%  habituation curve 10sISI of valid experiments

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM = fileparts(pM);


%% Settings
msrlist = {'RevFreq','RevSpeed','RevDur'};
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
% Dance = 'Dance_ShaneSpark4_Nlim8';

% limit strain
strainlimit = {'NM1968'};
% strainlimit = {};

%% get strain names
strainlist = dircontent(pDataHome);
if ~isempty(strainlimit); 
    strainlist(~ismember(strainlist,strainlimit)) = []; 
end
if isempty(strainlist); warning('no strain'); end


%% run data for all strains
for si = 1:numel(strainlist)
    % load data
    strain = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strain);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);
    clear MWTDB; 
    pD = [pSave,'/DataTrv.mat'];
    nodata = false;
    if exist(pD,'file'); load(pD,'MWTDB');
    else
       % MWTDB - get all paths
        load('/Volumes/COBOLT/MWT/MWTDB.mat','MWTDB');
        MWTDB = MWTDB.text; 
        i = MWTDB.ISI == 10 & MWTDB.preplate == 100 ...
            & MWTDB.tapN == 30 ...
            & ismember(MWTDB.groupname,sprintf('%s_400mM',strain));
        exp = unique(MWTDB.expname(i));
        MWTDB = MWTDB(ismember(MWTDB.expname,exp),:);
        MWTDB(~ismember(MWTDB.groupname,{'N2','N2_400mM',strain,[strain,'_400mM']}),:) = [];
        pMWT = MWTDB.mwtpath;
        nodata = isempty(pMWT);
    end
    if nodata; break; end
    
    %%
    pMWT = MWTDB.mwtpath;
    
    %% get data
    startTime = 90; 
    endTime = 95;
    sampleSize = nan(nMWT,1);
%     S = struct;
    headerNames = {'mwtid'};
    Header = cell(size(pMWT),numel(headerNames));
    for mwti = 1:numel(pMWT)
        processIntervalReporter(nMWT,20,'MWT',mwti);
        pmat = char(getpath2chorfile(pMWT(mwti),'Gangnam.mat'));
        pmwt = pMWT(mwti);
        D = load(pmat);
        
        return
        i = D.time(:,1) <= startTime & D.time(:,2) >= endTime;
        files = D.Data(i);
        sampleSize(mwti) = numel(files);
        % load data
        A = cell(size(files));
        for wrmi = 1:numel(files)
            d = files{wrmi};
            [a,legend] = extractChorData(d,legend_gangnam,'varnames',{'id','speed','midline','curve'},'outputtype','array');
            for si = 1:numel(legend)
                A(wrmi).(legend{si}) = a(:,si);
            end
        end
        
        %% prepare summary output identifiers
        db = parseMWTinfo(pmwt);
        dbname = {'expname','groupname','mwtname'};
        S(mwti).mwtpath = {pmwt};
        S(mwti).expname = db.expname;
        S(mwti).groupname = db.groupname;
        S(mwti).mwtname =  db.mwtname;
        S(mwti).wormid = arrayfun(@(x) unique(x.id),A)';
        % calculate other outputs
        varn = legend(~ismember(legend,'id'));
        for vi = 1:numel(varn)
            S(mwti).(varn{vi}) = arrayfun(@(x) nanmean(x.(varn{vi})),A)';
        end
    end

    return
%     %% run dance
%     MWTSet = feval(Dance,pMWT,'pSave',pSave);
%     
%     % collect graph
%     for msri = 1:numel(msrlist)
%         ps = sprintf('%s/%s/HabCurve %s.pdf',pSave,Dance,msrlist{msri});
%         [~,fn] = fileparts(ps);
%         pd = sprintf('%s/%s %s.pdf',pM,strain,fn);
%         copyfile(ps,pd);
%     end
%     
%     % collect RMANOVA
%     ps = sprintf('%s/%s/RMANOVA.txt',pSave,Dance);
%     [pf,fn] = fileparts(ps);
%     pd = sprintf('%s/%s %s.txt',pM,strain,fn);
%     copyfile(ps,pd);
    
end

















