%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);
pData = fileparts(pSave);
          
            
%% load data
cd(pData); load('data','Data2','MWTDB');

%% get group
[i,j] = ismember(Data2.mwtid,MWTDB.mwtid);
Data2.dose = MWTDB.dose_test(j(i));
Data2.timer = round(Data2.time);

%% get data for each time
t = Data2.timer;
t1 = (t- (floor(t./10).*10));
D = Data2(t1<=1,:);
% adjust time
for t1 = [100 110 120]
    D.timer(ismember(D.timer,t1+1)) = t1;
end
for t1 = [240 370]
    D.timer(ismember(D.timer,[t1+1:10:(t1+1)+20 t1+10 t1+20])) = t1;
end

clear Data2

%% get pauses % comparison










































