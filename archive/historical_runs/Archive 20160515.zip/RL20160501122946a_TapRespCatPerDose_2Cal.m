%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);

%% combine data
cd(pSave); load data

%% get luckery f1e
pSaveA = [pSave,'/velocity x time']; if ~isdir(pSaveA); mkdir(pSaveA); end
for ri = 1:size(Data,1)
    x = Time(ri,1:end-1)';
    y = Data(ri,:)';
    g = MWTDB(ri,:);
    name1 = sprintf('%s %s t%d [%d]',char(g.groupname), char(g.mwtname), floor(min(x)), g.mwtid);
    name2 = regexprep(name1,'_','-');
    figure('Visible','off');
    plot(x,y)
    title(name2);
    xlim([floor(min(x)) ceil(max(x))])
    printfig(name1,pSaveA,'w',3,'h',2)
end

return



































