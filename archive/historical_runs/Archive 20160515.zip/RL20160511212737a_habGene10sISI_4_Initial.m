%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% SETTING
msrlist = {'RevFreq','RevDur','RevSpeed'};


%% load data
DM = load([pM,'/habGene10sISI_2_habValue/All.mat'],'DataMaster');
DM = DM.DataMaster;
strainlist = unqiue(DM.strain);



%% create output table 
% create col name
a = {'N2','N2_400mM','Mut','Mut_400mM'}';
colNames = [a', strjoinrows([a, cellfunexpr(a,'_SE')],'')', ...
    strjoinrows([a, cellfunexpr(a,'_N')],'')'];
nCol = numel(colNames);
a = nan(numel(strainlist),numel(colNames));
R = struct;
for msri=1:numel(msrlist)
   R.(msrlist{msri}) = a; 
end


% sn = 'N2';
% msr = 'RevFreq';
habm = 'Initial';
% i = ismember(DM.habm,habm) & ismember(DM.msr,msr) & ismember(DM.groupname,'N2');


%% get intial response table
for si = 1:numel(strainlist)
    % get strain info
    strain = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strain);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);
    
    
    i = ismember(DM.habm,habm) & ismember(DM.strain,strain);
    D = DM(i,:);
    
    % get group name
    groupName = output_sortN2first(unique(D.groupname));
    
    return
%     if numel(groupName)~=4 || ~isequal(groupName, [cgroup rgroup]')
%         warning('wrong group name');
%     else
% 
%         %% get intial data
%         for msri = 1:numel(msrlist)
%             msr = msrlist{msri};
%             y = MWTSet.Graph.Initial.(msr).Y;
%             n = MWTSet.Graph.Initial.(msr).N;
%             e = MWTSet.Graph.Initial.(msr).E;
% 
%             gn = MWTSet.Graph.Initial.(msr).GroupName;
%             [i,j] = ismember(groupName,gn);
%             ind = j(i);
%             i = [ind; ind+numel(groupName); ind+(numel(groupName)*2)];
% 
%             a = nan(1,nCol);
%             b = [y,e,n];
%             a(i) = b;
%             R.(msr)(si,:) = a;
%         end
%     end

end


%% export
for msri = 1:numel(msrlist)
   a = R.(msrlist{msri});
   a = array2table(a,'VariableNames',colNames);
   T = table;
   T.strain = strainlist;
   T = [T a];
   cd(pM);
   writetable(T,sprintf('%s.csv',msrlist{msri}));
   
end















































