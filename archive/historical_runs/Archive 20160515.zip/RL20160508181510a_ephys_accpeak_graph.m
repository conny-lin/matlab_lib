%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);


%% SETTING
pSF = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Results/Data/10sISI/by strains/';

strainlist = dircontent(pSF);
strainlist(ismember(strainlist,'0-Code')) = [];
strainlist(~ismember(strainlist,'DA609')) = [];


%% load data
for si =1:numel(strainlist)
    % get strain info
    strain = strainlist{si};
    fprintf('%d/%d: %s\n',si, numel(strainlist), strain);
    % load data for strain
    pData = sprintf('%s/%s',pSF,strain);
    load([pData,'/data_ephys_t28_30.mat']);
    pSave = sprintf('%s/ephys graph',pData); if ~isdir(pSave); mkdir(pSave); end

    
    %% graph space out graphs
    
    
end




























    
    
    
    
    
    
    
    
    
    
    
    