
%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM = fileparts(pM);


%% Settings
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';

%% process into table
pD = ['/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/',...
    '5-initial sensitivity/habGene_initialSensitivity'];
a = dircontent(pD,'*.txt');
a = regexpcellout(a,' ','split');
strainlist = unique(a(:,1));

% limit strain
strainlimit = {'NM1968'};
strainlimit = {};

%% get strain names
if ~isempty(strainlimit); 
strainlist(~ismember(strainlist,strainlimit)) = []; 
end
if isempty(strainlist); warning('no strain'); end



%%
%% set up output table
msrlist = {'curve','speedbm'};
sAbriv = {'W','M'};
colNames = {'W0_curve','M0_curve',...
    'W_curve_etohp','W_curve_etoh',...
    'M_curve_etohp','M_curve_etoh',...
    'W0_speedbm','M0_speedbm',...
    'W_speedbm_etohp','W_speedbm_etoh',...
    'M_speedbm_etohp','M_speedbm_etoh'};

rowNames = strainlist;
%% run data for all strains
MS = array2table(nan(numel(rowNames),numel(colNames)),...
    'VariableNames',colNames,'RowNames',rowNames);

for si = 1:numel(strainlist)
% get strain info
strain = strainlist{si};
fprintf('%d/%d: %s **********\n',si,numel(strainlist),strain);

Sum = struct;
for msri = 1:numel(msrlist)
    %% get msr info
    msr = msrlist{msri}; 
    %% load file
    close all;
    pf = sprintf('%s/%s %s MANOVA.txt',pD,strain,msr); 
    
    a = fopen(pf,'r');
    dataArray = textscan(a, '%s%[^\n\r]', 'Delimiter', '','ReturnOnError', false);
    fclose(a);
    d = [dataArray{1:end-1}];
    clearvars filename delimiter formatSpec fileID dataArray ans;

    % get descriptive stats
    i = find(strcmp(d,'*** Descriptive Stats ***'));
    k = find(regexpcellout(d,'*** Multifactorial ANOVA'));
    j = find(regexpcellout(d,'*** Posthoc'));
    eStat = d(i+1:k-1);
    mANOVA = d(k+1:j-1);
    postHoc = d(j+1:end);

    % interprept eStat
    a = regexpcellout(eStat,' = ','split');
    eStat_type = a(:,1);
    b = regexpcellout(a(:,2)',', ','split');
    gname = regexprep(b(1,:),' ','_');
    b = cellfun(@str2num,b(2:end,:));
    c = array2table(b,'VariableNames',gname,'RowNames',eStat_type(2:end));
    eStatT = c;
    Sum.(msr).eStatT = eStatT;


    % interpret mANOVA
    a = regexpcellout(mANOVA,'[:] ','split');
    aFactor = a(:,1);
    b = regexpcellout(a(:,2),', p ','split');
    apvalue = nan(size(b,1),1);
    p = b(:,2);
    i = regexpcellout(p,'<');
    apvalue(i) = cellfun(@str2num,regexprep(p(i),'(<)|(=) ',''));
    mANOVAT = table;
    mANOVAT.factor = aFactor;
    mANOVAT.pvalue = apvalue;
    Sum.(msr).mANOVAT = mANOVAT;

    % interpret posthoc
    a = regexpcellout(postHoc,'(, p<)|(, p=)','split');
    p = a(:,2);
    phpvalue = nan(size(a,1),1);
    i = ~regexpcellout(p,'n.s.');
    phpvalue(i) = cellfun(@str2num,p(i));
    b = regexpcellout(a(:,1),' x ','split');
    g1 = regexprep(b(:,1),' ','_');
    g2 = regexprep(b(:,2),' ','_');

    postHocT = table;
    postHocT.g1 = g1;
    postHocT.g2 = g2;
    postHocT.pvalue=  phpvalue;
    Sum.(msr).postHocT = postHocT;
    %% -----------------------------------
    
end

    
%% summarize into table
%% wildtype curve and speed


%% summary table
for msri = 1:numel(msrlist)
    msr = msrlist{msri};
    
    MS.(sprintf('W0_%s',msr))(strain) = Sum.(msr).eStatT.N2_0mM('mean');
    MS.(sprintf('M0_%s',msr))(strain) = Sum.(msr).eStatT.([strain,'_0mM'])('mean');
%     MS.(strain)(sprintf('W400_%s',msr)) = Sum.(msr).eStatT.N2_400mM('mean');
%     MS.(strain)(sprintf('M400_%s',msr)) = Sum.(msr).eStatT.([strain,'_400mM'])('mean');
    
    d = Sum.(msr).postHocT;
    e = Sum.(msr).eStatT;
    
    p = d.pvalue(ismember(d.g1,'N2_0mM') & ismember(d.g2,'N2_400mM'));
    a = e.N2_400mM('mean');
    b = e.N2_0mM('mean');
    i = a-b;
    if i < 1; p = p*-1; end
    MS.(sprintf('W_%s_etoh',msr))(strain) = p;
    MS.(sprintf('W_%s_etohp',msr))(strain) = (a-b)/b;
    
    p = d.pvalue(ismember(d.g1,[strain,'_0mM']) & ismember(d.g2,[strain,'_400mM']));
    a = e.([strain,'_400mM'])('mean');
    b = e.([strain,'_0mM'])('mean');
    i = a-b;
    if i < 1; p = p*-1; end
    MS.(sprintf('M_%s_etoh',msr))(strain) = p;
    MS.(sprintf('M_%s_etohp',msr))(strain) = (a-b)/b;

    
end



   

end





%% save




%% swith for genotype
load('/Users/connylin/Dropbox/Code/Matlab/Library RL/Modules/MWTDatabase/strainNames.mat');
s = strainNames.strain;
a = MS.Properties.RowNames;
[i,j] = ismember(a,s);
MS.Properties.RowNames = strainNames.genotype(j(i));

cd(pM);
writetable(MS,'curve_speedbm_summary.csv','WriteRowNames',1);


return



%% rank

rn = strjoinrows([repmat({'M_ME'},30,1) num2cellstr((1:30)')],'');
a = table2array(MS(rn,:));
a(isnan(a)) = 1;
b = sum(a);
[i,j] = sort(b);
MSS = MS(:,j);

cd(pM);
writetable(MSS,'pvaluesum_sorted.csv','WriteRowNames',1);



%%


% %% sub fun
% function pairwise_withintime(A)
% if isempty(A); fprintf('all taps, p=n.s.')
% else
%     if size(A,1)==30; fprintf('all taps, p<0.05');
%     elseif size(A,1) <= 15
%         k = A.tap; fprintf('taps %s, p<0.05',char(strjoinrows(num2cellstr(k)',', ')))
%     elseif size(A,1) > 15
%         k = A.tap; 
%         tp = (1:30)';
%         j = find(~ismember(tp,k));
%         fprintf('taps %s, p=n.s., other taps, p<0.05',char(strjoinrows(num2cellstr(j)',', ')))
%     end
% end
% end










































