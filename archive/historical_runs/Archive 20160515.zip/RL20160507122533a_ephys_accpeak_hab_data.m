%%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveHome = fileparts(fileparts(pM));

%% SETTING
ISI = 10; preplate = 100;
assaytimePretap = 1;
assaytimePosttap = 8;

%% MWTDB - get all paths
MWTDB = load('/Volumes/COBOLT/MWT/MWTDB.mat');
MWTDB = MWTDB.MWTDB.text;

i = MWTDB.ISI == 10 ...
    & MWTDB.preplate == preplate ...
    & MWTDB.tapN == 30 ...
    & ismember(MWTDB.rx,'400mM') ...
    & ~ismember(MWTDB.strain,'N2');
exp = unique(MWTDB.expname(i));

MWTDB(~ismember(MWTDB.expname,exp),:) = [];
MWTDB(~ismember(MWTDB.rx,{'NA','400mM'}),:) = [];

%% make sure each strain has a 400mM companion 
gu = unique(MWTDB.groupname);
a = regexpcellout(gu,'_','split');
dose = a(:,2);
strain = a(:,1);
dose(cellfun(@isempty,dose)) = {''};
strain4 = strain(ismember(dose,'400mM'));
strain0 = strain(~ismember(dose,'400mM'));
i = ismember(strain0,strain4);
if sum(~i)~=0; error('some strains do not have 400mM group'); end


%% CHOR
% check if gangnam exist
pMWT = MWTDB.mwtpath;
[pSPS,pMWTsuc,pMWTfail] = getpath2chorfile(pMWT,'Gangnam.mat','reporting',1);
 
% run chor on those do not have gangnam
[Legend,pMWTpass,pMWTfailed] = chormaster5('Gangnam',pMWTfail);
[pFiles,pMWTval] = convertchorNall2mat(pMWTpass,'gangnam','Gangnam');


%% run data for all strains
assayTapNumber = 28:30;
assaytimes = [(assayTapNumber-1)*ISI+preplate-assaytimePretap;...
    (assayTapNumber-1)*ISI+preplate+assaytimePosttap];

legend_gangnam = load('/Users/connylin/Dropbox/Code/Matlab/Library RL/Modules/Chor_output_handling/legend_gangnam.mat');
legend_gangnam = legend_gangnam.legend_gangnam;
msrInterest = {'time','id','bias','speed','tap','midline'};

for si = 1:numel(strain0)
    %% create save folder
    strainame = strain{si};
    pSaveA = [pSaveHome,'/',strainame]; if ~isdir(pSaveA); mkdir(pSaveA); end
    fprintf('%d/%d: %s\n',si,numel(strain),strainame);
    
    %% get pMWT
    k = ismember(MWTDB.strain,strainame);
    e = MWTDB.expname(k);
    % get N2 control
    i = ismember(MWTDB.expname,e) & ismember(MWTDB.strain,'N2');
    pMWT = [MWTDB.mwtpath(i); MWTDB.mwtpath(k)];
    
    
    %% run data   
    Data = ephys_extractData(pMWT,assaytimes,ISI,preplate,assayTapNumber);
    DataG = ephys_tranformData2struct(Data,gu);
    % save
    cd(pSaveA); 
    save(sprintf('data_ephys_t28_30.mat'),'Data','gu','MWTDB','DataG');

    % export as excel file
    for gi = 1:size(DataG,2)
       x = DataG(gi).time(1,:);
       n = sum(~isnan(DataG(gi).speedb));
       n = n-1;
       n(n<1) = 0;
       y = nanmean(DataG(gi).speedb);
       e = (nanstd(DataG(gi).speedb)./sqrt(n)).*2;
       y1 = nanmean(DataG(gi).speedbm);
       e1 = (nanstd(DataG(gi).speedbm)./sqrt(n)).*2;
       A = [n' x' y' e' y1' e1'];
       A = array2table(A,'VariableNames',{'N','time','speedb','speedb_2SE','speedbm','speedbm_2SE'});
       cd(pSaveA)
       writetable(A,sprintf('%s.csv',char(DataG(gi).name)))
    end

end

fprintf('DONE\n');

beep
beep
beep

    
    
    
    
    
    
    
    
    
    
    
    