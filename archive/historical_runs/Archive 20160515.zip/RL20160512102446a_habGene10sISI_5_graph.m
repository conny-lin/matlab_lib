%  habituation curve 10sISI of valid experiments

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSaveM = fileparts(pM);

%% Settings
plateN = 9;
samplingN = 100;
sampleRepeatN = 3;
msrlist = {'RevFreq','RevSpeed','RevDur'};
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';


%% get strain names
strainlist = dircontent(pDataHome);
strainlist(~ismember(strainlist,{'NM1968'})) = [];

%% run data for all strains
StrainMaster = cell(numel(strainlist),2);
for si = 1:numel(strainlist)
    % load data
    strainame = strainlist{si};
    pSave = sprintf('%s/%s',pDataHome,strainame);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strainame);
    clear MWTDB; load([pSave,'/DataTrv.mat']);
    
    % varify group name
    [i,j] = ismember(DataTrv.mwtid,MWTDB.mwtid);
    DataTrv.groupname = MWTDB.groupname(j(i));
    DataTrv.strain = MWTDB.strain(j(i));
    gnu = output_sortN2first(unique(DataTrv.groupname));
    gnExpected = {'N2','N2_400mM',strainame,[strainame,'_400mM']}';
    if ~isequal(gnu,gnExpected)
        tabulate(DataTrv.groupname)
        error('group name not expected');
    end
    
    MWTSet = Dance_ShaneSpark4(pMWT,'pSave',pSave);
    
    
end















