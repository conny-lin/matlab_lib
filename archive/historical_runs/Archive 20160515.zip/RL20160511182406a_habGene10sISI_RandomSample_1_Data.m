%  habituation curve 10sISI of valid experiments

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSave = fileparts(pM);


%% get strain names
pDataHome = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';
a = dircontent(pDataHome);
% a(ismember(a,'0-Code')) = [];
strainlist  = a;
% strainlist(~ismember(strainlist,{'VG202'})) = [];

%% run data for all strains


for si = 8:numel(strainlist)
    %% create save folder
    strainame = strainlist{si};
    pSaveA = sprintf('%s/%s',pDataHome,strainame);
    fprintf('%d/%d: %s **********\n',si,numel(strainlist),strainame);
    load([pSaveA,'/MWTDB.mat']);
    pMWT = MWTDB.mwtpath;
    % get trv data
    DataTrv = import_trv_table(pMWT);
    cd(pSave); save('DataTrv.mat','DataTrv','MWTDB');

end

return










