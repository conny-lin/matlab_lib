%% OBJ
% - get sample size and plate size report for all strain exp

%% INITIALIZING
clc; clear; close all;
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',true);


%% SETTING
pSF = '/Users/connylin/Dropbox/RL/PubInPrep/PhD Dissertation/4-STH genes/Data/10sIS by strains';

strainlist = dircontent(pSF);
strainlist(ismember(strainlist,'0-Code')) = [];
strainlist(~ismember(strainlist,'CB312')) = [];


%% load data
for si =1:numel(strainlist)
    
% get strain info
strain = strainlist{si};
fprintf('%d/%d: %s\n',si, numel(strainlist), strain);
% load data for strain
load(sprintf('%s/%s/data_ephys_t28_30',pSF,strain),'DataG','MWTDB');
pSave = pM;


%% get worm number
gu = cell(size(DataG,2),1);
wormN = nan(size(DataG,2),1);
for gi = 1:size(DataG,2)
    gu{gi} = DataG(gi).name;
    wormN(gi) = size(DataG(gi).speedb,1);
end
%% get plate number
a = tabulate(MWTDB.groupname);
[i,j] = ismember(gu,a(:,1));
plateN= cell2mat(a(j(i),2));

T = table;
T.gname = gu;
T.plateN = plateN;
T.wormN = wormN;

cd(pM); writetable(T,sprintf('%s ephys t28-30 samplesize.csv'));



end