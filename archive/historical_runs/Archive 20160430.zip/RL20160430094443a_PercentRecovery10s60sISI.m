%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);

%% get data
% load([fileparts(pSave),'/Dance_DrunkMoves/Dance_DrunkMoves.mat'])
msrlist = {'RevDur','RevFreq','RevSpeed'};
gnu = {'N2','N2_400mM'};
isiu = {'10','60'};
D = cell(numel(isi)*numel(gnu)*numel(msrlist),1);
G = D;
n = 1;
for isii = 1:numel(isiu)
    isi = isiu{isii};
    pD = sprintf('%s/Data/Hab curve %ssISI recovery/Dance_Glee_Acafellas/Data Raw',...
        fileparts(pSave),isi);
    for msri = 1:numel(msrlist)
       for gni = 1:numel(gnu)
           msr = msrlist{msri};
           gn = gnu{gni};
           p = sprintf('%s/%s_Mean %s.csv',pD,msr,gn);
           T = readtable(p);
           % calculate % initial response
           d = T.s31./T.s1;
           g = repmat(cellstr([{msr},{isi},{gn}]),numel(d),1);
           % add to master
           D{n} = d;
           G{n} = g;
           n = n+1;
       end
    end
end
% take out cell
G = celltakeout(G,'multirow');
G1 = cell(size(G,2),1);
for c = 1:size(G,2)
   G1{c} = G(:,c);
end
D = cell2mat(D);
G = G1; 
clear G1 c n T p gn msr isi pD gni msri d g gnu isii;



%% anova
% prefix = 
   anovan_std(Y,G,gvarnames,pSave,prefix,varargin)



   
   
   
   
   
   
   
   
   




