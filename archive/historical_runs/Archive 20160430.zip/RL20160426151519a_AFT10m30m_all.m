%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pF = setup_std(mfilename('fullpath'),'RL','genSave',false);


%% get groups/strains

[~,~,cn,pC] = dircontent(fileparts(pF));
pC(ismember(cn,'Dance_DrunkPosture2 20150602115031 60m')) = [];

[~,~,sn,pS] = cellfun(@dircontent,pC,'UniformOutput',0);
sn = celltakeout(sn);
pS = celltakeout(pS);
exclude = {'DrunkPosture_20141124192837_N2 60mins'
    'DrunkPosture_20141124200903_N2 300s rerun after rename'
    'N2 Age'; 'RB1025 200mM';
    'N2 dose 200 400';'VC922';'N2 400mM'};
pS(ismember(sn,exclude)) = [];
sn(ismember(sn,exclude)) = [];

for si = 1:numel(pS)

pSave = [pS{si},'/AFT_10m30m'];
if ~isdir(pSave); mkdir(pSave); end
[~,strainame] = fileparts(pS{si});
fprintf('*** %s ***\n',strainame);

%% load data
pData = [fileparts(pSave),'/Dance_DrunkMoves/Dance_DrunkMoves.mat'];
load(pData);


%% setting
msr = 'speed';
time = [10 30];

%% treat data
Data = MWTSet.Data_Plate.(msr);
Data.time = Data.timeind-1;
Data.timeind = [];
Data.groupname = MWTSet.Info.VarIndex.groupname(Data.groupname);
Data.condition = MWTSet.Info.VarIndex.condition(Data.condition);
Data.strain = MWTSet.Info.VarIndex.strain(Data.strain);
% exclude zero data
Data(Data.mean==0 | isnan(Data.mean),:) = [];

%% summary and scatter for 0mM 10-30min
StdData = table;
for ti = 1:numel(time)
    %% get 0mM mean
    D = Data;
    D(D.time ~= time(ti),:) = [];
    D(~cellfun(@isempty,D.condition),:) = [];

    % get data
    g = D.strain;
    d = D.mean;
    
    % create mean
    t = table;
    t.time = repmat(time(ti),numel(unique(g)),1);
    StdData = [StdData; [t grpstatsTable(d,g,'gnameutitle','strain')]];
    
    % plot scatter by plate
    % get different color for each exp
    cm = colormap('jet');
    n = numel(unique(D.expname));
    cdesg = cm(1:floor(size(cm,1)/n):size(cm,1),:);

    e = D.expname;
    scolor = cdesg(e,:);
    
    close;
    clusterDotsErrorbar(d,g,'markersize',50,'scatterdotcolor',scolor,...
        'xname','','yname',msr,'visible','off');
    savename = sprintf('clusterDot 0mM t%d',time(ti));
    printfig(savename,pSave);
    
end



%% calculate mean per time
A = table;
for ti = 1:numel(time)
    %% get 0mM mean
    D = Data;
    D(D.time ~= time(ti),:) = [];
    D(cellfun(@isempty,D.condition),:) = [];
    if ti==1
       [u,i]  = unique(D.mwtname);
       A.mwtid = u;
       A.strain = D.strain(i);
    end
    
    % get data
    g = D.strain;
    d = D.mean;
    mwtid = D.mwtname;
    
    % calculate mean
    S = StdData(StdData.time==time(ti),:);
    c = nan(size(d));
    [i,j] = ismember(D.strain,S.strain);
    c(i) = S.mean(j(i));
    a = d./c;
    
    % put in A
    [i,j] = ismember(A.mwtid,mwtid);
    A.(sprintf('t%d',time(ti))) = nan(size(A,1),1);
    A.(sprintf('t%d',time(ti)))(i) = a(j(i));
    
end
MWTSet.AFT_Plate = A;


%% plot scatter by plate
lightblue = [0.301960796117783 0.745098054409027 0.933333337306976];
prefix = '400mM';
A = MWTSet.AFT_Plate;
for ti = 1:numel(time)
    fn = sprintf('t%d',time(ti));
    d = A.(fn);
    g = A.strain;
       
    close;
    yname = sprintf('relative %s',msr);
    clusterDotsErrorbar(d,g,'markersize',7,'scatterdotcolor',lightblue,...
        'xname','','yname',yname,'visible','off');
    savename = sprintf('clusterDot %s t%d',prefix,time(ti));
    printfig(savename,pSave);
    
end

%% stats

%% calculate recovery
D = MWTSet.AFT_Plate;
fn = {};
for ti = 1:numel(time)
    fn{ti} = sprintf('t%d',time(ti));
end
D.recovery = D.(fn{2}) - D.(fn{1});


%% make graphic table
su = unique(D.strain);
su = [su(ismember(su,'N2')); su(~ismember(su,'N2'))];
a = strjoinrows([su repmat({'se'},numel(su),1)],'_');
b = strjoinrows([su repmat({'n'},numel(su),1)],'_');

var = [su' a' b'];
A = nan(numel(time)+1,numel(var));

gu = unique(D.strain);
for ti = 1:numel(time)
    fn = sprintf('t%d',time(ti));
    d = D.(fn);
    g = D.strain;
    T1 = grpstatsTable(d,g,'gnameutitle','strain');
    [i,j] = ismember(T1.strain,su);
    k = find(i);
    A(ti,k) = T1.mean(j(i));
    A(ti,k+numel(su)) = T1.se(j(i));
    A(ti,k+(2*numel(su))) = T1.n(j(i));
end
d = D.recovery; g = D.strain;
T1 = grpstatsTable(d,g,'gnameutitle','strain');
[i,j] = ismember(T1.strain,su);
k = find(i);
A(end,k) = T1.mean(j(i));
A(end,k+numel(su)) = T1.se(j(i));
A(end,k+(2*numel(su))) = T1.n(j(i));
T = array2table(A,'VariableNames',var,'RowNames',[num2cellstr(time');'recovery']);
cd(pSave);
writetable(T,'AFT graph.csv','WriteRowNames',1)



%% repeated measures anova
posthoctype = 'tukey-kramer';
cd(pSave);
fid = fopen('rmANOVA.txt','w');

rm = fitrm(D,'t10-t30~strain');
ranovatbl = ranova(rm);
anovatxt = anovan_textresult(ranovatbl,0);
fprintf(fid,'repeated measures ANOVA (time= 10/30min):\n');
for x = 1:numel(anovatxt)
   fprintf(fid,'%s\n',anovatxt{x}); 
end

% posthoc
T = multcompare(rm,'Time','By','strain','ComparisonType',posthoctype);
mctxt = multcompare_text2016b(T);
fprintf(fid,'\nposthoc (%s):\n%s\n',posthoctype,mctxt);

% recovery stats
[anovatext,phtext,~] = anova1_std(D.recovery,D.strain);
fprintf(fid,'\nRecovery ANOVA:\n%s\n%s',anovatext,phtext);

%% T TEST recovery
fprintf(fid,'\nt test(right tail):\n');
gu = unique(D.strain);
for gi = 1:numel(gu)
    d = D.recovery(ismember(D.strain,gu(gi)));
    [h,p,~,STATS] = ttest(d,0,'tail','right');
    str = statTxtReport('t',STATS.df,STATS.tstat,p);
    fprintf(fid,'%s, %s\n',gu{gi},str);
end

%% close text report
fclose(fid);



end







