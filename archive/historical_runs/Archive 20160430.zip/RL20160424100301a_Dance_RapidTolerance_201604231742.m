%% OBJECTIVE:

%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pF = setup_std(mfilename('fullpath'),'RL','genSave',false);

pH = fileparts(pF);
[~,~,fn,p] = dircontent(pH);
fn(ismember(fn,{'Exp info','MT14390'})) =[];


%%
for fi = 1:numel(fn)


%% load dance data

pData = sprintf('%s/%s/Dance_RapidTolerance',pH,fn{fi});
cd(pData);
Db = readtable('info.csv');
pMWT = Db.mwtpath;
pSave = fileparts(pData);
MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSave);

end
