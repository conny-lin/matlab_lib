%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% get data
load([fileparts(pSave),'/Dance_DrunkMoves/Dance_DrunkMoves.mat'])

