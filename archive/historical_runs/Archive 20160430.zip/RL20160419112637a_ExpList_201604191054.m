%% OBJECTIVE:
% - create exp list
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load data
cd(fileparts(pSave));
T = readtable('Experiment summary rapid tolerance.csv');

%% clean table
T(cellfun(@isempty,T.ExpName),:) = [];
T.note = T.Column1;
T.Column1 = [];
T.groupname_note = T.GroupName;
%% check duplications
if numel(unique(T.MWTName)) ~= size(T,1)
    error('duplicate mwtfiles');
end
%% find MWTName in MWTDB
MWTDBHOME = load('/Volumes/COBOLT/MWT/MWTDB.mat');
MWTDB = MWTDBHOME.MWTDB.text;
[i,j] = ismember(T.MWTName,MWTDB.mwtname);
if sum(i) ~= size(T,1)
    error('missing mwt files in database');
end
% combine
a = T.note;
b = T.groupname_note;
T = MWTDB(j(i),:);
T.note = a;
T.groupname_note = b;
%% load second
cd(fileparts(pSave));
T1 = readtable('Table - info.csv');
[i,j] = ismember(T1.mwtname,MWTDB.mwtname);
if sum(i) ~= size(T1,1)
    error('missing mwt files in database');
end
%% combine
a = T1.note;
T1.groupname_note = T1.groupname;
b = T.groupname_note;
T1 = MWTDB(j(i),:);
T1.note = a;
T.groupname_note = b;

%% combine
T = [T;T1];




%% view current issues
i = ~cellfun(@isempty,T.note);
T(i,{'mwtname','groupname','note'});
%%

%%
MWTDB(MWTDB.exp_date == 20150104,{'rc'})









