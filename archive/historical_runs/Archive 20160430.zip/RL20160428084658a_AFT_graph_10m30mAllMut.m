%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pFF = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pFF);

%% load data
cd(pSave);
T = readtable('AFT_allmutants.csv');
T.Properties.VariableNames = ...
    {'strain','m10','m30','mrec','s10','s30','srec'};
T(1,:) = [];
T(:,{'mrec','srec'}) = [];

% graph
N2y = table2array(T(ismember(T.strain,'N2'),{'m10','m30'}))';
N2e = table2array(T(ismember(T.strain,'N2'),{'s10','s30'}))';
N2t = [10;30];
T(ismember(T.strain,{'N'},:)) = [];
for ri = 1:size(T,1)
    my = table2array(T(ri,{'m10','m30'}))';   
    me = table2array(T(ri,{'s10','s30'}))';
    mt = [10;30];
    
    
    return
end

