%% OBJECTIVE:
% -run DA609
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load data
MWTDB = load('/Volumes/COBOLT/MWT/MWTDB.mat','MWTDB');
MWTDB = MWTDB.MWTDB.text;
enT = MWTDB.expname(ismember(MWTDB.groupname,'RB1347_E3d24h0mM_R1h_T4d0mM'));
% custom exclusion
expexclude = {'20150221C_AS_300s0x0s0s_Exp1'};
mwtexclude = {'20150719_151413'};
enT(ismember(enT,expexclude)) = [];
MWTDB(~ismember(MWTDB.expname,enT),:) = [];
MWTDB(ismember(MWTDB.mwtname,mwtexclude),:) = [];
% processing
MWTDB = parseToleranceName(MWTDB);
tabulate(MWTDB.groupname_short);



%% run all files
MWTSet = Dance_RapidTolerance(MWTDB.mwtpath,'pSave',fileparts(pSave));
pData = [fileparts(pSave),'/Dance_RapidTolerance'];



%% GRAPH SCATTER
close;
D = MWTSet.Data_Plate;
D = innerjoin(MWTSet.Info.MWTDB,D);
gu =unique(D.groupname_short);
i = regexpcellout(gu,'N2');
gu = [gu(i);gu(~i)];
su = unique(D.strain);
i = regexpcellout(su,'N2');
su = [su(i);su(~i)];
cu = unique(D.condition_short);

markercolor = nan(size(D,1),3);
cdc = [0 0 0; 1 0 0; 0.5 0.5 0.5; 1 0 1];
for cui = 1:numel(cu)
    i = ismember(D.condition_short,cu(cui));
    markercolor(i,:) = repmat(cdc(cui,:),sum(i),1);
end

close;
fig1 = figure; hold all;
markertype = {'o','^'};

for si = 1:numel(su)
    i = ismember(D.strain,su(si));
    x = D.curve(i);
    y = D.speed(i);
    a = repmat(30,numel(x),1);
    c = markercolor(i,:);
    if si==1
        scatter(x,y,a,c,markertype{si},'filled')
    else
        scatter(x,y,a,c,markertype{si})

    end
    hold on;
end
savefigpdf('speed x curve scatter',pData);




return









%%
i= ismember(MWTDB.expname,'20150221C_AS_300s0x0s0s_Exp1');
unique(MWTDB.groupname(i))
return

%%
strainlist = {'RB1025','RB1347'};
for si = 1:numel(strainlist)
strain = strainlist{si};

pSave = ['/Users/connylin/Dropbox/DissertationTEMP/',strain];
if ~isdir(pSave); mkdir(pSave); end


load('/Volumes/COBOLT/MWT/MWTDB.mat');
MWTDB = MWTDB.text;
i = ismember(MWTDB.rc,'300s0x0s0s')...
    & ismember(MWTDB.strain,strain);
i = ismember(MWTDB.expname, unique(MWTDB.expname(i)))...
    & ismember(MWTDB.strain,[{'N2'};strain]);
MWTDB = MWTDB(i,:);
pMWT = MWTDB.mwtpath;
tabulate(MWTDB.groupname)

    

end