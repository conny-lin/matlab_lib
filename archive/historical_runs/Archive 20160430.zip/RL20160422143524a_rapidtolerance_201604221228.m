%% OBJECTIVE:
% establish N2 pheontype
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',false);

%% load dance data
pDataBase = '/Volumes/COBOLT/MWT/MWTDB.csv';
Db = readtable(pDataBase);
Db(Db.preplate~=300,:) =[];
en = Db.expname(ismember(Db.groupname,'N2_E3d24h0mM_R1h_T4d0mM'));
Db(~ismember(Db.expname,en),:) = [];
Db(~ismember(Db.strain,'N2'),:) = [];
Db(ismember(Db.groupname,{'N2_Test','N2_E3d24h0mM_R1h_T4d400mM','N2_E3d24h200mM_R1h_T4d400mM'}),:)= [];

problem =unique(Db.note(~cellfun(@isempty,Db.note)));
probExclude = {'For 11/16, bleaching was 3 hours apart for strain vs. N2';
'first time adding Withdrawal group'};
problem(ismember(problem,probExclude)) = [];
Db(ismember(Db.note,problem),:) = [];

tabulate(Db.groupname)
pause_enter;
pMWT = Db.mwtpath;


%%
pSaveA = fileparts(pSave);
MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSaveA);


%% make boxes around scatter plot





















