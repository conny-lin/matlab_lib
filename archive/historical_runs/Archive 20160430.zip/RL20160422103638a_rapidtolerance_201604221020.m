%% OBJECTIVE:
% -run DA609
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load dance data
cd([fileparts(pSave),'/Dance_RapidTolerance']);
load Dance_RapidTolerance


return



%% GRAPH SCATTER - by plate
close;
D = MWTSet.Data_Plate;
D = innerjoin(MWTSet.Info.MWTDB,D);
gu =unique(D.groupname_short);
i = regexpcellout(gu,'N2');
gu = [gu(i);gu(~i)];
su = unique(D.strain);
i = regexpcellout(su,'N2');
su = [su(i);su(~i)];
cu = unique(D.condition_short);

markercolor = nan(size(D,1),3);
cdc = [0 0 0; 1 0 0; 0.5 0.5 0.5; 1 0 1];
for cui = 1:numel(cu)
    i = ismember(D.condition_short,cu(cui));
    markercolor(i,:) = repmat(cdc(cui,:),sum(i),1);
end

close;
fig1 = figure; hold all;
markertype = {'o','^'};

for si = 1:numel(su)
    i = ismember(D.strain,su(si));
    x = D.curve(i);
    y = D.speed(i);
    a = repmat(30,numel(x),1);
    c = markercolor(i,:);
    if si==1
        scatter(x,y,a,c,markertype{si},'filled')
    else
        scatter(x,y,a,c,markertype{si})

    end
    hold on;
end

savefigpdf('speed x curve scatter',pData);









%% GRAPH SCATTER - by exp
close;
D = MWTSet.Data_Plate;
D = innerjoin(MWTSet.Info.MWTDB,D);
gu =unique(D.groupname_short);
i = regexpcellout(gu,'N2');
gu = [gu(i);gu(~i)];
su = unique(D.strain);
i = regexpcellout(su,'N2');
su = [su(i);su(~i)];
cu = unique(D.condition_short);

markercolor = nan(size(D,1),3);
cdc = [0 0 0; 1 0 0; 0.5 0.5 0.5; 1 0 1];
for cui = 1:numel(cu)
    i = ismember(D.condition_short,cu(cui));
    markercolor(i,:) = repmat(cdc(cui,:),sum(i),1);
end

close;
fig1 = figure; hold all;
markertype = {'o','^'};

for si = 1:numel(su)
    i = ismember(D.strain,su(si));
    x = D.curve(i);
    y = D.speed(i);
    a = repmat(30,numel(x),1);
    c = markercolor(i,:);
    if si==1
        scatter(x,y,a,c,markertype{si},'filled')
    else
        scatter(x,y,a,c,markertype{si})

    end
    hold on;
end
savefigpdf('speed x curve scatter',pData);




return
