%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pFF = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pFF);

%%
