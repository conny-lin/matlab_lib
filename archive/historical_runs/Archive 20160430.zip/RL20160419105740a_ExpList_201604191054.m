%% OBJECTIVE:
% - create exp list
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load data
T = readtable('Experiment summary rapid tolerance')