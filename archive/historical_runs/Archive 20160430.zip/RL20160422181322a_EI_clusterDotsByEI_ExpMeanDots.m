%% TIWI

%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',false);

pSaveA = [fileparts(pSave),'/Dance_RapidTolerance'];
cd(pSaveA);
load Dance_RapidTolerance;



%% make boxes around scatter plot
lightblue = [0.301960796117783 0.745098054409027 0.933333337306976];
name_postfix = 'EI clusterdots by exp';
msrlist = {'speed','curve'};
eilist = {'TI','WI'};
for msri = 1:numel(msrlist)
    msr = msrlist{msri};
    effectindex = {};
    effect = [];
    for ei = 1:numel(eilist)
        einame = eilist{ei};
        D = MWTSet.EI.(msr).(einame);
        a = regexpcellout(D.group,' ','split');
        grp = regexpcellout(a(:,1),'\<\d{8}','match');
        d = D.(einame);
        A = grpstatsTable(d,grp);
        A(:,{'se','sd','n'}) = [];
        effectindex = [effectindex; repmat({einame},size(A,1),1)];
        effect = [effect; A.mean];
    end
        
    clusterDotsErrorbar(effect,effectindex,...
        'markersize',6,'scatterdotcolor',lightblue,...
        'yname',sprintf('%s',msr),'xname','');
    
    savename = sprintf('%s %s %s',msr, einame,name_postfix);
    cd(pSaveA);
    savefig(savename);
    savefigpdf(savename,pSaveA);
end