%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pM = setup_std(mfilename('fullpath'),'RL','genSave',false);
pSave = fileparts(pM);

%% get data
% load([fileparts(pSave),'/Dance_DrunkMoves/Dance_DrunkMoves.mat'])

[pSave,'Data/Hab curve 60sISI recovery/Dance_Glee_Acafellas/Data Raw']







