%% OBJECTIVE:
% establish N2 pheontype
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load dance data
pDataBase = '/Volumes/COBOLT/MWT/MWTDB.csv';
Db = readtable(pDataBase);
%%
Db(Db.preplate~=300,:) =[];
en = Db.expname(ismember(Db.groupname,'N2_E3d24h0mM_R1h_T4d0mM'));
Db(~ismember(Db.expname,en),:) = [];
Db(~ismember(Db.strain,'N2'),:) = [];
Db(ismember(Db.groupname,'N2_Test'),:)= [];
unique(Db.groupname)

return

pData = [fileparts(pSave),'/Dance_RapidTolerance'];
cd(pData);
load Dance_RapidTolerance






%% GRAPH SCATTER - by exp
close;
D = MWTSet.Data_Exp;
msrlist = {'speed','curve'};
for msri= 1:numel(msrlist)
    msr = msrlist{msri};
    D1 = D.(msr);
    gname = strjoinrows(D1(:,{'strain','predose','postdose'}));
    
    clusterDotsErrorbar(D1.mean,gname,'markersize',10,'xname','','yname',msr)
    hText = xticklabel_rotate([],90);
    savefigpdf(sprintf('%s bar scatter by exp',msr),pData);

    
end
  


%% GRAPH SCATTER - by plate sep by exp
close;
D = MWTSet.Data_Plate;
D = innerjoin(MWTSet.Info.MWTDB,D);
D.exp_datestr = cellstr(num2str(D.exp_date));
msrlist = {'speed','curve'};
for msri= 1:numel(msrlist)
    msr = msrlist{msri};
    D1 = D.(msr);
    gname = strjoinrows(D(:,{'exp_datestr','groupname_short'}));
    clusterDotsErrorbar(D1,gname,'markersize',5,'xname','','yname',msr)
    hText = xticklabel_rotate([],90);
    savefigpdf(sprintf('%s bar scatter by plate sep exp',msr),pData);

    
end

return


%%

gu =unique(D.groupname_short);
i = regexpcellout(gu,'N2');
gu = [gu(i);gu(~i)];
su = unique(D.strain);
i = regexpcellout(su,'N2');
su = [su(i);su(~i)];
cu = unique(D.condition_short);

markercolor = nan(size(D,1),3);
cdc = [0 0 0; 1 0 0; 0.5 0.5 0.5; 1 0 1];
for cui = 1:numel(cu)
    i = ismember(D.condition_short,cu(cui));
    markercolor(i,:) = repmat(cdc(cui,:),sum(i),1);
end

close;
fig1 = figure; hold all;
markertype = {'o','^'};

for si = 1:numel(su)
    i = ismember(D.strain,su(si));
    x = D.curve(i);
    y = D.speed(i);
    a = repmat(30,numel(x),1);
    c = markercolor(i,:);
    if si==1
        scatter(x,y,a,c,markertype{si},'filled')
    else
        scatter(x,y,a,c,markertype{si})

    end
    hold on;
end










%% GRAPH SCATTER - by exp
close;
D = MWTSet.Data_Plate;
D = innerjoin(MWTSet.Info.MWTDB,D);
gu =unique(D.groupname_short);
i = regexpcellout(gu,'N2');
gu = [gu(i);gu(~i)];
su = unique(D.strain);
i = regexpcellout(su,'N2');
su = [su(i);su(~i)];
cu = unique(D.condition_short);

markercolor = nan(size(D,1),3);
cdc = [0 0 0; 1 0 0; 0.5 0.5 0.5; 1 0 1];
for cui = 1:numel(cu)
    i = ismember(D.condition_short,cu(cui));
    markercolor(i,:) = repmat(cdc(cui,:),sum(i),1);
end

close;
fig1 = figure; hold all;
markertype = {'o','^'};

for si = 1:numel(su)
    i = ismember(D.strain,su(si));
    x = D.curve(i);
    y = D.speed(i);
    a = repmat(30,numel(x),1);
    c = markercolor(i,:);
    if si==1
        scatter(x,y,a,c,markertype{si},'filled')
    else
        scatter(x,y,a,c,markertype{si})

    end
    hold on;
end
savefigpdf('speed x curve scatter',pData);




return
