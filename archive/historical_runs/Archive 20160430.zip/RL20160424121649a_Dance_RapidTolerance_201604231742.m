%% OBJECTIVE:

%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pF = setup_std(mfilename('fullpath'),'RL','genSave',false);

pH = fileparts(pF);
[~,~,fn,p] = dircontent(pH);
fn(ismember(fn,{'Exp info','MT14390'})) =[];


%%  re run dance
for fi = 1:numel(fn)
    fprintf('\nstrain: %s\n',fn{fi});
    pSave = sprintf('%s/%s',pH,fn{fi});
    cd(pSave);
    Db = readtable('info.csv');
    pMWT = Db.mwtpath;
    MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSave);
end
