%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pSave = setup_std(mfilename('fullpath'),'RL','genSave',true);

%% load data


pData = [fileparts(pSave),'/Dance_DrunkMoves/Dance_DrunkMoves.mat'];
load(pData);







