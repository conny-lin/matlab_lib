%% OBJECTIVE:
% establish N2 pheontype
%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pF = setup_std(mfilename('fullpath'),'RL','genSave',false);


[~,~,fn,p] = dircontent(fileparts(pF));

return

%% load dance data
pData = [fileparts(pSave),'/Dance_RapidTolerance'];
cd(pData);
Db = readtable('info.csv');
pMWT = Db.mwtpath;
MWTSet = Dance_RapidTolerance(pMWT,'pSave',pSaveA);

return
