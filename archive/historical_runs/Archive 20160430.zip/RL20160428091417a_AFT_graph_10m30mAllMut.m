%% INITIALIZING
clc; clear; close all;
%% PATHS
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pFF = setup_std(mfilename('fullpath'),'RL','genSave',true);
pSave = fileparts(pFF);

%% load data
cd(pSave);
T = readtable('AFT_allmutants.csv');
T.Properties.VariableNames = ...
    {'strain','m10','m30','mrec','s10','s30','srec'};
T(1,:) = [];
T(:,{'mrec','srec'}) = [];

% get N2
N2y = table2array(T(ismember(T.strain,'N2'),{'m10','m30'}))';
N2e = table2array(T(ismember(T.strain,'N2'),{'s10','s30'}))';
N2t = [1;2];
T(ismember(T.strain,{'N2'}),:) = [];
%% graph

close

xstart = 0;
for ri = 1:size(T,1)
    my = table2array(T(ri,{'m10','m30'}))';   
    me = table2array(T(ri,{'s10','s30'}))';
    mt = [1;2];
    
    x = [N2t mt];
    y = [N2y my];
    e = [N2e me];
    
    % Create axes
    fig1 = figure('Visible','off');
    axes1 = axes('Parent',fig1);
    hold(axes1,'on');

    % Create multiple error bars using matrix input to errorbar
    errorbar1 = errorbar(x,y,e,'MarkerSize',6,'Marker','o','LineWidth',1);
    set(errorbar1(2),...
        'MarkerFaceColor',[0.0784313753247261 0.168627455830574 0.549019634723663],...
        'MarkerEdgeColor',[0.0784313753247261 0.168627455830574 0.549019634723663],...
        'Color',[0.0784313753247261 0.168627455830574 0.549019634723663]);
    set(errorbar1(1),'MarkerFaceColor',[0 0 0],'MarkerEdgeColor',[0 0 0],...
        'Color',[0 0 0]);
    ylim(axes1,[0 3]);
    xlim(axes1,[0.8 2.2])
    
    if ri==1
       printfig('axes',pFF,'closefig',0,'w',1,'h',2); 
    end
    
    set(axes1,'XColor',[1 1 1],'XTick',[1 2],'XTickLabel',{'10','30'},...
        'YColor',[1 1 1],'ZColor',[1 1 1]);
    
    savename = T.strain{ri};
    printfig(savename,pFF,'closefig',1,'w',1,'h',2)
    
end

