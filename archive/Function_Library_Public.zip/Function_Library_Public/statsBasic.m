function d = statsBasic(N,varargin)
% get mean, N, std, se
% if multiple then Col = per group nRow = per datapoint

nRow = size(N,1);
nCol = size(N,2);
if nCol == 1 || nRow == 1
    n = sum(~isnan(N));
    nall = numel(N);
    d = [nall,n, nanmean(N),nanstd(N),nanstd(N)/sqrt(n-1)];
else
    m = mean(N,2);
    n = sum(~isnan(N),2);
    nall = repmat(size(N,2),size(N,1),1);
    sd = std(N')';
    se = sd./sqrt(n-1);
    d = [nall,n,m,sd,se];
end

if nargin > 1 
    if ismember('table',varargin) == 1
        d = table;
        d.gn = 'all';
        d.n = n;
        d.mean = nanmean(N);
        d.sd = std(N);
        d.se = nanstd(N)/sqrt(n-1);
    end
end
    
