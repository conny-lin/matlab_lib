function result = anova_textresult(t)
df = t{2,3};
error = t{3,3};
fvalue = t{2,5};
pvalue = t{2,6};
str = 'F(%d,%d) = %.3f, p %s %.4f';
if pvalue < 0.0001; sign = '<'; pvalue = 0.0001; else sign = '='; end
result = sprintf(str,df,error,fvalue,sign,pvalue);
end