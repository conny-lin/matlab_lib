function result = anovan_textresult(t)
%% display results of multiway anova


ttype = t(:,1);
factors = 2:find(ismember(ttype,'Error'))-1;
error = t{ismember(ttype,'Error'),3};
result = cell(numel(factors),1);
fx = 1;
for x = factors
    factorname = t{x,1};
    df = t{x,3};
    fvalue = t{x,6};
    pvalue = t{x,7};
    str = '%s: F(%d,%d) = %.3f, p %s %.4f';
    if pvalue < 0.0001; sign = '<'; pvalue = 0.0001; else sign = '='; end
    a = sprintf(str,factorname,df,error,fvalue,sign,pvalue);
    result{fx,1} = a;

    fprintf([str,'\n'],factorname,df,error,fvalue,sign,pvalue);
    fx = fx +1;
end




end